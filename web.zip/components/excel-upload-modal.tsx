"use client"

import { useState, useRef } from "react"
import { Upload, FileSpreadsheet, X, CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

interface ExcelUploadModalProps {
  onUpload: (file: File) => void
}

export function ExcelUploadModal({ onUpload }: ExcelUploadModalProps) {
  const [open, setOpen] = useState(false)
  const [file, setFile] = useState<File | null>(null)
  const [isDragging, setIsDragging] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = () => {
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)

    const droppedFile = e.dataTransfer.files[0]
    if (droppedFile && isValidFile(droppedFile)) {
      setFile(droppedFile)
    }
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (selectedFile && isValidFile(selectedFile)) {
      setFile(selectedFile)
    }
  }

  const isValidFile = (file: File) => {
    const validTypes = [
      "application/vnd.ms-excel",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ]
    const isValid = validTypes.includes(file.type)
    const isUnder10MB = file.size <= 10 * 1024 * 1024

    if (!isValid) {
      alert("엑셀 파일(.xls, .xlsx)만 업로드 가능합니다.")
      return false
    }
    if (!isUnder10MB) {
      alert("파일 크기는 10MB를 초과할 수 없습니다.")
      return false
    }
    return true
  }

  const handleUpload = () => {
    if (file) {
      onUpload(file)
      setFile(null)
      setOpen(false)
    }
  }

  const handleRemove = () => {
    setFile(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2">
          <Upload className="h-4 w-4" />
          {'엑셀 업로드'}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">{'엑셀 파일 업로드'}</DialogTitle>
          <DialogDescription>
            {'엑셀 파일(.xls, .xlsx)을 업로드하세요. 최대 파일 크기는 10MB입니다.'}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {!file ? (
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`flex flex-col items-center justify-center gap-4 rounded-lg border-2 border-dashed p-12 transition-colors ${
                isDragging
                  ? "border-primary bg-primary/5"
                  : "border-border bg-muted/20"
              }`}
            >
              <FileSpreadsheet className="h-16 w-16 text-muted-foreground" />
              <div className="text-center">
                <p className="text-sm font-medium text-foreground">
                  {'파일을 드래그하여 놓거나'}
                </p>
                <Button
                  variant="link"
                  className="h-auto p-0 text-primary"
                  onClick={() => fileInputRef.current?.click()}
                >
                  {'파일 선택'}
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                {'XLS, XLSX (최대 10MB)'}
              </p>
              <input
                ref={fileInputRef}
                type="file"
                accept=".xls,.xlsx"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
          ) : (
            <div className="flex items-center gap-4 rounded-lg border border-border bg-muted/30 p-4">
              <CheckCircle2 className="h-10 w-10 text-green-600" />
              <div className="flex-1">
                <p className="font-medium text-foreground">{file.name}</p>
                <p className="text-sm text-muted-foreground">
                  {(file.size / 1024).toFixed(2)} KB
                </p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleRemove}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="h-5 w-5" />
              </Button>
            </div>
          )}

          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setOpen(false)}>
              {'취소'}
            </Button>
            <Button onClick={handleUpload} disabled={!file}>
              {'업로드'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
