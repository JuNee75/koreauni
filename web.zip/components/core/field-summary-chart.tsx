"use client"

import { useEffect, useRef } from "react"
import type { CoreField } from "@/lib/core-indicators-data"

interface FieldSummaryChartProps {
  fields: CoreField[]
}

export function FieldSummaryChart({ fields }: FieldSummaryChartProps) {
  const chartRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    let chart: Highcharts.Chart | undefined
    async function init() {
      const Highcharts = (await import("highcharts")).default

      const categories = fields.map((f) => f.field)
      const colors = fields.map((f) => f.color)

      const parentData = fields.map((f) => {
        const parents = f.indicators.filter((i) => i.isParent)
        const vals = parents
          .map((i) => parseFloat(i.achievement25))
          .filter((v) => !isNaN(v))
        return vals.length > 0
          ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length)
          : 0
      })

      if (chartRef.current) {
        chart = Highcharts.chart(chartRef.current, {
          chart: {
            type: "column",
            backgroundColor: "transparent",
            style: { fontFamily: "var(--font-sans), sans-serif" },
          },
          title: { text: undefined },
          xAxis: {
            categories,
            labels: {
              style: { fontSize: "13px", color: "#334155", fontWeight: "600" },
            },
            lineColor: "#e2e8f0",
            tickColor: "#e2e8f0",
          },
          yAxis: {
            title: {
              text: "평균 달성률 (%)",
              style: { color: "#64748b", fontSize: "12px" },
            },
            gridLineColor: "#f1f5f9",
            labels: { style: { color: "#64748b" } },
            plotLines: [
              {
                value: 100,
                color: "#94A3B8",
                dashStyle: "Dash" as Highcharts.DashStyleValue,
                width: 1.5,
                label: {
                  text: "목표 100%",
                  align: "right" as Highcharts.AlignValue,
                  style: { color: "#94A3B8", fontSize: "11px" },
                },
              },
            ],
          },
          legend: { enabled: false },
          tooltip: {
            formatter: function (this: Highcharts.TooltipFormatterContextObject) {
              const idx = this.point.index ?? 0
              return `<b>${categories[idx]}</b><br/>평균 달성률: <b>${this.y}%</b>`
            },
            backgroundColor: "#ffffff",
            borderColor: "#e2e8f0",
            borderRadius: 8,
            shadow: {
              color: "rgba(0,0,0,0.08)",
              offsetX: 0,
              offsetY: 2,
              width: 8,
            },
            style: { fontSize: "13px" },
          },
          plotOptions: {
            column: {
              borderRadius: 6,
              colorByPoint: true,
              colors,
              dataLabels: {
                enabled: true,
                format: "{y}%",
                style: {
                  fontSize: "13px",
                  fontWeight: "700",
                  color: "#334155",
                  textOutline: "none",
                },
              },
            },
          },
          series: [
            {
              type: "column" as const,
              name: "평균 달성률",
              data: parentData,
            },
          ],
          accessibility: { enabled: false },
          credits: { enabled: false },
        })
      }
    }
    init()
    return () => {
      chart?.destroy()
    }
  }, [fields])

  return <div ref={chartRef} className="h-[360px] w-full" />
}
