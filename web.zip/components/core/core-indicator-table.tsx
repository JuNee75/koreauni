"use client"

import { useState } from "react"
import { Info } from "lucide-react"
import type { CoreSubIndicator } from "@/lib/core-indicators-data"
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip"

interface CoreIndicatorTableProps {
  indicators: CoreSubIndicator[]
  fieldColor: string
}

function AchievementBar({
  value,
  color,
}: {
  value: string
  color: string
}) {
  const num = parseFloat(value)
  if (isNaN(num)) return <span className="text-xs text-muted-foreground">{"-"}</span>

  const capped = Math.min(num, 100)
  let barColor = "#94A3B8"
  if (num >= 100) barColor = "#22C55E"
  else if (num >= 70) barColor = "#3B82F6"
  else if (num >= 50) barColor = "#EAB308"
  else if (num > 0) barColor = "#EF4444"

  return (
    <div className="flex items-center gap-2">
      <div className="h-2 w-16 rounded-full bg-muted overflow-hidden">
        <div
          className="h-full rounded-full transition-all"
          style={{ width: `${capped}%`, backgroundColor: barColor }}
        />
      </div>
      <span className="text-xs font-semibold text-foreground whitespace-nowrap">
        {value}
      </span>
    </div>
  )
}

function TypeBadge({ type }: { type: string }) {
  const colorMap: Record<string, string> = {
    "결과": "bg-[#3B82F6]/10 text-[#3B82F6]",
    "과정": "bg-[#EAB308]/10 text-[#B45309]",
    "투입": "bg-[#8B5CF6]/10 text-[#7C3AED]",
    "-": "bg-muted text-muted-foreground",
  }
  return (
    <span
      className={`inline-flex items-center rounded px-1.5 py-0.5 text-[11px] font-medium ${colorMap[type] || colorMap["-"]}`}
    >
      {type}
    </span>
  )
}

export function CoreIndicatorTable({
  indicators,
  fieldColor,
}: CoreIndicatorTableProps) {
  const [showFormula, setShowFormula] = useState<string | null>(null)

  return (
    <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border">
              <th className="px-3 py-3 text-left font-semibold text-muted-foreground whitespace-nowrap">
                {"기호"}
              </th>
              <th className="px-3 py-3 text-left font-semibold text-muted-foreground whitespace-nowrap">
                {"종류"}
              </th>
              <th className="px-3 py-3 text-left font-semibold text-muted-foreground min-w-[200px]">
                {"성과지표명"}
              </th>
              <th className="px-3 py-3 text-center font-semibold text-muted-foreground whitespace-nowrap">
                {"'24 목표"}
              </th>
              <th className="px-3 py-3 text-center font-semibold text-muted-foreground whitespace-nowrap">
                {"'25 목표"}
              </th>
              <th className="px-3 py-3 text-center font-semibold text-muted-foreground whitespace-nowrap">
                {"'25 현재"}
              </th>
              <th className="px-3 py-3 text-center font-semibold text-muted-foreground whitespace-nowrap">
                {"'25 달성도"}
              </th>
              <th className="px-3 py-3 text-center font-semibold text-muted-foreground whitespace-nowrap">
                {"'26 목표"}
              </th>
              <th className="px-3 py-3 text-center font-semibold text-muted-foreground whitespace-nowrap">
                {"'27 목표"}
              </th>
            </tr>
          </thead>
          <tbody>
            {indicators.map((item) => (
              <tr
                key={item.id}
                className={`border-b border-border/50 transition-colors hover:bg-muted/30 ${
                  item.isParent ? "bg-muted/20" : ""
                }`}
              >
                <td className="px-3 py-3 whitespace-nowrap">
                  <span
                    className={`font-semibold ${item.isParent ? "text-foreground" : "text-muted-foreground"}`}
                  >
                    {item.code}
                  </span>
                </td>
                <td className="px-3 py-3 whitespace-nowrap">
                  <TypeBadge type={item.type} />
                </td>
                <td className="px-3 py-3">
                  <div className="flex items-center gap-1.5">
                    <span
                      className={`${item.isParent ? "font-bold text-foreground" : "text-foreground"}`}
                    >
                      {item.name}
                    </span>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button
                          className="text-muted-foreground hover:text-foreground shrink-0"
                          onClick={() =>
                            setShowFormula(
                              showFormula === item.id ? null : item.id
                            )
                          }
                        >
                          <Info className="h-3.5 w-3.5" />
                        </button>
                      </TooltipTrigger>
                      <TooltipContent
                        side="top"
                        className="max-w-[360px] text-xs"
                      >
                        <p className="font-semibold">{"산출식"}</p>
                        <p className="mt-1">{item.formula}</p>
                        {item.source !== "-" && (
                          <>
                            <p className="font-semibold mt-2">{"정보 근거"}</p>
                            <p className="mt-1">{item.source}</p>
                          </>
                        )}
                      </TooltipContent>
                    </Tooltip>
                  </div>
                </td>
                <td className="px-3 py-3 text-center text-muted-foreground whitespace-nowrap">
                  {item.target24}
                </td>
                <td className="px-3 py-3 text-center font-medium whitespace-nowrap">
                  {item.target25Goal}
                </td>
                <td className="px-3 py-3 text-center whitespace-nowrap">
                  <span
                    className={`font-medium ${
                      parseFloat(item.current25) >= parseFloat(item.target25Goal)
                        ? "text-[#22C55E]"
                        : "text-foreground"
                    }`}
                  >
                    {item.current25 || "-"}
                  </span>
                </td>
                <td className="px-3 py-3">
                  <div className="flex justify-center">
                    <AchievementBar
                      value={item.achievement25}
                      color={fieldColor}
                    />
                  </div>
                </td>
                <td className="px-3 py-3 text-center text-muted-foreground whitespace-nowrap">
                  {item.target26}
                </td>
                <td className="px-3 py-3 text-center text-muted-foreground whitespace-nowrap">
                  {item.target27Goal}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
    </div>
  )
}
