"use client"

import { useEffect, useRef } from "react"
import type { CoreField } from "@/lib/core-indicators-data"

interface FieldRadarChartProps {
  fields: CoreField[]
}

export function FieldRadarChart({ fields }: FieldRadarChartProps) {
  const chartRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    let chart: Highcharts.Chart | undefined
    async function init() {
      const Highcharts = (await import("highcharts")).default
      const HighchartsMore = (await import("highcharts/highcharts-more")).default
      HighchartsMore(Highcharts)

      const categories = fields.map((f) => f.field)

      const achievementData = fields.map((f) => {
        const parents = f.indicators.filter((i) => i.isParent)
        const vals = parents
          .map((i) => parseFloat(i.achievement25))
          .filter((v) => !isNaN(v))
        return vals.length > 0
          ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length)
          : 0
      })

      if (chartRef.current) {
        chart = Highcharts.chart(chartRef.current, {
          chart: {
            polar: true,
            type: "area",
            backgroundColor: "transparent",
            style: { fontFamily: "var(--font-sans), sans-serif" },
          },
          title: { text: undefined },
          pane: {
            size: "85%",
          },
          xAxis: {
            categories,
            tickmarkPlacement: "on",
            lineWidth: 0,
            labels: {
              style: {
                fontSize: "13px",
                color: "#334155",
                fontWeight: "600",
              },
            },
          },
          yAxis: {
            gridLineInterpolation: "polygon",
            lineWidth: 0,
            min: 0,
            max: 150,
            tickInterval: 50,
            labels: {
              format: "{value}%",
              style: { color: "#94A3B8", fontSize: "10px" },
            },
            gridLineColor: "#e2e8f0",
          },
          legend: { enabled: false },
          tooltip: {
            shared: true,
            pointFormat:
              '<span style="color:{series.color}">{series.name}: <b>{point.y}%</b></span><br/>',
            backgroundColor: "#ffffff",
            borderColor: "#e2e8f0",
            borderRadius: 8,
            shadow: {
              color: "rgba(0,0,0,0.08)",
              offsetX: 0,
              offsetY: 2,
              width: 8,
            },
            style: { fontSize: "13px" },
          },
          series: [
            {
              type: "area" as const,
              name: "'25 달성률",
              data: achievementData,
              pointPlacement: "on",
              color: "#3B82F6",
              fillOpacity: 0.15,
              lineWidth: 2,
              marker: {
                radius: 4,
              },
            },
            {
              type: "area" as const,
              name: "목표 (100%)",
              data: [100, 100, 100, 100],
              pointPlacement: "on",
              color: "#94A3B8",
              fillOpacity: 0.05,
              lineWidth: 1,
              dashStyle: "Dash" as Highcharts.DashStyleValue,
              marker: { enabled: false },
            },
          ],
          accessibility: { enabled: false },
          credits: { enabled: false },
        })
      }
    }
    init()
    return () => {
      chart?.destroy()
    }
  }, [fields])

  return <div ref={chartRef} className="h-[360px] w-full" />
}
