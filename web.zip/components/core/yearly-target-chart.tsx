"use client"

import { useEffect, useRef } from "react"
import type { CoreSubIndicator } from "@/lib/core-indicators-data"

interface YearlyTargetChartProps {
  indicators: CoreSubIndicator[]
  fieldColor: string
  fieldName: string
}

export function YearlyTargetChart({
  indicators,
  fieldColor,
  fieldName,
}: YearlyTargetChartProps) {
  const chartRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    let chart: Highcharts.Chart | undefined
    async function init() {
      const Highcharts = (await import("highcharts")).default

      const parentIndicators = indicators.filter((i) => i.isParent)
      const categories = parentIndicators.map((i) => i.name)

      const target24 = parentIndicators.map((i) => {
        const v = parseFloat(i.target24)
        return isNaN(v) ? 0 : v
      })
      const target25 = parentIndicators.map((i) => {
        const v = parseFloat(i.target25Goal)
        return isNaN(v) ? 0 : v
      })
      const current25 = parentIndicators.map((i) => {
        const v = parseFloat(i.current25)
        return isNaN(v) ? 0 : v
      })
      const target26 = parentIndicators.map((i) => {
        const v = parseFloat(i.target26)
        return isNaN(v) ? 0 : v
      })
      const target27 = parentIndicators.map((i) => {
        const v = parseFloat(i.target27Goal)
        return isNaN(v) ? 0 : v
      })

      if (chartRef.current) {
        chart = Highcharts.chart(chartRef.current, {
          chart: {
            type: "column",
            backgroundColor: "transparent",
            style: { fontFamily: "var(--font-sans), sans-serif" },
          },
          title: { text: undefined },
          xAxis: {
            categories,
            labels: {
              style: { fontSize: "11px", color: "#334155" },
              rotation: categories.length > 3 ? -30 : 0,
            },
            lineColor: "#e2e8f0",
            tickColor: "#e2e8f0",
          },
          yAxis: {
            title: {
              text: "%",
              style: { color: "#64748b", fontSize: "12px" },
            },
            gridLineColor: "#f1f5f9",
            labels: { style: { color: "#64748b" } },
          },
          legend: {
            enabled: true,
            align: "center" as Highcharts.AlignValue,
            verticalAlign: "bottom" as Highcharts.VerticalAlignValue,
            itemStyle: {
              fontSize: "12px",
              color: "#64748b",
              fontWeight: "500",
            },
          },
          tooltip: {
            shared: true,
            backgroundColor: "#ffffff",
            borderColor: "#e2e8f0",
            borderRadius: 8,
            shadow: {
              color: "rgba(0,0,0,0.08)",
              offsetX: 0,
              offsetY: 2,
              width: 8,
            },
            style: { fontSize: "12px" },
          },
          plotOptions: {
            column: {
              borderRadius: 3,
              groupPadding: 0.15,
            },
          },
          series: [
            {
              type: "column" as const,
              name: "'24 목표",
              data: target24,
              color: "#CBD5E1",
            },
            {
              type: "column" as const,
              name: "'25 목표",
              data: target25,
              color: "#94A3B8",
            },
            {
              type: "column" as const,
              name: "'25 현재",
              data: current25,
              color: fieldColor,
            },
            {
              type: "column" as const,
              name: "'26 목표",
              data: target26,
              color: "#64748B",
            },
            {
              type: "column" as const,
              name: "'27 목표",
              data: target27,
              color: "#334155",
            },
          ],
          accessibility: { enabled: false },
          credits: { enabled: false },
        })
      }
    }
    init()
    return () => {
      chart?.destroy()
    }
  }, [indicators, fieldColor, fieldName])

  return <div ref={chartRef} className="h-[360px] w-full" />
}
