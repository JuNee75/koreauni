"use client"

import { useEffect, useRef } from "react"
import type { CoreSubIndicator } from "@/lib/core-indicators-data"

interface SubIndicatorChartProps {
  indicators: CoreSubIndicator[]
  fieldColor: string
}

export function SubIndicatorChart({
  indicators,
  fieldColor,
}: SubIndicatorChartProps) {
  const chartRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    let chart: Highcharts.Chart | undefined
    async function init() {
      const Highcharts = (await import("highcharts")).default

      const subIndicators = indicators.filter((i) => !i.isParent)
      const categories = subIndicators.map((i) => i.code)
      const fullNames = subIndicators.map((i) => i.name)
      const achievements = subIndicators.map((i) => {
        const v = parseFloat(i.achievement25)
        return isNaN(v) ? 0 : Math.min(v, 300)
      })
      const barColors = subIndicators.map((i) => {
        const v = parseFloat(i.achievement25)
        if (isNaN(v) || v === 0) return "#94A3B8"
        if (v >= 100) return "#22C55E"
        if (v >= 70) return "#3B82F6"
        if (v >= 50) return "#EAB308"
        return "#EF4444"
      })

      if (chartRef.current) {
        chart = Highcharts.chart(chartRef.current, {
          chart: {
            type: "bar",
            backgroundColor: "transparent",
            style: { fontFamily: "var(--font-sans), sans-serif" },
            height: Math.max(subIndicators.length * 36 + 80, 200),
          },
          title: { text: undefined },
          xAxis: {
            categories,
            labels: {
              style: { fontSize: "12px", color: "#334155", fontWeight: "500" },
            },
            lineColor: "#e2e8f0",
            tickColor: "transparent",
          },
          yAxis: {
            title: { text: undefined },
            max: 200,
            gridLineColor: "#f1f5f9",
            labels: {
              format: "{value}%",
              style: { color: "#64748b" },
            },
            plotLines: [
              {
                value: 100,
                color: "#94A3B8",
                dashStyle: "Dash" as Highcharts.DashStyleValue,
                width: 1,
              },
            ],
          },
          legend: { enabled: false },
          tooltip: {
            formatter: function (this: Highcharts.TooltipFormatterContextObject) {
              const idx = this.point.index ?? 0
              return `<b>${fullNames[idx]}</b> (${categories[idx]})<br/>'25 달성률: <b>${achievements[idx]}%</b>`
            },
            backgroundColor: "#ffffff",
            borderColor: "#e2e8f0",
            borderRadius: 8,
            shadow: {
              color: "rgba(0,0,0,0.08)",
              offsetX: 0,
              offsetY: 2,
              width: 8,
            },
            style: { fontSize: "12px" },
          },
          plotOptions: {
            bar: {
              borderRadius: 3,
              colorByPoint: true,
              colors: barColors,
              dataLabels: {
                enabled: true,
                format: "{y}%",
                style: {
                  fontSize: "11px",
                  fontWeight: "600",
                  color: "#334155",
                  textOutline: "none",
                },
              },
            },
          },
          series: [
            {
              type: "bar" as const,
              name: "달성률",
              data: achievements,
            },
          ],
          accessibility: { enabled: false },
          credits: { enabled: false },
        })
      }
    }
    init()
    return () => {
      chart?.destroy()
    }
  }, [indicators, fieldColor])

  return <div ref={chartRef} className="w-full" />
}
