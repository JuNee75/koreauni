"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  LayoutDashboard,
  TrendingUp,
  Users,
  FileText,
  BarChart3,
  UserCircle,
  Bell,
} from "lucide-react"
import type { LucideIcon } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { SidebarTrigger } from "@/components/ui/sidebar"

const pageConfig: Record<string, { title: string; icon: LucideIcon }> = {
  "/": { title: "관리자 대시보드", icon: LayoutDashboard },
  "/performance/core": { title: "핵심성과지표", icon: TrendingUp },
  "/performance/autonomous": { title: "자율성과지표", icon: TrendingUp },
  "/research-team": { title: "교육연구단 성과지표", icon: Users },
  "/board/notice": { title: "공지사항 관리", icon: FileText },
  "/board/archive": { title: "자료실 관리", icon: FileText },
  "/competency/diagnosis": { title: "핵심역량 진단관리", icon: BarChart3 },
  "/competency/assessment": { title: "핵심역량 평가관리", icon: BarChart3 },
  "/competency/report": { title: "핵심역량 리포트관리", icon: BarChart3 },
  "/students": { title: "학생정보 관리", icon: UserCircle },
}

export function AdminHeader() {
  const pathname = usePathname()
  const config = pageConfig[pathname] ?? { title: "관리자 대시보드", icon: LayoutDashboard }
  const IconComponent = config.icon

  return (
    <header className="sticky top-0 z-10 flex h-14 shrink-0 items-center justify-between border-b border-border bg-card px-4 md:h-16 md:px-8">
      <div className="flex items-center gap-2 md:gap-3">
        <SidebarTrigger className="h-8 w-8 md:h-9 md:w-9" />
        <h1 className="flex items-center gap-2 text-base font-bold text-foreground md:gap-2.5 md:text-xl">
          <IconComponent className="h-5 w-5 text-primary md:h-6 md:w-6" />
          {config.title}
        </h1>
      </div>

      <div className="flex items-center gap-2 md:gap-3">
        <Link href="/user">
          <Button
            variant="outline"
            size="sm"
            className="hidden text-sm font-medium sm:inline-flex"
          >
            {'사용자모드로 전환'}
          </Button>
        </Link>

        <Button variant="ghost" size="icon" className="relative h-8 w-8 md:h-9 md:w-9">
          <Bell className="h-4 w-4 md:h-5 md:w-5" />
          <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-destructive md:right-2 md:top-2" />
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="flex items-center gap-2 px-2 md:px-3">
              <Avatar className="h-7 w-7 md:h-8 md:w-8">
                <AvatarFallback className="bg-primary text-primary-foreground text-xs font-semibold md:text-sm">
                  {'관'}
                </AvatarFallback>
              </Avatar>
              <div className="hidden flex-col items-start sm:flex">
                <span className="text-sm font-semibold">{'관리자'}</span>
                <span className="text-xs text-muted-foreground">{'admin@korea.ac.kr'}</span>
              </div>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>{'내 계정'}</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem>{'프로필'}</DropdownMenuItem>
            <DropdownMenuItem>{'설정'}</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem>{'로그아웃'}</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}
