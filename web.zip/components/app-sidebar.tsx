"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useState, useEffect } from "react"
import {
  LayoutDashboard,
  TrendingUp,
  Users,
  FileText,
  BarChart3,
  UserCircle,
  ChevronDown,
} from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
} from "@/components/ui/sidebar"

const menuItems = [
  {
    title: "대시보드",
    url: "/",
    icon: LayoutDashboard,
  },
  {
    title: "대학원 성과지표",
    icon: TrendingUp,
    items: [
      { title: "핵심성과지표", url: "/performance/core" },
      { title: "자율성과지표", url: "/performance/autonomous" },
    ],
  },
  {
    title: "교육연구단 성과지표",
    url: "/research-team",
    icon: Users,
  },
  {
    title: "게시판관리",
    icon: FileText,
    items: [
      { title: "공지사항", url: "/board/notice" },
      { title: "자료실", url: "/board/archive" },
    ],
  },
  {
    title: "핵심역량진단",
    icon: BarChart3,
    items: [
      { title: "진단현황", url: "/competency/diagnosis" },
      { title: "버전관리", url: "/competency/version" },
      { title: "설문지관리", url: "/competency/survey" },
    ],
  },
  {
    title: "학생정보",
    url: "/students",
    icon: UserCircle,
  },
]

function CollapsibleMenu({
  item,
  pathname,
}: {
  item: {
    title: string
    icon: React.ComponentType<{ className?: string }>
    items: { title: string; url: string }[]
  }
  pathname: string
}) {
  const isGroupActive = item.items.some((sub) => pathname === sub.url)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    setOpen(isGroupActive)
  }, [isGroupActive])

  const isActive = (url: string) => pathname === url

  return (
    <SidebarMenuItem>
      <SidebarMenuButton
        onClick={() => setOpen(!open)}
        className="h-12 px-4 text-[16px] font-semibold text-sidebar-foreground hover:bg-sidebar-accent rounded-lg"
      >
        <item.icon className="h-5 w-5 shrink-0" />
        <span className="flex-1">{item.title}</span>
        <ChevronDown
          className={`h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200 ${open ? "rotate-180" : ""}`}
        />
      </SidebarMenuButton>
      {open && (
        <SidebarMenuSub className="ml-6 border-l border-sidebar-border pl-4 mt-2 gap-2">
          {item.items.map((subItem) => (
            <SidebarMenuSubItem key={subItem.title}>
              <SidebarMenuSubButton
                asChild
                isActive={isActive(subItem.url)}
                className="h-10 text-[15px] rounded-md"
              >
                <Link href={subItem.url}>
                  <span>{subItem.title}</span>
                </Link>
              </SidebarMenuSubButton>
            </SidebarMenuSubItem>
          ))}
        </SidebarMenuSub>
      )}
    </SidebarMenuItem>
  )
}

export function AppSidebar() {
  const pathname = usePathname()

  const isActive = (url: string) => pathname === url

  return (
    <Sidebar className="border-r border-sidebar-border bg-sidebar">
      <SidebarHeader className="border-b border-sidebar-border px-4 h-14 shrink-0 flex flex-row items-center justify-start md:px-6 md:h-16">
        <div className="relative h-9 w-36">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/images/logo_on.png"
            alt="고려대학교 로고"
            className="h-full w-auto object-contain"
          />
        </div>
      </SidebarHeader>

      <SidebarContent className="px-3 py-6">
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu className="gap-3">
              {menuItems.map((item) => {
                if (item.items) {
                  return (
                    <CollapsibleMenu
                      key={item.title}
                      item={item as { title: string; icon: React.ComponentType<{ className?: string }>; items: { title: string; url: string }[] }}
                      pathname={pathname}
                    />
                  )
                }
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton
                      asChild
                      isActive={isActive(item.url!)}
                      className="h-12 px-4 text-[16px] font-semibold text-sidebar-foreground hover:bg-sidebar-accent rounded-lg"
                    >
                      <Link href={item.url!}>
                        {item.icon && <item.icon className="h-5 w-5 shrink-0" />}
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                )
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  )
}
