'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Sparkles, TrendingUp, Target, Lightbulb, CheckCircle2 } from 'lucide-react'

export interface StudentProfileAnalysisProps {
  studentName: string
  department: string
  program: string
  academicStats: {
    avgGpa: string
    totalCredits: number
    paperCount: number
    presentationCount: number
    awardCount: number
  }
  competencyScores: {
    learningResearch: number
    convergenceResearch: number
  }
}

export function StudentAIProfileAnalysis({ 
  studentName, 
  department,
  program,
  academicStats,
  competencyScores 
}: StudentProfileAnalysisProps) {
  const totalScore = Math.round((competencyScores.learningResearch + competencyScores.convergenceResearch) / 2)
  
  // AI 프로필 분석 생성
  const getProfileAnalysis = () => {
    const insights = []
    
    // 학업 성과 분석
    if (parseFloat(academicStats.avgGpa) >= 3.8) {
      insights.push({
        category: '학업 성취',
        icon: CheckCircle2,
        text: `GPA ${academicStats.avgGpa}로 우수한 학업 성과를 유지 중입니다. 안정적인 학습 역량이 돋보입니다.`,
        color: 'text-green-600',
        bgColor: 'bg-green-50'
      })
    } else if (parseFloat(academicStats.avgGpa) >= 3.5) {
      insights.push({
        category: '학업 성취',
        icon: CheckCircle2,
        text: `GPA ${academicStats.avgGpa}로 일관된 학업 성과를 보이고 있습니다. 기초 역량이 안정적입니다.`,
        color: 'text-blue-600',
        bgColor: 'bg-blue-50'
      })
    }
    
    // 연구 활동 분석
    if (academicStats.paperCount > 0) {
      insights.push({
        category: '연구 활동',
        icon: TrendingUp,
        text: `${academicStats.paperCount}편의 논문 발표로 능동적인 연구 활동을 진행 중입니다. 학술 기여도가 높습니다.`,
        color: 'text-blue-600',
        bgColor: 'bg-blue-50'
      })
    }
    
    if (academicStats.awardCount > 0) {
      insights.push({
        category: '학술 성과',
        icon: Lightbulb,
        text: `${academicStats.awardCount}건의 수상으로 연구 우수성을 인정받았습니다. 경쟁력 있는 연구자입니다.`,
        color: 'text-amber-600',
        bgColor: 'bg-amber-50'
      })
    }
    
    // 역량 분석
    if (competencyScores.learningResearch > 75) {
      insights.push({
        category: '핵심 역량',
        icon: Target,
        text: `학습연구역량(${competencyScores.learningResearch}점)이 우수하여 자기주도적 학습과 연구 수행 능력이 강합니다.`,
        color: 'text-emerald-600',
        bgColor: 'bg-emerald-50'
      })
    }
    
    if (competencyScores.convergenceResearch >= 65 && competencyScores.convergenceResearch < 75) {
      insights.push({
        category: '개발 영역',
        icon: Lightbulb,
        text: `융합연구역량(${competencyScores.convergenceResearch}점)을 지속적으로 발전시키면 더욱 혁신적인 연구자로 성장할 수 있습니다.`,
        color: 'text-amber-600',
        bgColor: 'bg-amber-50'
      })
    }
    
    return insights
  }
  
  const analysis = getProfileAnalysis()
  
  return (
    <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-indigo-50">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-blue-600" />
          <CardTitle className="text-lg">AI가 분석한 프로필</CardTitle>
        </div>
        <p className="text-sm text-gray-600 mt-2">
          {studentName}님의 학업 성과, 연구 활동, 핵심역량을 기반으로 종합 분석한 결과입니다.
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* 종합 점수 */}
        <div className="rounded-lg bg-white p-4 border border-blue-100">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <h4 className="font-semibold text-gray-900">역량 종합 평가</h4>
              <Badge className="bg-blue-100 text-blue-700">{department}</Badge>
            </div>
            <div className="text-right">
              <p className="text-3xl font-bold text-blue-600">{totalScore}</p>
              <p className="text-xs text-gray-500">/ 100</p>
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between items-center text-sm">
              <span className="text-gray-700">학습연구역량</span>
              <span className="font-semibold text-gray-900">{competencyScores.learningResearch}점</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-green-500 h-2 rounded-full transition-all"
                style={{ width: `${(competencyScores.learningResearch / 100) * 100}%` }}
              ></div>
            </div>
          </div>
          <div className="space-y-2 mt-3">
            <div className="flex justify-between items-center text-sm">
              <span className="text-gray-700">융합연구역량</span>
              <span className="font-semibold text-gray-900">{competencyScores.convergenceResearch}점</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-purple-500 h-2 rounded-full transition-all"
                style={{ width: `${(competencyScores.convergenceResearch / 100) * 100}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* AI 분석 인사이트 */}
        <div className="space-y-3">
          {analysis.map((insight, idx) => {
            const Icon = insight.icon
            return (
              <div key={idx} className={`rounded-lg ${insight.bgColor} p-3 border-l-4 border-l-${insight.color.split('-')[1]}-600`}>
                <div className="flex gap-3">
                  <Icon className={`h-5 w-5 flex-shrink-0 mt-0.5 ${insight.color}`} />
                  <div>
                    <p className={`text-sm font-semibold ${insight.color} mb-0.5`}>{insight.category}</p>
                    <p className="text-sm text-gray-700">{insight.text}</p>
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        {/* 추천 메시지 */}
        <div className="rounded-lg bg-white p-3 border border-blue-100 text-sm text-gray-700 italic">
          💡 {studentName}님의 {program} 과정에서의 노력이 두드러집니다. 
          현재의 학업 성과를 바탕으로 융합 역량을 지속적으로 개발한다면 더욱 경쟁력 있는 연구자로 성장할 것으로 예상됩니다.
        </div>
      </CardContent>
    </Card>
  )
}
