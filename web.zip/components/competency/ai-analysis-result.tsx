'use client'

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Zap, AlertCircle, CheckCircle2, Target, BookOpen, Users, Lightbulb } from "lucide-react"

interface CompetencyScore {
  name: string
  score: number
  level: string
}

interface AIAnalysisProps {
  studentName: string
  competencies: CompetencyScore[]
  detailedData: {
    competencies: {
      name: string
      score: number
      level: string
      categories: {
        name: string
        score: number
        subCategories: {
          name: string
          score: number
          level: string
          interpretation: string
        }[]
      }[]
    }[]
  }
  departmentAverage: { name: string; score: number }[]
}

export function AIAnalysisResult({ studentName, competencies, detailedData, departmentAverage }: AIAnalysisProps) {
  // 총점 계산
  const avgScore = Math.round(
    competencies.reduce((sum, comp) => sum + comp.score, 0) / competencies.length
  )

  // 학과 평균 계산
  const deptAvgScore = departmentAverage.length > 0 
    ? Math.round(departmentAverage.reduce((sum, comp) => sum + comp.score, 0) / departmentAverage.length)
    : 74

  // 강점 역량 추출 (80점 이상) 및 점수 포함
  const strengths = detailedData.competencies
    .flatMap(comp => 
      comp.categories
        .filter(cat => cat.score >= 80)
        .map(cat => ({
          competency: comp.name,
          category: cat.name,
          score: cat.score,
          interpretation: cat.subCategories[0]?.interpretation || "우수한 역량"
        }))
    )
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)

  // 개선 필요 카테고리 (70점 미만) 및 점수 포함
  const improvements = detailedData.competencies
    .flatMap(comp => 
      comp.categories
        .filter(cat => cat.score < 70)
        .map(cat => ({
          competency: comp.name,
          category: cat.name,
          score: cat.score,
          subCategories: cat.subCategories,
          interpretation: cat.subCategories[0]?.interpretation || ""
        }))
    )
    .sort((a, b) => a.score - b.score)
    .slice(0, 3)

  // 전체 역량별 취약점 개수
  const improvementsByCompetency = detailedData.competencies.map(comp => ({
    name: comp.name,
    score: comp.score,
    weakCount: comp.categories.filter(cat => cat.score < 70).length,
    categories: comp.categories.filter(cat => cat.score < 70)
  }))

  // 월별 상담 포인트
  const counselingPoints = [
    {
      month: "1개월",
      focus: "문제 인식 및 목표 설정",
      actions: [
        "학과 평균 대비 역량 격차 분석 및 이해",
        "개선 필요 영역의 우선순위 결정",
        "SMART 목표 수립 (구체적, 측정가능, 달성가능, 관련성, 시간제한)"
      ]
    },
    {
      month: "2-3개월",
      focus: "역량 개발 활동 시작",
      actions: [
        "크로스 디시플린 워크샵 참여 (다학제간 통찰 강화)",
        "창의성 개발 프로그램 (독창적 발상, 창의적 사고)",
        "논리적 사고 훈련 (분석적 문제해결 역량)"
      ]
    },
    {
      month: "4-6개월",
      focus: "협력 및 리더십 강화",
      actions: [
        "팀 프로젝트 주도적 참여 (협력설계, 프로세스 관리)",
        "멘토링 프로그램 참여 (성장지원, 다양성 존중)",
        "월간 진행도 점검 및 피드백 반영"
      ]
    }
  ]

  const getLevelColor = (level: string) => {
    switch (level) {
      case "탁월": return "bg-green-100 text-green-700"
      case "우수": return "bg-blue-100 text-blue-700"
      case "보통": return "bg-yellow-100 text-yellow-700"
      case "개선필요": return "bg-red-100 text-red-700"
      default: return "bg-gray-100 text-gray-700"
    }
  }

  return (
    <div className="space-y-6">
      {/* 종합 평가 영역 */}
      <Card className="border-l-4 border-l-blue-500 bg-gradient-to-r from-blue-50 to-transparent">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-blue-600" />
                AI 분석결과
              </CardTitle>
              <p className="text-sm text-muted-foreground mt-1">{studentName} 학생의 핵심역량진단 분석 결과입니다.</p>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold text-blue-600">{avgScore}</div>
              <p className="text-sm text-muted-foreground">평균점수</p>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* 학과 평균 대비 */}
            <div className="p-3 bg-white rounded-lg border">
              <p className="text-xs font-medium text-muted-foreground mb-1">학과 평균 대비</p>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-bold text-blue-600">{avgScore - deptAvgScore > 0 ? '+' : ''}{avgScore - deptAvgScore}</span>
                <span className="text-sm text-muted-foreground">(학과평균: {deptAvgScore}점)</span>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                {avgScore >= deptAvgScore 
                  ? "학과 평균 이상의 역량을 보유하고 있습니다." 
                  : "학과 평균 이하이며 개선이 필요합니다."}
              </p>
            </div>

            {/* 강점 역량 */}
            <div className="p-3 bg-white rounded-lg border">
              <p className="text-xs font-medium text-muted-foreground mb-2">강점 역량</p>
              <div className="space-y-1">
                {strengths.length > 0 ? (
                  strengths.map((s, idx) => (
                    <div key={idx} className="flex items-center justify-between">
                      <span className="text-sm">{s.category}</span>
                      <Badge className="bg-green-100 text-green-700 hover:bg-green-100">{s.score}점</Badge>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-muted-foreground">현재 80점 이상의 역량이 없습니다.</p>
                )}
              </div>
            </div>

            {/* 개선 필요 */}
            <div className="p-3 bg-white rounded-lg border">
              <p className="text-xs font-medium text-muted-foreground mb-2">개선 필요 (70점 미만)</p>
              <div className="space-y-1">
                {improvements.length > 0 ? (
                  improvements.map((imp, idx) => (
                    <div key={idx} className="flex items-center justify-between">
                      <span className="text-sm">{imp.category}</span>
                      <Badge className="bg-red-100 text-red-700 hover:bg-red-100">{imp.score}점</Badge>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-muted-foreground">개선 필요 영역이 없습니다.</p>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 개선 전략 분석 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-orange-600" />
            개선 필요 영역 분석
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {improvementsByCompetency.filter(c => c.weakCount > 0).map((comp, idx) => (
              <div key={idx} className="p-3 bg-orange-50 rounded-lg border border-orange-200">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h4 className="font-medium text-sm">{comp.name}</h4>
                    <p className="text-xs text-muted-foreground mt-1">총점: {comp.score}점 | 취약 영역: {comp.weakCount}개</p>
                  </div>
                  <Badge className={getLevelColor(comp.score < 70 ? "개선필요" : "보통")}>
                    {comp.score < 70 ? "개선필요" : "보통"}
                  </Badge>
                </div>
                <div className="pl-0">
                  <p className="text-xs font-medium text-muted-foreground mb-2">주요 취약 영역:</p>
                  <ul className="space-y-1">
                    {comp.categories.slice(0, 2).map((cat, cidx) => (
                      <li key={cidx} className="text-xs flex items-start gap-2">
                        <span className="text-orange-600 mt-0.5">•</span>
                        <span>
                          <strong>{cat.name}</strong> ({cat.score}점): {cat.subCategories[0]?.interpretation || ""}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* 학생상담 가이드 */}
      <Card className="bg-gradient-to-r from-indigo-50 to-transparent border-l-4 border-l-indigo-500">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5 text-indigo-600" />
            교수님 상담 가이드
          </CardTitle>
          <p className="text-sm text-muted-foreground mt-2">
            {studentName} 학생의 역량 발전을 위한 단계별 상담 전략입니다.
          </p>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {counselingPoints.map((point, idx) => (
              <div key={idx} className="p-4 bg-white rounded-lg border-l-4 border-l-indigo-400">
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0">
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-indigo-100">
                      <span className="text-sm font-bold text-indigo-600">{idx + 1}</span>
                    </div>
                  </div>
                  <div className="flex-grow">
                    <h4 className="font-medium text-sm">{point.month} - {point.focus}</h4>
                    <ul className="mt-2 space-y-1">
                      {point.actions.map((action, aidx) => (
                        <li key={aidx} className="text-xs text-muted-foreground flex items-start gap-2">
                          <span className="text-indigo-400 mt-0.5">→</span>
                          <span>{action}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* 상담 권고사항 */}
          <div className="mt-6 p-4 bg-indigo-50 rounded-lg">
            <h4 className="font-medium text-sm mb-3 flex items-center gap-2">
              <Lightbulb className="w-4 h-4 text-indigo-600" />
              상담 권고사항
            </h4>
            <ul className="space-y-2 text-xs text-muted-foreground">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                <span>월 2회 이상의 개인 상담을 통해 진행도 점검 및 피드백 제공</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                <span>취약 영역별 온라인 강좌 및 워크숍 참여 권장</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                <span>고학년 우수 연구자와의 멘토링 프로그램 연결</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                <span>팀 프로젝트 주도적 참여를 통한 협력 및 리더십 역량 발전</span>
              </li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
