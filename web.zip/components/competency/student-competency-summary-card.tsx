'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'
import { TrendingUp, ArrowRight } from 'lucide-react'
import Link from 'next/link'

export interface CompetencySummaryCardProps {
  competencies: {
    name: string
    score: number
    level: string
  }[]
  departmentAverage: { name: string; score: number }[]
}

const levelColors: Record<string, string> = {
  '탁월': 'bg-green-100 text-green-800',
  '우수': 'bg-blue-100 text-blue-800',
  '보통': 'bg-amber-100 text-amber-800',
  '개선필요': 'bg-red-100 text-red-800',
}

export function StudentCompetencySummaryCard({ 
  competencies, 
  departmentAverage 
}: CompetencySummaryCardProps) {
  const comparisonData = competencies.map((comp, idx) => ({
    name: comp.name.substring(0, 4),
    '당신': comp.score,
    '학과평균': departmentAverage[idx]?.score || 0,
  }))

  const strengths = competencies.filter(c => c.score >= 75)
  const improvements = competencies.filter(c => c.score < 65)

  return (
    <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-purple-600" />
            <CardTitle className="text-lg">역량 진단 결과 요약</CardTitle>
          </div>
          <Link href="/user/competency-result">
            <Button size="sm" variant="outline" className="gap-1">
              상세보기
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* 역량 점수 비교 */}
        <div>
          <p className="text-sm font-semibold text-gray-700 mb-3">역량별 점수 비교</p>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={comparisonData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="name" />
              <YAxis domain={[0, 100]} />
              <Tooltip />
              <Bar dataKey="당신" fill="#a855f7" />
              <Bar dataKey="학과평균" fill="#e5e7eb" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* 강점과 개선영역 */}
        <div className="grid grid-cols-2 gap-3">
          {/* 강점 */}
          <div className="rounded-lg bg-green-50 p-3 border border-green-200">
            <p className="text-xs font-semibold text-green-700 mb-2">강점 영역</p>
            <div className="space-y-1">
              {strengths.length > 0 ? (
                strengths.map((comp, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs">
                    <span className="text-gray-700">{comp.name}</span>
                    <span className="font-semibold text-green-700">{comp.score}점</span>
                  </div>
                ))
              ) : (
                <p className="text-xs text-gray-600">강점 영역 없음</p>
              )}
            </div>
          </div>

          {/* 개선영역 */}
          <div className="rounded-lg bg-amber-50 p-3 border border-amber-200">
            <p className="text-xs font-semibold text-amber-700 mb-2">개선 영역</p>
            <div className="space-y-1">
              {improvements.length > 0 ? (
                improvements.map((comp, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs">
                    <span className="text-gray-700">{comp.name}</span>
                    <span className="font-semibold text-amber-700">{comp.score}점</span>
                  </div>
                ))
              ) : (
                <p className="text-xs text-gray-600">개선 영역 없음</p>
              )}
            </div>
          </div>
        </div>

        {/* 역량 상태 배지 */}
        <div className="flex flex-wrap gap-2">
          {competencies.map((comp, idx) => (
            <Badge key={idx} className={levelColors[comp.level]}>
              {comp.name} {comp.score}점
            </Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
