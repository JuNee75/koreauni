'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Lightbulb, TrendingUp, Focus, Target, AlertCircle } from 'lucide-react'

export interface StudentCompetencyData {
  name: string
  competencies: {
    name: string
    score: number
    level: string
    categories: {
      name: string
      score: number
    }[]
  }[]
  departmentAverage: { name: string; score: number }[]
  schoolAverage: { name: string; score: number }[]
}

export function StudentAIAnalysis({ data }: { data: StudentCompetencyData }) {
  // 역량별 분석 생성
  const generateCompetencyAnalysis = () => {
    const learningResearch = data.competencies[0]
    const convergenceResearch = data.competencies[1]
    
    const learningDeptAvg = data.departmentAverage[0]?.score || 0
    const convergenceDeptAvg = data.departmentAverage[1]?.score || 0
    
    const learningSchoolAvg = data.schoolAverage[0]?.score || 0
    const convergenceSchoolAvg = data.schoolAverage[1]?.score || 0
    
    return {
      learningResearch,
      convergenceResearch,
      learningDeptAvg,
      convergenceDeptAvg,
      learningSchoolAvg,
      convergenceSchoolAvg,
    }
  }

  const analysis = generateCompetencyAnalysis()

  // 학생의 위치 파악
  const isLearningAboveDept = analysis.learningResearch.score >= analysis.learningDeptAvg
  const isConvergenceAboveDept = analysis.convergenceResearch.score >= analysis.convergenceDeptAvg
  const isLearningAboveSchool = analysis.learningResearch.score >= analysis.learningSchoolAvg
  const isConvergenceAboveSchool = analysis.convergenceResearch.score >= analysis.convergenceSchoolAvg

  return (
    <div className="space-y-4">
      {/* 전체 평가 요약 */}
      <Card className="border-blue-200 bg-blue-50">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-blue-600" />
            <CardTitle className="text-base">당신의 역량 진단 분석</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-gray-700">
            진단 결과를 통해 당신의 현재 위치를 객관적으로 파악하는 것이 성장의 첫 단계입니다.
            아래 분석을 통해 자신의 강점과 개선 영역을 인식하고, 구체적인 행동변화를 계획해보세요.
          </p>
        </CardContent>
      </Card>

      {/* 역량별 비교 분석 */}
      <div className="space-y-3">
        <h3 className="font-semibold text-gray-900">역량별 진단 위치</h3>
        
        {/* 학습연구역량 */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-blue-600"></div>
                <CardTitle className="text-sm">{analysis.learningResearch.name}</CardTitle>
              </div>
              <Badge variant="outline">{analysis.learningResearch.score}점</Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="grid grid-cols-2 gap-2">
              <div className="rounded-lg bg-gray-50 p-3">
                <p className="text-xs font-medium text-gray-600">학과 평균</p>
                <p className="text-lg font-semibold text-gray-900">{analysis.learningDeptAvg}점</p>
                {isLearningAboveDept ? (
                  <p className="mt-1 text-xs text-green-600 font-medium">✓ 평균 이상</p>
                ) : (
                  <p className="mt-1 text-xs text-amber-600 font-medium">∧ 개선 기회</p>
                )}
              </div>
              <div className="rounded-lg bg-gray-50 p-3">
                <p className="text-xs font-medium text-gray-600">학교 평균</p>
                <p className="text-lg font-semibold text-gray-900">{analysis.learningSchoolAvg}점</p>
                {isLearningAboveSchool ? (
                  <p className="mt-1 text-xs text-green-600 font-medium">✓ 평균 이상</p>
                ) : (
                  <p className="mt-1 text-xs text-amber-600 font-medium">∧ 개선 기회</p>
                )}
              </div>
            </div>
            <div className="border-t pt-2">
              <p className="text-xs text-gray-700">
                {isLearningAboveDept && isLearningAboveSchool
                  ? '학습과 연구에 대한 기초 역량이 우수합니다. 이를 바탕으로 더욱 깊이 있는 연구 경험을 쌓아보세요.'
                  : isLearningAboveDept
                  ? '학과 평균은 충족하나, 학교 평균과의 격차를 줄이기 위해 자기주도학습과 연구 역량 개발에 집중하세요.'
                  : '학습과 연구 역량이 평균보다 낮습니다. 효율적인 학습 방법 개선과 단계별 목표 설정으로 기초를 다져보세요.'}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* 융합연구역량 */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-purple-600"></div>
                <CardTitle className="text-sm">{analysis.convergenceResearch.name}</CardTitle>
              </div>
              <Badge variant="outline">{analysis.convergenceResearch.score}점</Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="grid grid-cols-2 gap-2">
              <div className="rounded-lg bg-gray-50 p-3">
                <p className="text-xs font-medium text-gray-600">학과 평균</p>
                <p className="text-lg font-semibold text-gray-900">{analysis.convergenceDeptAvg}점</p>
                {isConvergenceAboveDept ? (
                  <p className="mt-1 text-xs text-green-600 font-medium">✓ 평균 이상</p>
                ) : (
                  <p className="mt-1 text-xs text-amber-600 font-medium">∧ 개선 기회</p>
                )}
              </div>
              <div className="rounded-lg bg-gray-50 p-3">
                <p className="text-xs font-medium text-gray-600">학교 평균</p>
                <p className="text-lg font-semibold text-gray-900">{analysis.convergenceSchoolAvg}점</p>
                {isConvergenceAboveSchool ? (
                  <p className="mt-1 text-xs text-green-600 font-medium">✓ 평균 이상</p>
                ) : (
                  <p className="mt-1 text-xs text-amber-600 font-medium">∧ 개선 기회</p>
                )}
              </div>
            </div>
            <div className="border-t pt-2">
              <p className="text-xs text-gray-700">
                {isConvergenceAboveDept && isConvergenceAboveSchool
                  ? '창의적 사고와 협력 능력이 뛰어납니다. 이러한 역량을 활용하여 새로운 분야와의 융합 연구를 시도해보세요.'
                  : isConvergenceAboveDept
                  ? '학과 동료들과 비교하면 충분하지만, 더 넓은 시각으로 다른 분야의 관점을 익혀보세요.'
                  : '창의성과 협력 역량 개발이 필요합니다. 다학제 워크숍 참여, 새로운 관점 학습 등을 통해 역량을 키워보세요.'}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 개선을 위한 조언 */}
      <Card className="border-orange-200 bg-orange-50">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Focus className="h-5 w-5 text-orange-600" />
            <CardTitle className="text-base">개선을 위한 조언</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex gap-3">
              <Target className="h-4 w-4 flex-shrink-0 text-orange-600 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-gray-900">현재 위치 정확히 이해하기</p>
                <p className="mt-1 text-xs text-gray-700">
                  학과 및 학교 평균과 비교하여 자신의 상대적 위치를 객관적으로 파악하세요.
                  "내가 약한 영역"이 아닌 "우리 학과/학교 기준에서 개선이 필요한 영역"으로 인식하는 것이 중요합니다.
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <TrendingUp className="h-4 w-4 flex-shrink-0 text-orange-600 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-gray-900">구체적인 행동 계획 수립</p>
                <p className="mt-1 text-xs text-gray-700">
                  약점 개선을 위해 "월별 목표 설정 → 실행 → 점검" 사이클을 반복하세요.
                  담당 교수님과 상담하여 맞춤형 멘토링을 받는 것을 권장합니다.
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <AlertCircle className="h-4 w-4 flex-shrink-0 text-orange-600 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-gray-900">강점 활용하여 약점 보완</p>
                <p className="mt-1 text-xs text-gray-700">
                  우수한 영역의 경험과 방법론을 약한 영역에 적용해보세요.
                  예를 들어, 성공한 학습 방법이나 팀 협력 경험을 다른 영역에 전이시킬 수 있습니다.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 반성 질문 */}
      <Card className="border-green-200 bg-green-50">
        <CardHeader>
          <CardTitle className="text-base">스스로에게 던지는 질문</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-sm">
            <li className="flex gap-2">
              <span className="text-green-600 font-bold">1.</span>
              <span className="text-gray-700">
                내가 강점으로 평가받은 영역에서 나의 구체적인 성공 경험은 무엇인가?
              </span>
            </li>
            <li className="flex gap-2">
              <span className="text-green-600 font-bold">2.</span>
              <span className="text-gray-700">
                개선이 필요한 영역에서 지금까지 시도했던 노력은 무엇이었나?
              </span>
            </li>
            <li className="flex gap-2">
              <span className="text-green-600 font-bold">3.</span>
              <span className="text-gray-700">
                나의 강점 역량을 약점 개선에 어떻게 활용할 수 있을까?
              </span>
            </li>
            <li className="flex gap-2">
              <span className="text-green-600 font-bold">4.</span>
              <span className="text-gray-700">
                3개월 후 나는 어느 정도 수준에 도달하고 싶은가?
              </span>
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}
