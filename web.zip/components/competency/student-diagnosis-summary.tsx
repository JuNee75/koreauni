'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'

export interface StudentSummaryData {
  studentName: string
  competencies: {
    name: string
    score: number
    level: string
    categories: {
      name: string
      score: number
      level: string
    }[]
  }[]
  departmentAverage: { name: string; score: number }[]
}

const COLORS = ['#2563eb', '#dc2626', '#f59e0b']
const levelColors: Record<string, string> = {
  '탁월': 'bg-green-100 text-green-800',
  '우수': 'bg-blue-100 text-blue-800',
  '보통': 'bg-amber-100 text-amber-800',
  '개선필요': 'bg-red-100 text-red-800',
}

export function StudentDiagnosisSummary({ data }: { data: StudentSummaryData }) {
  // 총점 계산
  const totalScore = Math.round(
    data.competencies.reduce((sum, comp) => sum + comp.score, 0) / data.competencies.length
  )

  // 비교 데이터 준비
  const comparisonData = data.competencies.map((comp, idx) => ({
    name: comp.name,
    '당신': comp.score,
    '학과평균': data.departmentAverage[idx]?.score || 0,
  }))

  // 카테고리별 분포
  const categoryDistribution = data.competencies.flatMap(comp =>
    comp.categories.map(cat => ({
      name: cat.name,
      score: cat.score,
      competency: comp.name,
    }))
  )

  // 강점 영역 (75점 이상)
  const strengths = categoryDistribution.filter(cat => cat.score >= 75)
  // 개선 영역 (65점 미만)
  const improvements = categoryDistribution.filter(cat => cat.score < 65)

  return (
    <div className="space-y-6">
      {/* 헤더 */}
      <Card className="border-blue-200 bg-gradient-to-r from-blue-50 to-blue-100">
        <CardHeader>
          <div className="space-y-2">
            <CardTitle className="text-xl">{data.studentName}님의 역량 진단 결과</CardTitle>
            <p className="text-sm text-gray-600">설문 참여를 통해 분석된 당신의 핵심역량 프로필입니다</p>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4 md:grid-cols-4">
            <div className="rounded-lg bg-white p-3 text-center">
              <p className="text-2xl font-bold text-blue-600">{totalScore}</p>
              <p className="text-xs font-medium text-gray-600 mt-1">종합 점수</p>
            </div>
            {data.competencies.map((comp, idx) => (
              <div key={idx} className="rounded-lg bg-white p-3 text-center">
                <p className="text-xl font-bold text-gray-900">{comp.score}</p>
                <p className="text-xs font-medium text-gray-600 mt-1 truncate">{comp.name}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* 핵심역량 비교 */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">당신 vs 학과 평균 비교</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={comparisonData} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis domain={[0, 100]} />
              <Tooltip />
              <Legend />
              <Bar dataKey="당신" fill="#2563eb" />
              <Bar dataKey="학과평균" fill="#e5e7eb" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* 역량 상세 분석 */}
      <div className="grid gap-4 md:grid-cols-2">
        {data.competencies.map((comp, idx) => (
          <Card key={idx}>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm">{comp.name}</CardTitle>
                <Badge className={levelColors[comp.level]}>{comp.level}</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">{comp.score}점</span>
                  <span className="text-xs text-gray-500">
                    {data.departmentAverage[idx] && `학과평균: ${data.departmentAverage[idx].score}점`}
                  </span>
                </div>
                <Progress value={(comp.score / 100) * 100} className="h-2" />
              </div>
              <div className="space-y-2">
                {comp.categories.slice(0, 4).map((cat, catIdx) => (
                  <div key={catIdx} className="flex items-center justify-between text-xs">
                    <span className="text-gray-700">{cat.name}</span>
                    <span className="font-medium text-gray-900">{cat.score}점</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* 강점 분석 */}
      {strengths.length > 0 && (
        <Card className="border-green-200 bg-green-50">
          <CardHeader>
            <CardTitle className="text-base text-green-900">당신의 강점 영역</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {strengths.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between rounded-lg bg-white p-2">
                  <div>
                    <p className="text-sm font-medium text-gray-900">{item.name}</p>
                    <p className="text-xs text-gray-500">{item.competency}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-green-600">{item.score}</p>
                    <p className="text-xs text-green-600 font-medium">우수</p>
                  </div>
                </div>
              ))}
            </div>
            <p className="mt-3 text-xs text-green-800">
              ✓ 이 영역의 역량을 더욱 발전시키고, 다른 영역에 적극 활용해보세요.
            </p>
          </CardContent>
        </Card>
      )}

      {/* 개선 영역 */}
      {improvements.length > 0 && (
        <Card className="border-amber-200 bg-amber-50">
          <CardHeader>
            <CardTitle className="text-base text-amber-900">개선이 필요한 영역</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {improvements.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between rounded-lg bg-white p-2">
                  <div>
                    <p className="text-sm font-medium text-gray-900">{item.name}</p>
                    <p className="text-xs text-gray-500">{item.competency}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-amber-600">{item.score}</p>
                    <p className="text-xs text-amber-600 font-medium">개선필요</p>
                  </div>
                </div>
              ))}
            </div>
            <p className="mt-3 text-xs text-amber-800">
              ✓ 구체적인 개선 계획을 수립하고, 담당 교수님과 상담하여 멘토링을 받으세요.
            </p>
          </CardContent>
        </Card>
      )}

      {/* 다음 단계 안내 */}
      <Card className="border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="text-base">다음 단계</CardTitle>
        </CardHeader>
        <CardContent>
          <ol className="space-y-2 text-sm">
            <li className="flex gap-2">
              <span className="font-bold text-blue-600">1단계:</span>
              <span>위의 AI 역량분석을 통해 당신의 현재 위치를 정확히 파악하세요</span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-blue-600">2단계:</span>
              <span>담당 교수님과 상담하여 3개월 단기 목표를 수립하세요</span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-blue-600">3단계:</span>
              <span>월별 진행도를 점검하고, 필요시 계획을 조정하세요</span>
            </li>
            <li className="flex gap-2">
              <span className="font-bold text-blue-600">4단계:</span>
              <span>3개월 후 재진단을 통해 발전도를 확인하세요</span>
            </li>
          </ol>
        </CardContent>
      </Card>
    </div>
  )
}
