'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Label } from '@/components/ui/label'
import { ArrowRight, CheckCircle2, Circle, AlertCircle } from 'lucide-react'
import { Progress } from '@/components/ui/progress'

interface SurveyQuestion {
  id: string
  text: string
  options: { value: string; label: string }[]
}

interface CompetencyCategory {
  id: string
  name: string
  questions: SurveyQuestion[]
}

interface Competency {
  id: string
  name: string
  categories: CompetencyCategory[]
  selected: boolean
  participationPeriod?: {
    startDate: string
    endDate: string
  }
}

interface SurveyParticipationProps {
  competencies: Competency[]
  onSubmit: (responses: Record<string, string>) => void
}

export function SurveyParticipation({ competencies, onSubmit }: SurveyParticipationProps) {
  const [selectedCompetencies, setSelectedCompetencies] = useState<string[]>([])
  const [currentCompetencyIndex, setCurrentCompetencyIndex] = useState(0)
  const [responses, setResponses] = useState<Record<string, string>>({})
  const [stage, setStage] = useState<'selection' | 'survey'>('selection')

  const currentCompetency = competencies.find(c => c.id === selectedCompetencies[currentCompetencyIndex])
  const totalQuestions = selectedCompetencies.reduce((sum, id) => {
    const comp = competencies.find(c => c.id === id)
    return sum + (comp?.categories.reduce((catSum, cat) => catSum + cat.questions.length, 0) || 0)
  }, 0)
  const answeredQuestions = Object.keys(responses).length
  const progressPercent = totalQuestions > 0 ? Math.round((answeredQuestions / totalQuestions) * 100) : 0

  const handleCompetencyToggle = (competencyId: string) => {
    setSelectedCompetencies(prev => {
      if (prev.includes(competencyId)) {
        return prev.filter(id => id !== competencyId)
      } else {
        return [...prev, competencyId]
      }
    })
  }

  const handleStartSurvey = () => {
    if (selectedCompetencies.length === 0) return
    setStage('survey')
  }

  const handleAnswer = (questionId: string, answer: string) => {
    setResponses(prev => ({
      ...prev,
      [questionId]: answer,
    }))
  }

  const handleNext = () => {
    if (currentCompetencyIndex < selectedCompetencies.length - 1) {
      setCurrentCompetencyIndex(prev => prev + 1)
    }
  }

  const handlePrev = () => {
    if (currentCompetencyIndex > 0) {
      setCurrentCompetencyIndex(prev => prev - 1)
    }
  }

  const handleSubmit = () => {
    onSubmit(responses)
  }

  if (stage === 'selection') {
    return (
      <div className="space-y-6">
        {/* 헤더 */}
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-gray-900">핵심역량진단 설문</h1>
          <p className="text-gray-600">
            참여하실 역량을 선택하고 설문을 진행해주세요.
            선택된 역량의 설문만 참여하시면 됩니다.
          </p>
        </div>

        {/* 역량 선택 */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">참여할 역량 선택</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {competencies.map(competency => (
              <div
                key={competency.id}
                onClick={() => handleCompetencyToggle(competency.id)}
                className={`relative flex items-start gap-4 p-4 rounded-lg border-2 transition-all cursor-pointer ${
                  selectedCompetencies.includes(competency.id)
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 bg-white hover:border-gray-300'
                }`}
              >
                {/* 체크 박스 */}
                <div className="flex-shrink-0 mt-1">
                  {selectedCompetencies.includes(competency.id) ? (
                    <CheckCircle2 className="h-6 w-6 text-blue-600" />
                  ) : (
                    <Circle className="h-6 w-6 text-gray-300" />
                  )}
                </div>

                {/* 내용 */}
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-gray-900">{competency.name}</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    {competency.categories.length}개 카테고리 •{' '}
                    {competency.categories.reduce((sum, cat) => sum + cat.questions.length, 0)}개 문항
                  </p>
                  {competency.participationPeriod && (
                    <p className="text-xs text-gray-500 mt-2 flex items-center gap-1">
                      <span className="inline-block w-1 h-1 bg-gray-400 rounded-full"></span>
                      참여기간: {competency.participationPeriod.startDate} ~ {competency.participationPeriod.endDate}
                    </p>
                  )}
                </div>

                {/* 배지 */}
                {selectedCompetencies.includes(competency.id) && (
                  <Badge className="bg-blue-600 text-white flex-shrink-0">선택됨</Badge>
                )}
              </div>
            ))}
          </CardContent>
        </Card>

        {/* 안내 메시지 */}
        {selectedCompetencies.length === 0 && (
          <div className="flex gap-3 p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <AlertCircle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-amber-800">
              최소 1개 이상의 역량을 선택해주세요.
            </p>
          </div>
        )}

        {/* 선택 요약 */}
        {selectedCompetencies.length > 0 && (
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="pt-6">
              <p className="text-sm text-gray-700 mb-2">
                <span className="font-semibold">{selectedCompetencies.length}개 역량</span>이 선택되었습니다.
              </p>
              <div className="flex flex-wrap gap-2">
                {selectedCompetencies.map(id => {
                  const comp = competencies.find(c => c.id === id)
                  return (
                    <Badge key={id} className="bg-blue-600 text-white">
                      {comp?.name}
                    </Badge>
                  )
                })}
              </div>
              <p className="text-xs text-gray-600 mt-3">
                총 {totalQuestions}개의 문항에 답변하셔야 합니다.
              </p>
            </CardContent>
          </Card>
        )}

        {/* 시작 버튼 */}
        <div className="flex justify-end">
          <Button
            onClick={handleStartSurvey}
            disabled={selectedCompetencies.length === 0}
            className="gap-2 bg-blue-600 hover:bg-blue-700 text-white px-8"
          >
            설문 시작
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    )
  }

  // 설문 스테이지
  if (!currentCompetency) return null

  return (
    <div className="space-y-6">
      {/* 상단 진행 정보 */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{currentCompetency.name}</h1>
            <p className="text-sm text-gray-600 mt-1">
              역량 {currentCompetencyIndex + 1} / {selectedCompetencies.length}
            </p>
          </div>
          <Badge className="bg-blue-100 text-blue-700 text-base px-3 py-1">
            {progressPercent}% 완료
          </Badge>
        </div>

        {/* 진행도 바 */}
        <Progress value={progressPercent} className="h-2" />
        <p className="text-xs text-gray-600">
          {answeredQuestions} / {totalQuestions}개 답변
        </p>
      </div>

      {/* 역량 상태 표시 */}
      <div className="grid grid-cols-2 gap-2">
        {competencies.map(comp => (
          <div
            key={comp.id}
            className={`p-3 rounded-lg border text-sm font-medium transition-all ${
              selectedCompetencies.includes(comp.id)
                ? comp.id === currentCompetency.id
                  ? 'bg-blue-100 border-blue-300 text-blue-900'
                  : 'bg-green-50 border-green-200 text-green-700'
                : 'bg-gray-50 border-gray-200 text-gray-500'
            }`}
          >
            <div className="flex items-center gap-2">
              {selectedCompetencies.includes(comp.id) ? (
                <CheckCircle2 className="h-4 w-4" />
              ) : (
                <Circle className="h-4 w-4" />
              )}
              {comp.name}
            </div>
          </div>
        ))}
      </div>

      {/* 설문 문항 */}
      <Card>
        <CardContent className="pt-6 space-y-8">
          {currentCompetency.categories.map(category => (
            <div key={category.id} className="space-y-4">
              <h3 className="font-semibold text-gray-900 text-base">{category.name}</h3>
              <div className="space-y-5 pl-4 border-l-2 border-blue-300">
                {category.questions.map(question => (
                  <div key={question.id} className="space-y-3">
                    <label className="text-sm font-medium text-gray-900">
                      {question.text}
                    </label>
                    <RadioGroup
                      value={responses[question.id] || ''}
                      onValueChange={value => handleAnswer(question.id, value)}
                    >
                      <div className="space-y-2">
                        {question.options.map(option => (
                          <div key={option.value} className="flex items-center space-x-2">
                            <RadioGroupItem value={option.value} id={question.id + option.value} />
                            <Label
                              htmlFor={question.id + option.value}
                              className="text-sm text-gray-700 cursor-pointer font-normal"
                            >
                              {option.label}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </RadioGroup>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* 네비게이션 버튼 */}
      <div className="flex justify-between gap-3">
        <Button
          onClick={handlePrev}
          disabled={currentCompetencyIndex === 0}
          variant="outline"
          className="px-6"
        >
          이전
        </Button>

        <div className="flex gap-2">
          {selectedCompetencies.length > 1 && (
            <Button
              onClick={handleNext}
              disabled={currentCompetencyIndex === selectedCompetencies.length - 1}
              variant="outline"
              className="px-6"
            >
              다음
            </Button>
          )}
          <Button
            onClick={handleSubmit}
            disabled={answeredQuestions < totalQuestions}
            className="gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6"
          >
            {answeredQuestions === totalQuestions ? '완료' : '답변 완료 후 제출'}
            {answeredQuestions === totalQuestions && <CheckCircle2 className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      {/* 미답변 경고 */}
      {answeredQuestions < totalQuestions && (
        <div className="flex gap-3 p-3 bg-amber-50 border border-amber-200 rounded-lg">
          <AlertCircle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-amber-800">
            아직 <span className="font-semibold">{totalQuestions - answeredQuestions}개</span>의 문항에 답변하지 않았습니다.
          </p>
        </div>
      )}
    </div>
  )
}
