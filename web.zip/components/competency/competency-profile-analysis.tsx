'use client'

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import dynamic from "next/dynamic"
import { BarChart3 } from "lucide-react"

const HighchartsReact = dynamic(() => import("highcharts-react-official"), { ssr: false })
import Highcharts from "highcharts"

interface CompetencyProfileProps {
  studentName: string
  detailedData: {
    competencies: {
      name: string
      score: number
      level: string
      categories: {
        name: string
        score: number
        subCategories: {
          name: string
          score: number
          level: string
        }[]
      }[]
    }[]
  }
  departmentAverage: { name: string; score: number }[]
  schoolAverage?: { name: string; score: number }[] // 학교 전체 평균
}

export function CompetencyProfileAnalysis({ 
  studentName, 
  detailedData, 
  departmentAverage,
  schoolAverage = [
    { name: "학습연구역량", score: 73 },
    { name: "융합연구역량", score: 70 }
  ]
}: CompetencyProfileProps) {
  const [activeTab, setActiveTab] = useState(0)
  
  const competencies = detailedData.competencies
  const activeCompetency = competencies[activeTab]
  
  // 현재 선택된 역량의 카테고리별 데이터
  const chartData = activeCompetency.categories.map(cat => {
    const deptAvg = departmentAverage.find(d => d.name === activeCompetency.name)?.score || 0
    const schoolAvg = schoolAverage.find(s => s.name === activeCompetency.name)?.score || 0
    
    // 카테고리별 평균값 계산 (부분적으로)
    const categoryDeptAvg = Math.round(deptAvg * (cat.score / Math.max(...activeCompetency.categories.map(c => c.score))))
    const categorySchoolAvg = Math.round(schoolAvg * (cat.score / Math.max(...activeCompetency.categories.map(c => c.score))))
    
    return {
      name: cat.name,
      studentScore: cat.score,
      deptAvg: Math.max(categoryDeptAvg, 60), // 최소값 60으로 설정
      schoolAvg: Math.max(categorySchoolAvg, 58)
    }
  })

  // 막대 그래프 옵션
  const barChartOptions: Highcharts.Options = {
    chart: {
      type: 'column',
      height: 350,
      style: { fontFamily: 'inherit' }
    },
    title: { text: '' },
    xAxis: {
      categories: chartData.map(d => d.name),
      labels: {
        style: {
          fontSize: '12px'
        }
      }
    },
    yAxis: {
      title: { text: '점수' },
      min: 0,
      max: 100
    },
    tooltip: {
      headerFormat: '<strong>{point.x}</strong><br/>',
      pointFormat: '{series.name}: {point.y}점<br/>',
      shared: true
    },
    legend: {
      enabled: true,
      layout: 'horizontal'
    },
    plotOptions: {
      column: {
        pointPadding: 0.2,
        borderWidth: 0
      }
    },
    series: [
      {
        name: `${studentName}`,
        data: chartData.map(d => d.studentScore),
        color: '#2563eb',
        type: 'column'
      },
      {
        name: '학과평균',
        data: chartData.map(d => d.deptAvg),
        color: '#fbbf24',
        type: 'column'
      },
      {
        name: '학교평균',
        data: chartData.map(d => d.schoolAvg),
        color: '#d1d5db',
        type: 'column'
      }
    ] as any
  }

  // 점수별 색상
  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600"
    if (score >= 70) return "text-blue-600"
    if (score >= 60) return "text-yellow-600"
    return "text-red-600"
  }

  // 비교 분석 텍스트
  const getComparison = (studentScore: number, deptAvg: number, schoolAvg: number) => {
    if (studentScore >= deptAvg && studentScore >= schoolAvg) {
      return "학과 및 학교 평균 이상 (우수)"
    } else if (studentScore >= deptAvg) {
      return "학과 평균 이상 (중상)"
    } else if (studentScore >= schoolAvg) {
      return "학교 평균 이상 (중상)"
    } else {
      return "평균 이하 (개선 필요)"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-blue-600" />
          역량 프로필 분석
        </CardTitle>
        <p className="text-sm text-muted-foreground mt-2">
          역량별 카테고리를 학과평균, 학교평균과 비교합니다.
        </p>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab.toString()} onValueChange={(val) => setActiveTab(parseInt(val))}>
          {/* 탭 메뉴 */}
          <TabsList className="grid w-full grid-cols-2 mb-6">
            {competencies.map((comp, idx) => (
              <TabsTrigger key={idx} value={idx.toString()} className="text-sm">
                <div className="flex items-center gap-2">
                  <span>{comp.name}</span>
                  <Badge 
                    variant="outline"
                    className={comp.score >= 80 ? "bg-green-100 text-green-700" : comp.score >= 70 ? "bg-blue-100 text-blue-700" : "bg-orange-100 text-orange-700"}
                  >
                    {comp.score}점
                  </Badge>
                </div>
              </TabsTrigger>
            ))}
          </TabsList>

          {/* 탭 콘텐츠 */}
          {competencies.map((comp, idx) => (
            <TabsContent key={idx} value={idx.toString()} className="space-y-4">
              {/* 그래프 */}
              <div className="border rounded-lg p-4 bg-white">
                <HighchartsReact
                  highcharts={Highcharts}
                  options={barChartOptions}
                />
              </div>

              {/* 세부 비교 분석 */}
              <div className="space-y-3">
                <h4 className="font-medium text-sm">카테고리별 상세 비교</h4>
                {chartData.map((data, idx) => (
                  <div key={idx} className="p-3 bg-gray-50 rounded-lg border">
                    <div className="flex items-center justify-between mb-2">
                      <h5 className="font-medium text-sm">{data.name}</h5>
                      <Badge className={`${getScoreColor(data.studentScore)} bg-transparent border`}>
                        {data.studentScore}점
                      </Badge>
                    </div>
                    
                    {/* 비교 바 */}
                    <div className="space-y-2">
                      {/* 본인 점수 */}
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground w-16">{studentName}</span>
                        <div className="flex-grow bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full" 
                            style={{ width: `${(data.studentScore / 100) * 100}%` }}
                          />
                        </div>
                        <span className="text-xs font-medium w-10 text-right">{data.studentScore}점</span>
                      </div>

                      {/* 학과 평균 */}
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground w-16">학과평균</span>
                        <div className="flex-grow bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-amber-400 h-2 rounded-full" 
                            style={{ width: `${(data.deptAvg / 100) * 100}%` }}
                          />
                        </div>
                        <span className="text-xs font-medium w-10 text-right">{data.deptAvg}점</span>
                      </div>

                      {/* 학교 평균 */}
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground w-16">학교평균</span>
                        <div className="flex-grow bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-gray-400 h-2 rounded-full" 
                            style={{ width: `${(data.schoolAvg / 100) * 100}%` }}
                          />
                        </div>
                        <span className="text-xs font-medium w-10 text-right">{data.schoolAvg}점</span>
                      </div>
                    </div>

                    {/* 분석 텍스트 */}
                    <div className="mt-2 p-2 bg-white rounded border-l-2 border-l-blue-400">
                      <p className="text-xs text-muted-foreground">
                        <strong>{data.name}</strong>: {getComparison(data.studentScore, data.deptAvg, data.schoolAvg)}
                      </p>
                      {data.studentScore < data.deptAvg && (
                        <p className="text-xs text-red-600 mt-1">
                          학과평균 대비 {data.deptAvg - data.studentScore}점 하회 - 개선 권고
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* 역량 요약 */}
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <h4 className="font-medium text-sm mb-2">{comp.name} 종합 분석</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {comp.score >= 75 
                    ? `${studentName} 학생의 ${comp.name}은(는) 전반적으로 우수한 수준입니다. 특히 강점 영역을 지속적으로 발전시키면서, 취약 영역에 대한 맞춤형 개선이 필요합니다.`
                    : `${studentName} 학생의 ${comp.name}은(는) 개선의 기회가 있습니다. 카테고리별로 우수 영역과 취약 영역의 편차가 있으므로, 취약 영역을 집중적으로 개발할 필요가 있습니다.`
                  }
                </p>
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  )
}
