"use client"

import { Student } from "@/lib/student-data"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  User,
  Mail,
  Phone,
  GraduationCap,
  BookOpen,
  Calendar,
  FlaskConical,
  Award,
  Globe,
} from "lucide-react"

interface StudentBasicInfoProps {
  student: Student
}

const statusColors: Record<string, string> = {
  "재학": "bg-green-50 text-green-700 border-green-200",
  "휴학": "bg-amber-50 text-amber-700 border-amber-200",
  "수료": "bg-blue-50 text-blue-700 border-blue-200",
  "졸업": "bg-gray-100 text-gray-600 border-gray-200",
}

const programColors: Record<string, string> = {
  "석사": "bg-blue-50 text-blue-700 border-blue-200",
  "박사": "bg-indigo-50 text-indigo-700 border-indigo-200",
  "통합": "bg-gray-100 text-gray-600 border-gray-200",
}

function InfoItem({ icon: Icon, label, value }: { icon: React.ElementType; label: string; value: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-muted">
        <Icon className="h-4.5 w-4.5 text-muted-foreground" />
      </div>
      <div className="min-w-0">
        <p className="text-sm text-muted-foreground">{label}</p>
        <p className="text-base font-medium text-foreground truncate">{value}</p>
      </div>
    </div>
  )
}

export function StudentBasicInfo({ student }: StudentBasicInfoProps) {
  return (
    <Card>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-bold">{"기본정보"}</CardTitle>
          <div className="flex items-center gap-2">
            <span className={`rounded-full border px-3 py-1 text-sm font-semibold ${programColors[student.program]}`}>
              {student.program}
            </span>
            <span className={`rounded-full border px-3 py-1 text-sm font-semibold ${statusColors[student.status]}`}>
              {student.status}
            </span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {/* Top: Name + Student ID */}
        <div className="flex items-center gap-4 mb-6 pb-5 border-b border-border">
          <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-primary/10">
            <User className="h-7 w-7 text-primary" />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h2 className="text-xl font-bold text-foreground">{student.name}</h2>
              {student.nationality === "외국인" && (
                <span className="flex items-center gap-1 rounded-full border border-orange-200 bg-orange-50 px-2.5 py-0.5 text-xs font-semibold text-orange-700">
                  <Globe className="h-3.5 w-3.5" />
                  {"외국인"}
                </span>
              )}
            </div>
            <p className="text-sm text-muted-foreground mt-0.5">{"학번 " + student.studentId}</p>
          </div>
        </div>

        {/* Info Grid */}
        <div className="grid grid-cols-2 gap-x-8 gap-y-5 md:grid-cols-3 lg:grid-cols-4">
          <InfoItem icon={BookOpen} label="소속 학과" value={student.department} />
          <InfoItem icon={GraduationCap} label="학위과정" value={student.program + "과정 " + student.grade + "학년 " + student.semester + "학기"} />
          <InfoItem icon={User} label="지도교수" value={student.advisor} />
          <InfoItem icon={FlaskConical} label="연구실" value={student.researchLab} />
          <InfoItem icon={Calendar} label="입학일" value={student.enrollmentDate} />
          <InfoItem icon={Mail} label="이메일" value={student.email} />
          <InfoItem icon={Phone} label="연락처" value={student.phone} />
          <InfoItem icon={Award} label="장학금" value={student.scholarshipType + " (" + student.supportYears + "년차)"} />
        </div>
      </CardContent>
    </Card>
  )
}
