import { Inbox } from "lucide-react"

interface EmptyStateProps {
  message: string
}

export function EmptyState({ message }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 rounded-lg border border-dashed border-border py-10 text-center">
      <Inbox className="h-8 w-8 text-muted-foreground/40" />
      <p className="text-base text-muted-foreground">{message}</p>
    </div>
  )
}
