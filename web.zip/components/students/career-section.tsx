"use client"

import { StudentCareer } from "@/lib/student-data"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { EducationTab } from "./tabs/education-tab"
import { ResearchTab } from "./tabs/research-tab"
import { LectureTab } from "./tabs/lecture-tab"
import { StartupTab } from "./tabs/startup-tab"
import { QualificationTab } from "./tabs/qualification-tab"
import { BookOpen, FlaskConical, Mic, Briefcase, Award } from "lucide-react"

interface CareerSectionProps {
  career: StudentCareer
}

const tabs = [
  { value: "education", label: "교육", icon: BookOpen, activeColor: "data-[state=active]:bg-blue-600 data-[state=active]:text-white" },
  { value: "research", label: "연구", icon: FlaskConical, activeColor: "data-[state=active]:bg-emerald-600 data-[state=active]:text-white" },
  { value: "lecture", label: "강의", icon: Mic, activeColor: "data-[state=active]:bg-amber-600 data-[state=active]:text-white" },
  { value: "startup", label: "창업", icon: Briefcase, activeColor: "data-[state=active]:bg-rose-600 data-[state=active]:text-white" },
  { value: "qualification", label: "자격/수상", icon: Award, activeColor: "data-[state=active]:bg-indigo-600 data-[state=active]:text-white" },
]

export function CareerSection({ career }: CareerSectionProps) {
  return (
    <Card>
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-bold">{"경력사항"}</CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <Tabs defaultValue="education">
          <TabsList className="mb-6 h-auto flex flex-wrap gap-1.5 bg-muted/50 p-1.5 rounded-lg w-full justify-start">
            {tabs.map((tab) => (
              <TabsTrigger
                key={tab.value}
                value={tab.value}
                className={`flex items-center gap-2 rounded-md px-5 py-2.5 text-sm font-semibold transition-all data-[state=active]:shadow-sm ${tab.activeColor}`}
              >
                <tab.icon className="h-4 w-4 shrink-0" />
                {tab.label}
              </TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value="education">
            <EducationTab courses={career.courses} nonCurriculum={career.nonCurriculum} />
          </TabsContent>
          <TabsContent value="research">
            <ResearchTab
              papers={career.papers}
              presentations={career.presentations}
              trainings={career.trainings}
              internships={career.internships}
            />
          </TabsContent>
          <TabsContent value="lecture">
            <LectureTab lectures={career.lectures} />
          </TabsContent>
          <TabsContent value="startup">
            <StartupTab startups={career.startups} />
          </TabsContent>
          <TabsContent value="qualification">
            <QualificationTab qualifications={career.qualifications} />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
