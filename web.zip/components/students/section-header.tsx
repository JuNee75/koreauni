interface SectionHeaderProps {
  label: string
  description?: string
}

export function SectionHeader({ label, description }: SectionHeaderProps) {
  return (
    <div className="flex items-start gap-3 mb-4">
      <div className="h-6 w-1 rounded-full bg-primary shrink-0 mt-0.5" />
      <div>
        <h3 className="text-base font-bold text-foreground">{label}</h3>
        {description && (
          <p className="text-sm text-muted-foreground mt-0.5 leading-relaxed">{description}</p>
        )}
      </div>
    </div>
  )
}
