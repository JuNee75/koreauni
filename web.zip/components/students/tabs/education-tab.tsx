"use client"

import { CourseRecord, NonCurriculumRecord } from "@/lib/student-data"
import { SectionHeader } from "../section-header"
import { EmptyState } from "../empty-state"
import { Clock } from "lucide-react"

interface EducationTabProps {
  courses: CourseRecord[]
  nonCurriculum: NonCurriculumRecord[]
}

const gradeColors: Record<string, string> = {
  "A+": "text-blue-600 font-bold",
  "A0": "text-blue-500 font-semibold",
  "B+": "text-green-600 font-semibold",
  "B0": "text-green-500",
  "P": "text-gray-500",
}

const courseTypeColors: Record<string, string> = {
  "전공필수": "bg-blue-50 text-blue-700 border-blue-200",
  "전공선택": "bg-indigo-50 text-indigo-700 border-indigo-200",
  "교양": "bg-gray-100 text-gray-600 border-gray-200",
}

const methodColors: Record<string, string> = {
  "대면": "bg-green-50 text-green-700 border-green-200",
  "비대면": "bg-orange-50 text-orange-700 border-orange-200",
  "혼합": "bg-blue-50 text-blue-700 border-blue-200",
}

export function EducationTab({ courses, nonCurriculum }: EducationTabProps) {
  const gpa = courses.filter((c) => c.score > 0).length > 0
    ? (courses.filter((c) => c.score > 0).reduce((sum, c) => sum + c.score, 0) / courses.filter((c) => c.score > 0).length).toFixed(2)
    : "-"

  const totalCredits = courses.reduce((sum, c) => sum + c.credits, 0)

  return (
    <div className="flex flex-col gap-8">
      {/* 교과 */}
      <div>
        <SectionHeader label="교과" description="정규교과에 대한 교육 성적 정보" />

        {/* Summary */}
        <div className="grid grid-cols-3 gap-3 mb-4">
          <div className="rounded-lg border border-border bg-muted/30 p-4 text-center">
            <p className="text-sm text-muted-foreground mb-1">{"이수 과목 수"}</p>
            <p className="text-xl font-bold text-foreground">{courses.length}<span className="text-sm font-normal text-muted-foreground ml-1">{"개"}</span></p>
          </div>
          <div className="rounded-lg border border-border bg-muted/30 p-4 text-center">
            <p className="text-sm text-muted-foreground mb-1">{"총 이수 학점"}</p>
            <p className="text-xl font-bold text-foreground">{totalCredits}<span className="text-sm font-normal text-muted-foreground ml-1">{"학점"}</span></p>
          </div>
          <div className="rounded-lg border border-border bg-muted/30 p-4 text-center">
            <p className="text-sm text-muted-foreground mb-1">{"평균 평점"}</p>
            <p className="text-xl font-bold text-primary">{gpa}<span className="text-sm font-normal text-muted-foreground ml-1">{"/4.5"}</span></p>
          </div>
        </div>

        {courses.length === 0 ? (
          <EmptyState message="등록된 교과 이수 정보가 없습니다." />
        ) : (
          <div className="overflow-x-auto rounded-lg border border-border">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-muted/40">
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"연도/학기"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"교과목코드"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"교과목명"}</th>
                  <th className="px-4 py-3 text-center text-sm font-semibold text-muted-foreground">{"구분"}</th>
                  <th className="px-4 py-3 text-center text-sm font-semibold text-muted-foreground">{"학점"}</th>
                  <th className="px-4 py-3 text-center text-sm font-semibold text-muted-foreground">{"성적"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"담당교수"}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {courses.map((course, i) => (
                  <tr key={i} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3 text-sm text-muted-foreground">{course.year + " " + course.semester}</td>
                    <td className="px-4 py-3 font-mono text-sm text-muted-foreground">{course.courseCode}</td>
                    <td className="px-4 py-3 text-sm font-medium text-foreground">{course.courseName}</td>
                    <td className="px-4 py-3 text-center">
                      <span className={`inline-block rounded-full border px-2.5 py-0.5 text-xs font-medium ${courseTypeColors[course.courseType]}`}>
                        {course.courseType}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center text-sm font-medium">{course.credits}</td>
                    <td className={`px-4 py-3 text-center text-sm ${gradeColors[course.grade] ?? ""}`}>{course.grade}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{course.professor}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* 비교과 */}
      <div>
        <SectionHeader
          label="비교과"
          description="시행연도, 학기, 프로그램명, 회차정보, 시작일시, 종료일시, 운영방식, 강사(소속), 장소"
        />

        {nonCurriculum.length === 0 ? (
          <EmptyState message="등록된 비교과 활동 정보가 없습니다." />
        ) : (
          <div className="flex flex-col gap-3">
            {nonCurriculum.map((nc) => (
              <div key={nc.id} className="rounded-lg border border-border p-4 hover:bg-muted/20 transition-colors">
                <div className="flex items-start justify-between gap-4 mb-3">
                  <div>
                    <h4 className="text-base font-semibold text-foreground">{nc.programName}</h4>
                    <p className="text-sm text-muted-foreground mt-0.5">{nc.year + " " + nc.semester + " · " + nc.sessionInfo}</p>
                  </div>
                  <span className={`shrink-0 rounded-full border px-3 py-1 text-xs font-medium ${methodColors[nc.operationMethod]}`}>
                    {nc.operationMethod}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-3 text-sm md:grid-cols-4">
                  <div>
                    <span className="text-muted-foreground">{"기간: "}</span>
                    <span className="text-foreground font-medium">{nc.startDate + " ~ " + nc.endDate}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">{"강사: "}</span>
                    <span className="text-foreground font-medium">{nc.instructor + " (" + nc.instructorAffiliation + ")"}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">{"장소: "}</span>
                    <span className="text-foreground font-medium">{nc.location}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-foreground font-medium">{nc.hours + "시간"}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
