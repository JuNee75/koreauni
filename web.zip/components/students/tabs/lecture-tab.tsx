"use client"

import { LectureRecord } from "@/lib/student-data"
import { SectionHeader } from "../section-header"
import { EmptyState } from "../empty-state"

interface LectureTabProps {
  lectures: LectureRecord[]
}

export function LectureTab({ lectures }: LectureTabProps) {
  const regularLectures = lectures.filter((l) => l.type === "강의")
  const semoLectures = lectures.filter((l) => l.type === "SEMO")

  return (
    <div className="flex flex-col gap-8">
      {/* 강의 */}
      <div>
        <SectionHeader
          label="강의"
          description="강의교과목명, 교과목번호, 학점, 학기(26-01), 강의 요일 및 시작/종료 시간, 강의장소"
        />
        {regularLectures.length === 0 ? (
          <EmptyState message="등록된 강의 정보가 없습니다." />
        ) : (
          <div className="overflow-x-auto rounded-lg border border-border">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-muted/40">
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"교과목명"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"교과목번호"}</th>
                  <th className="px-4 py-3 text-center text-sm font-semibold text-muted-foreground">{"학점"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"학기"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"요일/시간"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"강의장소"}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {regularLectures.map((lecture) => (
                  <tr key={lecture.id} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3 text-sm font-medium text-foreground">{lecture.courseName}</td>
                    <td className="px-4 py-3 font-mono text-sm text-muted-foreground">{lecture.courseCode}</td>
                    <td className="px-4 py-3 text-center text-sm font-medium">{lecture.credits}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{lecture.semester}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{lecture.dayOfWeek + " " + lecture.startTime + "~" + lecture.endTime}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{lecture.location}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* SEMO */}
      <div>
        <SectionHeader
          label="SEMO"
          description="SEMO 교과목명, 교과목번호, 학점, 학기(26-01), 강의 운영 요일 및 시작/종료 시간, 강의장소"
        />
        {semoLectures.length === 0 ? (
          <EmptyState message="등록된 SEMO 강의 정보가 없습니다." />
        ) : (
          <div className="overflow-x-auto rounded-lg border border-border">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-muted/40">
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"교과목명"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"교과목번호"}</th>
                  <th className="px-4 py-3 text-center text-sm font-semibold text-muted-foreground">{"학점"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"학기"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"요일/시간"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"강의장소"}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {semoLectures.map((lecture) => (
                  <tr key={lecture.id} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3 text-sm font-medium text-foreground">{lecture.courseName}</td>
                    <td className="px-4 py-3 font-mono text-sm text-muted-foreground">{lecture.courseCode}</td>
                    <td className="px-4 py-3 text-center text-sm font-medium">{lecture.credits}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{lecture.semester}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{lecture.dayOfWeek + " " + lecture.startTime + "~" + lecture.endTime}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{lecture.location}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
