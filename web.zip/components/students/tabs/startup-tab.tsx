"use client"

import { StartupRecord } from "@/lib/student-data"
import { SectionHeader } from "../section-header"
import { EmptyState } from "../empty-state"
import { CheckCircle, XCircle } from "lucide-react"

interface StartupTabProps {
  startups: StartupRecord[]
}

function formatRevenue(revenue: number): string {
  if (revenue >= 100000000) return (revenue / 100000000).toFixed(1) + "억원"
  if (revenue >= 10000) return Math.floor(revenue / 10000) + "만원"
  return revenue.toLocaleString() + "원"
}

export function StartupTab({ startups }: StartupTabProps) {
  return (
    <div className="flex flex-col gap-8">
      {/* 사업자등록증 */}
      <div>
        <SectionHeader
          label="사업자등록증 입력"
          description="사업자등록증(등록번호, 회사명, 대표자, 개업연월일, 주소, 종류(업태, 종목), 발급년월일, 발급기관명)"
        />
        {startups.length === 0 ? (
          <EmptyState message="등록된 창업 정보가 없습니다." />
        ) : (
          <div className="flex flex-col gap-4">
            {startups.map((startup) => (
              <div key={startup.id} className="rounded-lg border border-border p-5">
                {/* Company Header */}
                <div className="flex items-start justify-between gap-4 mb-5 pb-4 border-b border-border">
                  <div>
                    <h3 className="text-lg font-bold text-foreground">{startup.companyName}</h3>
                    <p className="text-sm text-muted-foreground mt-0.5">{"대표자: " + startup.ceo}</p>
                  </div>
                  <span className="rounded-full border border-blue-200 bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700">
                    {startup.businessType}
                  </span>
                </div>

                {/* Registration Details */}
                <div className="grid grid-cols-2 gap-4 mb-4 md:grid-cols-3">
                  <div>
                    <p className="text-sm text-muted-foreground mb-0.5">{"사업자등록번호"}</p>
                    <p className="text-base font-semibold font-mono text-foreground">{startup.registrationNumber}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-0.5">{"개업연월일"}</p>
                    <p className="text-base font-medium text-foreground">{startup.establishDate}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-0.5">{"업태/종목"}</p>
                    <p className="text-base font-medium text-foreground">{startup.businessType + " / " + startup.businessCategory}</p>
                  </div>
                  <div className="col-span-2 md:col-span-3">
                    <p className="text-sm text-muted-foreground mb-0.5">{"주소"}</p>
                    <p className="text-base font-medium text-foreground">{startup.address}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-0.5">{"발급년월일"}</p>
                    <p className="text-base font-medium text-foreground">{startup.issueDate}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-0.5">{"발급기관"}</p>
                    <p className="text-base font-medium text-foreground">{startup.issueAuthority}</p>
                  </div>
                </div>

                {/* Stats Row */}
                <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t border-border">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">{"직원수"}</p>
                    <p className="text-xl font-bold text-foreground">{startup.employees}<span className="text-sm font-normal text-muted-foreground ml-1">{"명"}</span></p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">{"4대보험 사업장 가입"}</p>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      {startup.insuranceEnrolled ? (
                        <>
                          <CheckCircle className="h-5 w-5 text-green-600" />
                          <span className="text-base font-semibold text-green-600">{"가입"}</span>
                        </>
                      ) : (
                        <>
                          <XCircle className="h-5 w-5 text-red-500" />
                          <span className="text-base font-semibold text-red-500">{"미가입"}</span>
                        </>
                      )}
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">{"연매출"}</p>
                    <p className="text-xl font-bold text-foreground">{formatRevenue(startup.annualRevenue)}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
