"use client"

import { PaperRecord, PresentationRecord, TrainingRecord, InternshipRecord } from "@/lib/student-data"
import { SectionHeader } from "../section-header"
import { EmptyState } from "../empty-state"
import { ExternalLink, Trophy } from "lucide-react"

interface ResearchTabProps {
  papers: PaperRecord[]
  presentations: PresentationRecord[]
  trainings: TrainingRecord[]
  internships: InternshipRecord[]
}

const countryBadge = (country: string) =>
  country === "국외"
    ? "bg-indigo-50 text-indigo-700 border-indigo-200"
    : "bg-blue-50 text-blue-700 border-blue-200"

export function ResearchTab({ papers, presentations, trainings, internships }: ResearchTabProps) {
  return (
    <div className="flex flex-col gap-8">
      {/* 논문 */}
      <div>
        <SectionHeader
          label="국내외 논문"
          description="학술논문, 학술단행본, 학술회의, 전시 및 작품발표실적, 수상경력, 기타연구업적, 연구업적집"
        />
        {papers.length === 0 ? (
          <EmptyState message="등록된 논문 정보가 없습니다." />
        ) : (
          <div className="flex flex-col gap-3">
            {papers.map((paper) => (
              <div key={paper.id} className="rounded-lg border border-border p-4 hover:bg-muted/20 transition-colors">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-2">
                      <span className={`rounded-full border px-2.5 py-0.5 text-xs font-medium ${countryBadge(paper.country)}`}>
                        {paper.country}
                      </span>
                      <span className="rounded-full border border-gray-200 bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-600">
                        {paper.type}
                      </span>
                      {paper.isci && <span className="rounded-full border border-orange-200 bg-orange-50 px-2.5 py-0.5 text-xs font-semibold text-orange-700">{"SCI"}</span>}
                      {paper.isKci && <span className="rounded-full border border-green-200 bg-green-50 px-2.5 py-0.5 text-xs font-semibold text-green-700">{"KCI"}</span>}
                      {paper.isFirstAuthor && <span className="rounded-full border border-purple-200 bg-purple-50 px-2.5 py-0.5 text-xs font-semibold text-purple-700">{"제1저자"}</span>}
                    </div>
                    <p className="font-semibold text-foreground text-base leading-relaxed">{paper.title}</p>
                    <div className="flex flex-wrap gap-4 mt-2 text-sm text-muted-foreground">
                      <span>{"저널: " + paper.journal}</span>
                      <span>{"저자: " + paper.authors}</span>
                      <span>{"게재일: " + paper.publishDate}</span>
                    </div>
                  </div>
                  {paper.doi && (
                    <a
                      href={"https://doi.org/" + paper.doi}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="shrink-0 flex items-center gap-1 rounded-md border border-border px-3 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
                    >
                      <ExternalLink className="h-4 w-4" />
                      {"DOI"}
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 학술발표 */}
      <div>
        <SectionHeader
          label="국내외 학술발표"
          description="학술논문, 학술단행본, 학술회의, 전시 및 작품발표실적, 수상경력, 기타연구업적, 연구업적집"
        />
        {presentations.length === 0 ? (
          <EmptyState message="등록된 학술발표 정보가 없습니다." />
        ) : (
          <div className="overflow-x-auto rounded-lg border border-border">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-muted/40">
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"구분"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"제목"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"학술행사/기관"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"일자"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"장소"}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {presentations.map((pr) => (
                  <tr key={pr.id} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-1">
                        <span className={`rounded-full border px-2.5 py-0.5 text-xs font-medium ${countryBadge(pr.country)}`}>
                          {pr.country}
                        </span>
                        <span className="rounded-full border border-gray-200 bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-600">
                          {pr.type}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm font-medium text-foreground">{pr.title}</p>
                      {pr.awardInfo && (
                        <div className="flex items-center gap-1 mt-1">
                          <Trophy className="h-4 w-4 text-amber-500" />
                          <span className="text-sm text-amber-600 font-medium">{pr.awardInfo}</span>
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{pr.conference}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{pr.date}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{pr.location}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* 연수 */}
      <div>
        <SectionHeader
          label="국내외 장단기 연수"
          description="연수프로그램명, 연수종류(장/단기), 연수장소(국내외 국가명), 연수기관명, 연수시행일자, 연수종료일자"
        />
        {trainings.length === 0 ? (
          <EmptyState message="등록된 연수 정보가 없습니다." />
        ) : (
          <div className="overflow-x-auto rounded-lg border border-border">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-muted/40">
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"구분"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"프로그램명"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"연수기관"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"국가"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"기간"}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {trainings.map((t) => (
                  <tr key={t.id} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex gap-1">
                        <span className={`rounded-full border px-2.5 py-0.5 text-xs font-medium ${t.isAbroad ? "bg-indigo-50 text-indigo-700 border-indigo-200" : "bg-blue-50 text-blue-700 border-blue-200"}`}>
                          {t.isAbroad ? "국외" : "국내"}
                        </span>
                        <span className={`rounded-full border px-2.5 py-0.5 text-xs font-medium ${t.duration === "장기" ? "bg-purple-50 text-purple-700 border-purple-200" : "bg-gray-100 text-gray-600 border-gray-200"}`}>
                          {t.duration}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm font-medium text-foreground">{t.programName}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{t.institution}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{t.country}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{t.startDate + " ~ " + t.endDate}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* 인턴십 */}
      <div>
        <SectionHeader
          label="국내외 인턴십"
          description="인턴십프로그램명, 인턴장소(국내외 국가명), 인턴기관명, 인턴시행일자, 인턴종료일자"
        />
        {internships.length === 0 ? (
          <EmptyState message="등록된 인턴십 정보가 없습니다." />
        ) : (
          <div className="overflow-x-auto rounded-lg border border-border">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-muted/40">
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"구분"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"프로그램명"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"인턴기관"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"장소/국가"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"기간"}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {internships.map((int) => (
                  <tr key={int.id} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3">
                      <span className={`rounded-full border px-2.5 py-0.5 text-xs font-medium ${int.isAbroad ? "bg-indigo-50 text-indigo-700 border-indigo-200" : "bg-blue-50 text-blue-700 border-blue-200"}`}>
                        {int.isAbroad ? "국외" : "국내"}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm font-medium text-foreground">{int.programName}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{int.institution}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{int.location + " (" + int.country + ")"}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{int.startDate + " ~ " + int.endDate}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
