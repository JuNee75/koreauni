"use client"

import { QualificationRecord } from "@/lib/student-data"
import { SectionHeader } from "../section-header"
import { EmptyState } from "../empty-state"
import { Languages, ScrollText, CheckCircle, XCircle, Trophy } from "lucide-react"

interface QualificationTabProps {
  qualifications: QualificationRecord[]
}

const awardGradeColors: Record<string, string> = {
  "최우수상": "bg-amber-50 text-amber-700 border-amber-200",
  "우수상": "bg-orange-50 text-orange-700 border-orange-200",
  "금상": "bg-yellow-50 text-yellow-700 border-yellow-200",
  "은상": "bg-gray-100 text-gray-700 border-gray-200",
}

export function QualificationTab({ qualifications }: QualificationTabProps) {
  const certs = qualifications.filter((q) => q.type === "자격증")
  const awards = qualifications.filter((q) => q.type === "수상")
  const languages = qualifications.filter((q) => q.type === "어학")

  return (
    <div className="flex flex-col gap-8">
      {/* 자격증 */}
      <div>
        <SectionHeader
          label="자격증"
          description="자격/수상 명칭, 발행/시상 기관명, 증서번호, 취득/수상일자, 수상등급(대상, 금상, 최우수상 등)"
        />
        {certs.length === 0 ? (
          <EmptyState message="등록된 자격증 정보가 없습니다." />
        ) : (
          <div className="overflow-x-auto rounded-lg border border-border">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-muted/40">
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"자격증명"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"발급기관"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"증서번호"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"취득일자"}</th>
                  <th className="px-4 py-3 text-center text-sm font-semibold text-muted-foreground">{"상태"}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {certs.map((cert) => (
                  <tr key={cert.id} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <ScrollText className="h-4 w-4 text-blue-500 shrink-0" />
                        <span className="text-sm font-medium text-foreground">{cert.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{cert.issuer}</td>
                    <td className="px-4 py-3 font-mono text-sm text-muted-foreground">{cert.certificateNumber ?? "-"}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{cert.acquiredDate}</td>
                    <td className="px-4 py-3 text-center">
                      {cert.isValid ? (
                        <span className="inline-flex items-center gap-1 rounded-full border border-green-200 bg-green-50 px-2.5 py-0.5 text-xs font-semibold text-green-700">
                          <CheckCircle className="h-3.5 w-3.5" />{"유효"}
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 rounded-full border border-gray-200 bg-gray-100 px-2.5 py-0.5 text-xs font-semibold text-gray-500">
                          <XCircle className="h-3.5 w-3.5" />{"만료"}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* 수상 */}
      <div>
        <SectionHeader
          label="수상"
          description="자격/수상 명칭, 발행/시상 기관명, 증서번호, 취득/수상일자, 수상등급(대상, 금상, 최우수상 등)"
        />
        {awards.length === 0 ? (
          <EmptyState message="등록된 수상 정보가 없습니다." />
        ) : (
          <div className="flex flex-col gap-3">
            {awards.map((award) => (
              <div key={award.id} className="flex items-center gap-4 rounded-lg border border-border p-4 hover:bg-muted/20 transition-colors">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-amber-50 border border-amber-200">
                  <Trophy className="h-5 w-5 text-amber-500" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h4 className="text-base font-semibold text-foreground">{award.name}</h4>
                    {award.awardGrade && (
                      <span className={`rounded-full border px-2.5 py-0.5 text-xs font-semibold ${awardGradeColors[award.awardGrade] ?? "bg-gray-100 text-gray-700 border-gray-200"}`}>
                        {award.awardGrade}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground mt-0.5">{award.issuer + " · " + award.acquiredDate}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 어학 */}
      <div>
        <SectionHeader
          label="어학"
          description="어학 자격 종류(TOEIC, TOFEL, TEPS 등), test일자, 총점"
        />
        {languages.length === 0 ? (
          <EmptyState message="등록된 어학 정보가 없습니다." />
        ) : (
          <div className="overflow-x-auto rounded-lg border border-border">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-muted/40">
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"종류"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"발급기관"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"응시일자"}</th>
                  <th className="px-4 py-3 text-center text-sm font-semibold text-muted-foreground">{"총점"}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-muted-foreground">{"유효기간"}</th>
                  <th className="px-4 py-3 text-center text-sm font-semibold text-muted-foreground">{"상태"}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {languages.map((lang) => (
                  <tr key={lang.id} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <Languages className="h-4 w-4 text-blue-500 shrink-0" />
                        <span className="text-sm font-semibold text-foreground">{lang.testType}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{lang.issuer}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{lang.testDate ?? "-"}</td>
                    <td className="px-4 py-3 text-center">
                      <span className="text-lg font-bold text-primary">{lang.totalScore}</span>
                    </td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{lang.expiryDate ?? "영구"}</td>
                    <td className="px-4 py-3 text-center">
                      {lang.isValid ? (
                        <span className="inline-flex items-center gap-1 rounded-full border border-green-200 bg-green-50 px-2.5 py-0.5 text-xs font-semibold text-green-700">
                          <CheckCircle className="h-3.5 w-3.5" />{"유효"}
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 rounded-full border border-gray-200 bg-gray-100 px-2.5 py-0.5 text-xs font-semibold text-gray-500">
                          <XCircle className="h-3.5 w-3.5" />{"만료"}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
