"use client"

import { useEffect, useRef } from "react"
import type { AutonomousIndicator } from "@/lib/autonomous-indicators-data"
import { categoryOrder, categoryColors } from "@/lib/autonomous-indicators-data"

interface CategoryAchievementChartProps {
  stats: Record<string, { count: number; totalAchievement: number; items: AutonomousIndicator[] }>
}

export function CategoryAchievementChart({ stats }: CategoryAchievementChartProps) {
  const chartRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    let chart: Highcharts.Chart | undefined
    async function init() {
      const Highcharts = (await import("highcharts")).default

      const categories = categoryOrder.map((cat) => {
        if (cat.length > 8) return cat.substring(0, 8) + "..."
        return cat
      })
      const fullNames = [...categoryOrder]
      const data = categoryOrder.map((cat) => {
        const s = stats[cat]
        if (!s || s.count === 0) return 0
        return Math.round(s.totalAchievement / s.count)
      })
      const colors = categoryOrder.map((cat) => categoryColors[cat])

      if (chartRef.current) {
        chart = Highcharts.chart(chartRef.current, {
          chart: {
            type: "column",
            backgroundColor: "transparent",
            style: { fontFamily: "var(--font-sans), sans-serif" },
          },
          title: { text: undefined },
          xAxis: {
            categories,
            labels: {
              rotation: -45,
              style: { fontSize: "11px", color: "#64748b" },
            },
            lineColor: "#e2e8f0",
            tickColor: "#e2e8f0",
          },
          yAxis: {
            title: { text: "달성률 (%)", style: { color: "#64748b", fontSize: "12px" } },
            max: 100,
            gridLineColor: "#f1f5f9",
            labels: { style: { color: "#64748b" } },
          },
          legend: { enabled: false },
          tooltip: {
            formatter: function (this: Highcharts.TooltipFormatterContextObject) {
              const idx = this.point.index ?? 0
              return `<b>${fullNames[idx]}</b><br/>평균 달성률: <b>${this.y}%</b>`
            },
            backgroundColor: "#ffffff",
            borderColor: "#e2e8f0",
            borderRadius: 8,
            shadow: { color: "rgba(0,0,0,0.08)", offsetX: 0, offsetY: 2, width: 8 },
            style: { fontSize: "13px" },
          },
          plotOptions: {
            column: {
              borderRadius: 4,
              colorByPoint: true,
              colors,
              dataLabels: {
                enabled: true,
                format: "{y}%",
                style: { fontSize: "11px", fontWeight: "600", color: "#334155", textOutline: "none" },
              },
            },
          },
          series: [
            {
              type: "column" as const,
              name: "달성률",
              data,
            },
          ],
          accessibility: { enabled: false },
          credits: { enabled: false },
        })
      }
    }
    init()
    return () => {
      chart?.destroy()
    }
  }, [stats])

  return <div ref={chartRef} className="h-[380px] w-full" />
}
