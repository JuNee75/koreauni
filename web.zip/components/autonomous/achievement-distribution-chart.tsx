"use client"

import { useEffect, useRef } from "react"
import { indicators } from "@/lib/autonomous-indicators-data"

export function AchievementDistributionChart() {
  const chartRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    let chart: Highcharts.Chart | undefined
    async function init() {
      const Highcharts = (await import("highcharts")).default

      const ranges = [
        { label: "0~30%", min: 0, max: 30, color: "#EF4444" },
        { label: "31~50%", min: 31, max: 50, color: "#F97316" },
        { label: "51~70%", min: 51, max: 70, color: "#EAB308" },
        { label: "71~99%", min: 71, max: 99, color: "#3B82F6" },
        { label: "100%+", min: 100, max: 9999, color: "#22C55E" },
      ]

      const data = ranges.map((r) => ({
        name: r.label,
        y: indicators.filter(
          (i) => i.achievementPercent >= r.min && i.achievementPercent <= r.max
        ).length,
        color: r.color,
      }))

      if (chartRef.current) {
        chart = Highcharts.chart(chartRef.current, {
          chart: {
            type: "column",
            backgroundColor: "transparent",
            style: { fontFamily: "var(--font-sans), sans-serif" },
          },
          title: { text: undefined },
          xAxis: {
            categories: ranges.map((r) => r.label),
            labels: { style: { fontSize: "12px", color: "#64748b" } },
            lineColor: "#e2e8f0",
            tickColor: "#e2e8f0",
          },
          yAxis: {
            title: { text: "지표 수", style: { color: "#64748b", fontSize: "12px" } },
            allowDecimals: false,
            gridLineColor: "#f1f5f9",
            labels: { style: { color: "#64748b" } },
          },
          legend: { enabled: false },
          tooltip: {
            formatter: function (this: Highcharts.TooltipFormatterContextObject) {
              return `달성률 <b>${this.x}</b>: <b>${this.y}건</b>`
            },
            backgroundColor: "#ffffff",
            borderColor: "#e2e8f0",
            borderRadius: 8,
            shadow: { color: "rgba(0,0,0,0.08)", offsetX: 0, offsetY: 2, width: 8 },
            style: { fontSize: "13px" },
          },
          plotOptions: {
            column: {
              borderRadius: 4,
              colorByPoint: true,
              colors: data.map((d) => d.color),
              dataLabels: {
                enabled: true,
                format: "{y}건",
                style: { fontSize: "12px", fontWeight: "600", color: "#334155", textOutline: "none" },
              },
            },
          },
          series: [
            {
              type: "column" as const,
              name: "지표 수",
              data: data.map((d) => d.y),
            },
          ],
          accessibility: { enabled: false },
          credits: { enabled: false },
        })
      }
    }
    init()
    return () => {
      chart?.destroy()
    }
  }, [])

  return <div ref={chartRef} className="h-[320px] w-full" />
}
