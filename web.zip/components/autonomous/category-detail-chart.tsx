"use client"

import { useEffect, useRef } from "react"
import type { AutonomousIndicator } from "@/lib/autonomous-indicators-data"

interface CategoryDetailChartProps {
  categoryName: string
  items: AutonomousIndicator[]
}

export function CategoryDetailChart({ categoryName, items }: CategoryDetailChartProps) {
  const chartRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    let chart: Highcharts.Chart | undefined
    async function init() {
      const Highcharts = (await import("highcharts")).default

      const labels = items.map((item) => {
        const label = item.id
        return label
      })
      const achievements = items.map((item) => Math.min(item.achievementPercent, 100))
      const barColors = items.map((item) => {
        const pct = Math.min(item.achievementPercent, 100)
        if (pct >= 100) return "#22C55E"
        if (pct >= 70) return "#3B82F6"
        if (pct >= 50) return "#EAB308"
        return "#EF4444"
      })

      if (chartRef.current) {
        chart = Highcharts.chart(chartRef.current, {
          chart: {
            type: "bar",
            backgroundColor: "transparent",
            style: { fontFamily: "var(--font-sans), sans-serif" },
            height: Math.max(items.length * 40 + 60, 180),
          },
          title: { text: undefined },
          xAxis: {
            categories: labels,
            labels: { style: { fontSize: "12px", color: "#334155" } },
            lineColor: "#e2e8f0",
            tickColor: "transparent",
          },
          yAxis: {
            title: { text: undefined },
            max: 100,
            gridLineColor: "#f1f5f9",
            labels: {
              format: "{value}%",
              style: { color: "#64748b" },
            },
          },
          legend: { enabled: false },
          tooltip: {
            formatter: function (this: Highcharts.TooltipFormatterContextObject) {
              const idx = this.point.index ?? 0
              const item = items[idx]
              return `<b>${item.id}</b><br/>${item.programName.substring(0, 40)}...<br/>달성률: <b>${item.achievementRate}</b>`
            },
            backgroundColor: "#ffffff",
            borderColor: "#e2e8f0",
            borderRadius: 8,
            shadow: { color: "rgba(0,0,0,0.08)", offsetX: 0, offsetY: 2, width: 8 },
            style: { fontSize: "12px" },
          },
          plotOptions: {
            bar: {
              borderRadius: 3,
              colorByPoint: true,
              colors: barColors,
              dataLabels: {
                enabled: true,
                format: "{y}%",
                style: { fontSize: "11px", fontWeight: "600", color: "#334155", textOutline: "none" },
              },
            },
          },
          series: [
            {
              type: "bar" as const,
              name: categoryName,
              data: achievements,
            },
          ],
          accessibility: { enabled: false },
          credits: { enabled: false },
        })
      }
    }
    init()
    return () => {
      chart?.destroy()
    }
  }, [categoryName, items])

  return <div ref={chartRef} className="w-full" />
}
