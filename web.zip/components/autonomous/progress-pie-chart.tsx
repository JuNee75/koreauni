"use client"

import { useEffect, useRef } from "react"

interface ProgressPieChartProps {
  counts: { blue: number; yellow: number; red: number; green: number; none: number }
}

export function ProgressPieChart({ counts }: ProgressPieChartProps) {
  const chartRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    let chart: Highcharts.Chart | undefined
    async function init() {
      const Highcharts = (await import("highcharts")).default

      const data = [
        { name: "정상 진행", y: counts.blue, color: "#3B82F6" },
        { name: "주의", y: counts.yellow, color: "#EAB308" },
        { name: "위험/지연", y: counts.red, color: "#EF4444" },
        { name: "초과 달성", y: counts.green, color: "#22C55E" },
        { name: "미분류", y: counts.none, color: "#94A3B8" },
      ].filter((d) => d.y > 0)

      if (chartRef.current) {
        chart = Highcharts.chart(chartRef.current, {
          chart: {
            type: "pie",
            backgroundColor: "transparent",
            style: { fontFamily: "var(--font-sans), sans-serif" },
          },
          title: { text: undefined },
          tooltip: {
            pointFormat: "<b>{point.y}건</b> ({point.percentage:.1f}%)",
            backgroundColor: "#ffffff",
            borderColor: "#e2e8f0",
            borderRadius: 8,
            shadow: { color: "rgba(0,0,0,0.08)", offsetX: 0, offsetY: 2, width: 8 },
            style: { fontSize: "13px" },
          },
          plotOptions: {
            pie: {
              innerSize: "55%",
              borderWidth: 0,
              dataLabels: {
                enabled: true,
                format: "<b>{point.name}</b>: {point.y}건",
                style: { fontSize: "12px", fontWeight: "500", color: "#334155", textOutline: "none" },
                distance: 20,
              },
            },
          },
          series: [
            {
              type: "pie" as const,
              name: "진척도",
              data,
            },
          ],
          accessibility: { enabled: false },
          credits: { enabled: false },
        })
      }
    }
    init()
    return () => {
      chart?.destroy()
    }
  }, [counts])

  return <div ref={chartRef} className="h-[320px] w-full" />
}
