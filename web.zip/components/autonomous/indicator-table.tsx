"use client"

import type { AutonomousIndicator, ProgressStatus } from "@/lib/autonomous-indicators-data"

interface IndicatorTableProps {
  items: AutonomousIndicator[]
}

function ProgressDot({ status }: { status: ProgressStatus }) {
  const colorMap: Record<ProgressStatus, string> = {
    blue: "bg-[#3B82F6]",
    yellow: "bg-[#EAB308]",
    red: "bg-[#EF4444]",
    green: "bg-[#22C55E]",
    none: "bg-[#94A3B8]",
  }
  const labelMap: Record<ProgressStatus, string> = {
    blue: "정상",
    yellow: "주의",
    red: "위험",
    green: "초과달성",
    none: "-",
  }

  return (
    <div className="flex items-center gap-2">
      <span className={`inline-block h-2.5 w-2.5 rounded-full ${colorMap[status]}`} />
      <span className="text-xs text-muted-foreground">{labelMap[status]}</span>
    </div>
  )
}

function AchievementBar({ percent }: { percent: number }) {
  const capped = Math.min(percent, 100)
  let barColor = "bg-[#EF4444]"
  if (capped >= 100) barColor = "bg-[#22C55E]"
  else if (capped >= 70) barColor = "bg-[#3B82F6]"
  else if (capped >= 50) barColor = "bg-[#EAB308]"

  return (
    <div className="flex items-center gap-2">
      <div className="h-2 w-16 rounded-full bg-muted overflow-hidden">
        <div className={`h-full rounded-full ${barColor}`} style={{ width: `${capped}%` }} />
      </div>
      <span className="text-xs font-medium text-foreground">{percent > 100 ? `${percent}%` : `${capped}%`}</span>
    </div>
  )
}

export function IndicatorTable({ items }: IndicatorTableProps) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-border">
            <th className="px-3 py-3 text-left font-semibold text-muted-foreground whitespace-nowrap">{"지표번호"}</th>
            <th className="px-3 py-3 text-left font-semibold text-muted-foreground whitespace-nowrap">{"지표명"}</th>
            <th className="px-3 py-3 text-left font-semibold text-muted-foreground whitespace-nowrap min-w-[200px]">{"사업 및 프로그램명"}</th>
            <th className="px-3 py-3 text-left font-semibold text-muted-foreground whitespace-nowrap">{"기준값"}</th>
            <th className="px-3 py-3 text-center font-semibold text-muted-foreground whitespace-nowrap">{"2025 목표"}</th>
            <th className="px-3 py-3 text-center font-semibold text-muted-foreground whitespace-nowrap">{"2025 현재"}</th>
            <th className="px-3 py-3 text-center font-semibold text-muted-foreground whitespace-nowrap">{"달성률"}</th>
            <th className="px-3 py-3 text-center font-semibold text-muted-foreground whitespace-nowrap">{"진척도"}</th>
            <th className="px-3 py-3 text-center font-semibold text-muted-foreground whitespace-nowrap">{"2026 목표"}</th>
            <th className="px-3 py-3 text-center font-semibold text-muted-foreground whitespace-nowrap">{"2027 목표"}</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => (
            <tr
              key={item.id}
              className="border-b border-border/50 transition-colors hover:bg-muted/30"
            >
              <td className="px-3 py-3 font-medium text-foreground whitespace-nowrap">{item.id}</td>
              <td className="px-3 py-3 text-foreground max-w-[180px] truncate" title={item.indicatorName}>
                {item.indicatorName}
              </td>
              <td className="px-3 py-3 text-foreground max-w-[260px]">
                <span className="line-clamp-2 text-sm" title={item.programName}>
                  {item.programName}
                </span>
              </td>
              <td className="px-3 py-3 text-center text-muted-foreground whitespace-nowrap">{item.baseValue}</td>
              <td className="px-3 py-3 text-center font-medium whitespace-nowrap">{item.target2025}</td>
              <td className="px-3 py-3 text-center whitespace-nowrap">{item.current2025}</td>
              <td className="px-3 py-3">
                <AchievementBar percent={item.achievementPercent} />
              </td>
              <td className="px-3 py-3 text-center">
                <div className="flex justify-center">
                  <ProgressDot status={item.progress} />
                </div>
              </td>
              <td className="px-3 py-3 text-center text-muted-foreground whitespace-nowrap">{item.target2026}</td>
              <td className="px-3 py-3 text-center text-muted-foreground whitespace-nowrap">{item.target2027}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
