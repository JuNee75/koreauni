"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { ExcelUploadModal } from "@/components/excel-upload-modal"
import {
  GraduationCap,
  FlaskConical,
  Handshake,
  Globe,
  Target,
  TrendingUp,
  CheckCircle2,
  Clock,
  BarChart3,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import {
  coreFields,
  getFieldStats,
  getOverallCoreStats,
} from "@/lib/core-indicators-data"
import { FieldSummaryChart } from "@/components/core/field-summary-chart"
import { FieldRadarChart } from "@/components/core/field-radar-chart"
import { YearlyTargetChart } from "@/components/core/yearly-target-chart"
import { SubIndicatorChart } from "@/components/core/sub-indicator-chart"
import { CoreIndicatorTable } from "@/components/core/core-indicator-table"

const fieldIcons = {
  "교육": GraduationCap,
  "연구": FlaskConical,
  "산학협력": Handshake,
  "국제화": Globe,
} as const

const fieldTabColors = {
  "교육": "data-[state=active]:bg-red-50 data-[state=active]:text-red-800 data-[state=active]:border-red-300",
  "연구": "data-[state=active]:bg-green-50 data-[state=active]:text-green-800 data-[state=active]:border-green-300",
  "산학협력": "data-[state=active]:bg-amber-50 data-[state=active]:text-amber-800 data-[state=active]:border-amber-300",
  "국제화": "data-[state=active]:bg-violet-50 data-[state=active]:text-violet-800 data-[state=active]:border-violet-300",
} as const

export default function CorePerformancePage() {
  const [expandedField, setExpandedField] = useState<string | null>(null)
  const overall = getOverallCoreStats()
  const fieldStats = getFieldStats()

  const handleUpload = (file: File) => {
    console.log("Uploaded file for core performance:", file.name)
  }

  const toggleField = (field: string) => {
    setExpandedField((prev) => (prev === field ? null : field))
  }

  return (
    <div className="flex flex-col gap-6 p-4 md:gap-8 md:p-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground">
            {"5차년도 4단계 BK21 핵심성과지표 ['26 1. 13 기준]"}
          </p>
        </div>
        <ExcelUploadModal onUpload={handleUpload} />
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {"전체 지표"}
            </CardTitle>
            <div className="rounded-full bg-muted p-2">
              <Target className="h-4 w-4 text-foreground" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-foreground">
              {overall.totalIndicators}
            </div>
            <p className="mt-1 text-xs text-muted-foreground">
              {"4개 분야 / "}
              {overall.parentCount}
              {"개 핵심지표"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {"평균 달성률"}
            </CardTitle>
            <div className="rounded-full bg-[#3B82F6]/10 p-2">
              <TrendingUp className="h-4 w-4 text-[#3B82F6]" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-[#3B82F6]">
              {overall.avgAchievement}%
            </div>
            <p className="mt-1 text-xs text-muted-foreground">
              {"2025년 목표 대비 핵심지표 평균"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {"목표 달성"}
            </CardTitle>
            <div className="rounded-full bg-[#22C55E]/10 p-2">
              <CheckCircle2 className="h-4 w-4 text-[#22C55E]" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-[#22C55E]">
              {overall.achieved}
            </div>
            <p className="mt-1 text-xs text-muted-foreground">
              {"개 핵심지표 100% 이상 달성"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {"미달성"}
            </CardTitle>
            <div className="rounded-full bg-[#EAB308]/10 p-2">
              <Clock className="h-4 w-4 text-[#EAB308]" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-[#EAB308]">
              {overall.inProgress + overall.notStarted}
            </div>
            <p className="mt-1 text-xs text-muted-foreground">
              {"개 핵심지표 목표 미달성"}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Overview Charts */}
      <div className="grid gap-6 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <CardHeader className="flex flex-row items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" />
            <CardTitle className="text-lg font-bold">
              {"분야별 평균 달성률"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <FieldSummaryChart fields={coreFields} />
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center gap-2">
            <Target className="h-5 w-5 text-primary" />
            <CardTitle className="text-lg font-bold">
              {"분야별 달성 현황"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <FieldRadarChart fields={coreFields} />
          </CardContent>
        </Card>
      </div>

      {/* Field Cards - Summary Overview */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {fieldStats.map((stat) => {
          const Icon = fieldIcons[stat.field]
          return (
            <Card
              key={stat.field}
              className="overflow-hidden"
              style={{ borderTop: `3px solid ${stat.color}` }}
            >
              <CardContent className="pt-5 pb-4">
                <div className="flex items-center gap-3 mb-3">
                  <div
                    className="rounded-lg p-2"
                    style={{ backgroundColor: stat.bgColor }}
                  >
                    <Icon className="h-5 w-5" style={{ color: stat.color }} />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-foreground">
                      {stat.field}
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      {stat.totalIndicators}
                      {"개 지표 / "}
                      {stat.parentCount}
                      {"개 핵심"}
                    </p>
                  </div>
                </div>
                <div className="flex items-end gap-2">
                  <span
                    className="text-3xl font-bold"
                    style={{ color: stat.color }}
                  >
                    {stat.avgAchievement}%
                  </span>
                  <span className="text-xs text-muted-foreground mb-1">
                    {"평균 달성률"}
                  </span>
                </div>
                <div className="mt-2 h-2 w-full rounded-full bg-muted overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all"
                    style={{
                      width: `${Math.min(stat.avgAchievement, 100)}%`,
                      backgroundColor: stat.color,
                    }}
                  />
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Detailed Tabs by Field */}
      <Tabs defaultValue="교육" className="w-full">
        <TabsList className="w-full justify-start gap-2 bg-transparent p-0 h-auto mb-4 flex-wrap md:gap-3">
          {coreFields.map((field) => {
            const Icon = fieldIcons[field.field]
            return (
              <TabsTrigger
                key={field.field}
                value={field.field}
                className={`rounded-lg border border-border px-3 py-2.5 text-sm font-semibold transition-all md:px-6 md:py-4 md:text-base data-[state=active]:shadow-sm data-[state=inactive]:bg-card data-[state=inactive]:text-muted-foreground ${fieldTabColors[field.field]}`}
              >
                <Icon className="h-4 w-4 mr-1.5 md:h-5 md:w-5 md:mr-2" />
                {field.field}
              </TabsTrigger>
            )
          })}
        </TabsList>

        {coreFields.map((field) => {
          const parentIndicators = field.indicators.filter((i) => i.isParent)

          return (
            <TabsContent
              key={field.field}
              value={field.field}
              className="mt-6 flex flex-col gap-6"
            >
              {/* Yearly Target Chart */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-bold">
                    {field.field}
                    {" 분야 연도별 목표 현황"}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <YearlyTargetChart
                    indicators={field.indicators}
                    fieldColor={field.color}
                    fieldName={field.field}
                  />
                </CardContent>
              </Card>

              {/* Sub Indicator Bar Chart + Table */}
              <div className="grid gap-6 lg:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg font-bold">
                      {"하위 지표별 달성률"}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <SubIndicatorChart
                      indicators={field.indicators}
                      fieldColor={field.color}
                    />
                  </CardContent>
                </Card>

                {/* Parent Indicators Summary */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg font-bold">
                      {"핵심지표 요약"}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-col gap-4">
                      {parentIndicators.map((pi) => {
                        const achVal = parseFloat(pi.achievement25)
                        const achNum = isNaN(achVal) ? 0 : achVal
                        let statusColor = "#94A3B8"
                        let statusText = "미시작"
                        if (achNum >= 100) {
                          statusColor = "#22C55E"
                          statusText = "달성"
                        } else if (achNum >= 70) {
                          statusColor = "#3B82F6"
                          statusText = "양호"
                        } else if (achNum >= 50) {
                          statusColor = "#EAB308"
                          statusText = "주의"
                        } else if (achNum > 0) {
                          statusColor = "#EF4444"
                          statusText = "위험"
                        }

                        return (
                          <div
                            key={pi.id}
                            className="rounded-lg border border-border p-4"
                          >
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-2">
                                <span className="font-bold text-foreground">
                                  {pi.code}
                                </span>
                                <span className="text-sm text-foreground">
                                  {pi.name}
                                </span>
                              </div>
                              <Badge
                                className="text-[11px] font-semibold border-0"
                                style={{
                                  backgroundColor: `${statusColor}15`,
                                  color: statusColor,
                                }}
                              >
                                {statusText}
                              </Badge>
                            </div>
                            <div className="flex items-center gap-3 text-xs text-muted-foreground mb-2">
                              <span>
                                {"목표: "}
                                {pi.target25Goal}
                              </span>
                              <span>
                                {"현재: "}
                                {pi.current25 || "-"}
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <div className="flex-1 h-2.5 rounded-full bg-muted overflow-hidden">
                                <div
                                  className="h-full rounded-full transition-all"
                                  style={{
                                    width: `${Math.min(achNum, 100)}%`,
                                    backgroundColor: statusColor,
                                  }}
                                />
                              </div>
                              <span
                                className="text-sm font-bold whitespace-nowrap"
                                style={{ color: statusColor }}
                              >
                                {pi.achievement25}
                              </span>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Full Data Table */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-bold">
                    {field.field}
                    {" 분야 전체 지표 상세"}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <CoreIndicatorTable
                    indicators={field.indicators}
                    fieldColor={field.color}
                  />
                </CardContent>
              </Card>
            </TabsContent>
          )
        })}
      </Tabs>
    </div>
  )
}
