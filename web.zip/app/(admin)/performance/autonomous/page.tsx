"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Target,
  TrendingUp,
  CheckCircle2,
  Clock,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  BarChart3,
  PieChart,
  ListFilter,
} from "lucide-react"
import { ExcelUploadModal } from "@/components/excel-upload-modal"
import {
  indicators,
  categoryOrder,
  categoryColors,
  getCategoryStats,
  getProgressCounts,
  getOverallStats,
} from "@/lib/autonomous-indicators-data"
import { CategoryAchievementChart } from "@/components/autonomous/category-achievement-chart"
import { ProgressPieChart } from "@/components/autonomous/progress-pie-chart"
import { AchievementDistributionChart } from "@/components/autonomous/achievement-distribution-chart"
import { CategoryDetailChart } from "@/components/autonomous/category-detail-chart"
import { IndicatorTable } from "@/components/autonomous/indicator-table"

export default function AutonomousPerformancePage() {
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null)

  const stats = getCategoryStats()
  const progressCounts = getProgressCounts()
  const overall = getOverallStats()

  const handleUpload = (file: File) => {
    console.log("Uploaded file for autonomous performance:", file.name)
  }

  const toggleCategory = (cat: string) => {
    setExpandedCategory((prev) => (prev === cat ? null : cat))
  }

  return (
    <div className="flex flex-col gap-6 p-4 md:gap-8 md:p-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground">
            {"총 "}
            <span className="font-semibold text-foreground">{indicators.length}</span>
            {"개 지표 / "}
            <span className="font-semibold text-foreground">{categoryOrder.length}</span>
            {"개 카테고리 분석"}
          </p>
        </div>
        <ExcelUploadModal onUpload={handleUpload} />
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{"전체 지표"}</CardTitle>
            <div className="rounded-full bg-muted p-2">
              <Target className="h-4 w-4 text-foreground" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-foreground">{overall.total}</div>
            <p className="mt-1 text-xs text-muted-foreground">{"개 자율성과지표 관리중"}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{"평균 달성률"}</CardTitle>
            <div className="rounded-full bg-[#3B82F6]/10 p-2">
              <TrendingUp className="h-4 w-4 text-[#3B82F6]" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-[#3B82F6]">{overall.avgAchievement}%</div>
            <p className="mt-1 text-xs text-muted-foreground">{"2025년 목표 대비"}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{"목표 달성"}</CardTitle>
            <div className="rounded-full bg-[#22C55E]/10 p-2">
              <CheckCircle2 className="h-4 w-4 text-[#22C55E]" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-[#22C55E]">{overall.achieved}</div>
            <p className="mt-1 text-xs text-muted-foreground">{"개 지표 100% 이상 달성"}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{"진행중"}</CardTitle>
            <div className="rounded-full bg-[#EAB308]/10 p-2">
              <Clock className="h-4 w-4 text-[#EAB308]" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-[#EAB308]">{overall.inProgress}</div>
            <p className="mt-1 text-xs text-muted-foreground">{"개 지표 목표 미달성"}</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Charts Row */}
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" />
            <CardTitle className="text-lg font-bold">{"카테고리별 평균 달성률"}</CardTitle>
          </CardHeader>
          <CardContent>
            <CategoryAchievementChart stats={stats} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center gap-2">
            <PieChart className="h-5 w-5 text-primary" />
            <CardTitle className="text-lg font-bold">{"진척도 현황"}</CardTitle>
          </CardHeader>
          <CardContent>
            <ProgressPieChart counts={progressCounts} />
            <div className="mt-4 flex flex-wrap items-center justify-center gap-3">
              {[
                { label: "정상", color: "bg-[#3B82F6]", count: progressCounts.blue },
                { label: "주의", color: "bg-[#EAB308]", count: progressCounts.yellow },
                { label: "위험", color: "bg-[#EF4444]", count: progressCounts.red },
                { label: "초과", color: "bg-[#22C55E]", count: progressCounts.green },
              ]
                .filter((s) => s.count > 0)
                .map((s) => (
                  <div key={s.label} className="flex items-center gap-1.5">
                    <span className={`h-2.5 w-2.5 rounded-full ${s.color}`} />
                    <span className="text-xs text-muted-foreground">
                      {s.label} {s.count}
                    </span>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Achievement Distribution */}
      <Card>
        <CardHeader className="flex flex-row items-center gap-2">
          <ListFilter className="h-5 w-5 text-primary" />
          <CardTitle className="text-lg font-bold">{"달성률 분포"}</CardTitle>
        </CardHeader>
        <CardContent>
          <AchievementDistributionChart />
        </CardContent>
      </Card>

      {/* Category-wise Detail Section */}
      <div className="flex flex-col gap-4">
        <h2 className="text-xl font-bold text-foreground">{"카테고리별 상세 현황"}</h2>

        {categoryOrder.map((cat) => {
          const catStats = stats[cat]
          if (!catStats || catStats.count === 0) return null
          const avgAchievement = Math.round(catStats.totalAchievement / catStats.count)
          const isExpanded = expandedCategory === cat

          return (
            <Card key={cat} className="overflow-hidden">
              <button
                className="flex w-full items-center justify-between px-6 py-4 text-left transition-colors hover:bg-muted/30"
                onClick={() => toggleCategory(cat)}
              >
                <div className="flex items-center gap-3">
                  <span
                    className="h-3 w-3 rounded-full shrink-0"
                    style={{ backgroundColor: categoryColors[cat] }}
                  />
                  <span className="text-base font-bold text-foreground">{cat}</span>
                  <Badge variant="secondary" className="text-xs font-medium">
                    {catStats.count}{"개 지표"}
                  </Badge>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <div className="hidden h-2 w-24 overflow-hidden rounded-full bg-muted sm:block">
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${avgAchievement}%`,
                          backgroundColor: categoryColors[cat],
                        }}
                      />
                    </div>
                    <span className="text-sm font-semibold text-foreground">{avgAchievement}%</span>
                  </div>
                  {isExpanded ? (
                    <ChevronUp className="h-4 w-4 text-muted-foreground" />
                  ) : (
                    <ChevronDown className="h-4 w-4 text-muted-foreground" />
                  )}
                </div>
              </button>

              {isExpanded && (
                <CardContent className="border-t border-border pt-4">
                  <div className="flex flex-col gap-6">
                    {/* Category Bar Chart */}
                    <CategoryDetailChart categoryName={cat} items={catStats.items} />

                    {/* Detail Table */}
                    <IndicatorTable items={catStats.items} />
                  </div>
                </CardContent>
              )}
            </Card>
          )
        })}
      </div>

      {/* Attention-needed indicators */}
      <Card>
        <CardHeader className="flex flex-row items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-[#EF4444]" />
          <CardTitle className="text-lg font-bold">{"주의 필요 지표"}</CardTitle>
        </CardHeader>
        <CardContent>
          <IndicatorTable
            items={indicators.filter(
              (i) => i.progress === "red" || i.progress === "yellow" || i.achievementPercent === 0
            )}
          />
          {indicators.filter(
            (i) => i.progress === "red" || i.progress === "yellow" || i.achievementPercent === 0
          ).length === 0 && (
            <p className="py-8 text-center text-sm text-muted-foreground">{"주의 필요 지표가 없습니다."}</p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
