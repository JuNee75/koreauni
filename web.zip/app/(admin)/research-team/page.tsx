"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ExcelUploadModal } from "@/components/excel-upload-modal"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Users, GraduationCap, TrendingUp, Briefcase, DollarSign, Lightbulb, Globe } from "lucide-react"

export default function ResearchTeamPage() {
  const indicators = [
    { id: "professors", title: "전임교수 현황", icon: Users, color: "data-[state=active]:bg-red-100 data-[state=active]:text-red-800 data-[state=active]:border-red-400" },
    { id: "students", title: "대학원생 현황", icon: GraduationCap, color: "data-[state=active]:bg-indigo-100 data-[state=active]:text-indigo-700 data-[state=active]:border-indigo-400" },
    { id: "recruitment", title: "대학원생 확보 및 배출", icon: TrendingUp, color: "data-[state=active]:bg-purple-100 data-[state=active]:text-purple-700 data-[state=active]:border-purple-400" },
    { id: "employment", title: "취(창)업 현황", icon: Briefcase, color: "data-[state=active]:bg-pink-100 data-[state=active]:text-pink-700 data-[state=active]:border-pink-400" },
    { id: "research-funding", title: "연구비 수주 현황", icon: DollarSign, color: "data-[state=active]:bg-green-100 data-[state=active]:text-green-700 data-[state=active]:border-green-400" },
    { id: "patents", title: "특허, 기술이전, 창업", icon: Lightbulb, color: "data-[state=active]:bg-amber-100 data-[state=active]:text-amber-700 data-[state=active]:border-amber-400" },
    { id: "international", title: "국제공동연구", icon: Globe, color: "data-[state=active]:bg-cyan-100 data-[state=active]:text-cyan-700 data-[state=active]:border-cyan-400" },
  ]

  const handleUpload = (indicatorId: string) => (file: File) => {
    console.log("[v0] Uploaded file for research team indicator:", indicatorId, file.name)
  }

  return (
    <div className="flex flex-col gap-6 p-4 md:gap-8 md:p-8">
      <div className="flex items-center justify-between">
        <p className="text-base text-muted-foreground">
          {'교육연구단 성과 및 현황 관리'}
        </p>
      </div>

      <Tabs defaultValue="professors" className="w-full">
        <TabsList className="w-full justify-start flex-wrap h-auto gap-2 bg-transparent p-0 mb-4 md:gap-3">
          {indicators.map((indicator) => (
            <TabsTrigger
              key={indicator.id}
              value={indicator.id}
              className={`whitespace-nowrap rounded-lg border border-border px-3 py-2.5 text-sm font-semibold transition-all md:px-5 md:py-4 md:text-base data-[state=active]:shadow-sm data-[state=inactive]:bg-card data-[state=inactive]:text-muted-foreground ${indicator.color}`}
            >
              <indicator.icon className="h-4 w-4 mr-1.5 md:h-5 md:w-5 md:mr-2" />
              {indicator.title}
            </TabsTrigger>
          ))}
        </TabsList>

        {indicators.map((indicator, index) => (
          <TabsContent key={indicator.id} value={indicator.id} className="mt-6">
            <div className="space-y-5">
              <div className="flex justify-end">
                <ExcelUploadModal onUpload={handleUpload(indicator.id)} />
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-xl font-bold">
                    {index + 1}. {indicator.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {indicator.id === "professors" ? (
                    <div className="space-y-4">
                      <p className="text-sm text-muted-foreground">
                        {'업로드된 데이터가 아래 표에 표시됩니다. 예시 양식:'}
                      </p>
                      <div className="overflow-x-auto rounded-lg border border-border">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b border-border bg-secondary/50">
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'대학원 학과(부)'}</th>
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'학기'}</th>
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'전체교수 수'}</th>
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'참여교수 수'}</th>
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'참여비율(%)'}</th>
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'비고'}</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5 text-muted-foreground">{'(학과명)'}</td>
                              <td className="px-4 py-3.5">{'2024년 2학기'}</td>
                              <td className="px-4 py-3.5">{'9명'}</td>
                              <td className="px-4 py-3.5">{'7'}</td>
                              <td className="px-4 py-3.5">{'77.78'}</td>
                              <td className="px-4 py-3.5 text-muted-foreground">{'-'}</td>
                            </tr>
                            <tr className="transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5 text-muted-foreground">{'(학과명)'}</td>
                              <td className="px-4 py-3.5">{'2025년 1학기'}</td>
                              <td className="px-4 py-3.5">{'10명'}</td>
                              <td className="px-4 py-3.5">{'7'}</td>
                              <td className="px-4 py-3.5">{'70'}</td>
                              <td className="px-4 py-3.5 text-muted-foreground">{'-'}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  ) : indicator.id === "students" ? (
                    <div className="space-y-4">
                      <p className="text-sm text-muted-foreground">
                        {'업로드된 데이터가 아래 표에 표시됩니다. 예시 양식:'}
                      </p>
                      <div className="overflow-x-auto rounded-lg border border-border">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b border-border bg-secondary/50">
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'학과(부)'}</th>
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'학기'}</th>
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'구분'}</th>
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'전체 인원'}</th>
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'전임 인원'}</th>
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'전임 비율(%)'}</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5 text-muted-foreground" rowSpan={4}>{'(학과명)'}</td>
                              <td className="px-4 py-3.5" rowSpan={4}>{'2024년 2학기'}</td>
                              <td className="px-4 py-3.5">{'석사'}</td>
                              <td className="px-4 py-3.5">{'18'}</td>
                              <td className="px-4 py-3.5">{'15'}</td>
                              <td className="px-4 py-3.5">{'83.33'}</td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5">{'박사'}</td>
                              <td className="px-4 py-3.5">{'5'}</td>
                              <td className="px-4 py-3.5">{'3'}</td>
                              <td className="px-4 py-3.5">{'60'}</td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5">{'석·박사 통합'}</td>
                              <td className="px-4 py-3.5">{'7'}</td>
                              <td className="px-4 py-3.5">{'7'}</td>
                              <td className="px-4 py-3.5">{'100'}</td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30 bg-secondary/30">
                              <td className="px-4 py-3.5 font-semibold">{'계'}</td>
                              <td className="px-4 py-3.5 font-semibold">{'30'}</td>
                              <td className="px-4 py-3.5 font-semibold">{'25'}</td>
                              <td className="px-4 py-3.5 font-semibold">{'83.33'}</td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5 text-muted-foreground" rowSpan={4}>{'(학과명)'}</td>
                              <td className="px-4 py-3.5" rowSpan={4}>{'2025년 1학기'}</td>
                              <td className="px-4 py-3.5">{'석사'}</td>
                              <td className="px-4 py-3.5">{'20'}</td>
                              <td className="px-4 py-3.5">{'18'}</td>
                              <td className="px-4 py-3.5">{'90'}</td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5">{'박사'}</td>
                              <td className="px-4 py-3.5">{'6'}</td>
                              <td className="px-4 py-3.5">{'4'}</td>
                              <td className="px-4 py-3.5">{'66.67'}</td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5">{'석·박사 통합'}</td>
                              <td className="px-4 py-3.5">{'8'}</td>
                              <td className="px-4 py-3.5">{'8'}</td>
                              <td className="px-4 py-3.5">{'100'}</td>
                            </tr>
                            <tr className="transition-colors hover:bg-secondary/30 bg-secondary/30">
                              <td className="px-4 py-3.5 font-semibold">{'계'}</td>
                              <td className="px-4 py-3.5 font-semibold">{'34'}</td>
                              <td className="px-4 py-3.5 font-semibold">{'30'}</td>
                              <td className="px-4 py-3.5 font-semibold">{'88.24'}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  ) : indicator.id === "recruitment" ? (
                    <div className="space-y-4">
                      <p className="text-sm text-muted-foreground">
                        {'교육연구단 대학원생 확보 및 배출 현황'}
                      </p>
                      <div className="overflow-x-auto rounded-lg border border-border">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b border-border bg-secondary/50">
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'학기'}</th>
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'구분'}</th>
                              <th className="px-4 py-3.5 text-right font-semibold text-foreground">{'전체 인원'}</th>
                              <th className="px-4 py-3.5 text-right font-semibold text-foreground">{'참여 인원'}</th>
                              <th className="px-4 py-3.5 text-right font-semibold text-foreground">{'참여 비율(%)'}</th>
                            </tr>
                          </thead>
                          <tbody>
                            {/* 2024년 2학기 */}
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5 font-medium" rowSpan={4}>{'2024년 2학기'}</td>
                              <td className="px-4 py-3.5">{'석사'}</td>
                              <td className="px-4 py-3.5 text-right">{'18'}</td>
                              <td className="px-4 py-3.5 text-right">{'15'}</td>
                              <td className="px-4 py-3.5 text-right">{'83.33'}</td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5">{'박사'}</td>
                              <td className="px-4 py-3.5 text-right">{'5'}</td>
                              <td className="px-4 py-3.5 text-right">{'3'}</td>
                              <td className="px-4 py-3.5 text-right">{'60'}</td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5">{'석·박사 통합'}</td>
                              <td className="px-4 py-3.5 text-right">{'7'}</td>
                              <td className="px-4 py-3.5 text-right">{'7'}</td>
                              <td className="px-4 py-3.5 text-right">{'100'}</td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30 bg-secondary/30">
                              <td className="px-4 py-3.5 font-semibold">{'소계'}</td>
                              <td className="px-4 py-3.5 text-right font-semibold">{'30'}</td>
                              <td className="px-4 py-3.5 text-right font-semibold">{'25'}</td>
                              <td className="px-4 py-3.5 text-right font-semibold">{'83.33'}</td>
                            </tr>
                            {/* 2025년 1학기 */}
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5 font-medium" rowSpan={4}>{'2025년 1학기'}</td>
                              <td className="px-4 py-3.5">{'석사'}</td>
                              <td className="px-4 py-3.5 text-right">{'20'}</td>
                              <td className="px-4 py-3.5 text-right">{'18'}</td>
                              <td className="px-4 py-3.5 text-right">{'90'}</td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5">{'박사'}</td>
                              <td className="px-4 py-3.5 text-right">{'6'}</td>
                              <td className="px-4 py-3.5 text-right">{'4'}</td>
                              <td className="px-4 py-3.5 text-right">{'66.67'}</td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5">{'석·박사 통합'}</td>
                              <td className="px-4 py-3.5 text-right">{'8'}</td>
                              <td className="px-4 py-3.5 text-right">{'8'}</td>
                              <td className="px-4 py-3.5 text-right">{'100'}</td>
                            </tr>
                            <tr className="transition-colors hover:bg-secondary/30 bg-secondary/30">
                              <td className="px-4 py-3.5 font-semibold">{'소계'}</td>
                              <td className="px-4 py-3.5 text-right font-semibold">{'34'}</td>
                              <td className="px-4 py-3.5 text-right font-semibold">{'30'}</td>
                              <td className="px-4 py-3.5 text-right font-semibold">{'88.24'}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  ) : indicator.id === "employment" ? (
                    <div className="space-y-4">
                      <p className="text-sm text-muted-foreground">
                        {'교육연구단 취(창)업 현황'}
                      </p>
                      <div className="overflow-x-auto rounded-lg border border-border">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b border-border bg-secondary/50">
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'구분 (학기/시기)'}</th>
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'학위 과정'}</th>
                              <th className="px-4 py-3.5 text-right font-semibold text-foreground">{'참여 확보(재학)'}</th>
                              <th className="px-4 py-3.5 text-right font-semibold text-foreground">{'졸업(배출)'}</th>
                              <th className="px-4 py-3.5 text-right font-semibold text-foreground">{'취업(창업)'}</th>
                              <th className="px-4 py-3.5 text-right font-semibold text-foreground">{'취업률'}</th>
                            </tr>
                          </thead>
                          <tbody>
                            {/* 2024년 8월 졸업 */}
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5 font-medium" rowSpan={2}>{'2024년 8월 졸업'}</td>
                              <td className="px-4 py-3.5">{'석사'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 text-right">{'4'}</td>
                              <td className="px-4 py-3.5 text-right">{'3'}</td>
                              <td className="px-4 py-3.5 text-right font-semibold text-blue-600">{'75%'}</td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5">{'박사'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 text-right">{'0'}</td>
                              <td className="px-4 py-3.5 text-right">{'0'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                            </tr>
                            {/* 2024년 2학기 */}
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30 bg-secondary/20">
                              <td className="px-4 py-3.5 font-medium" rowSpan={3}>{'2024년 2학기'}</td>
                              <td className="px-4 py-3.5">{'석사'}</td>
                              <td className="px-4 py-3.5 text-right">{'15'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30 bg-secondary/20">
                              <td className="px-4 py-3.5">{'박사'}</td>
                              <td className="px-4 py-3.5 text-right">{'3'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30 bg-secondary/20">
                              <td className="px-4 py-3.5">{'석·박사 통합'}</td>
                              <td className="px-4 py-3.5 text-right">{'7'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                            </tr>
                            {/* 2025년 2월 졸업 */}
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5 font-medium" rowSpan={2}>{'2025년 2월 졸업'}</td>
                              <td className="px-4 py-3.5">{'석사'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 text-right">{'5'}</td>
                              <td className="px-4 py-3.5 text-right">{'3'}</td>
                              <td className="px-4 py-3.5 text-right font-semibold text-blue-600">{'66.67%'}</td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5">{'박사'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 text-right">{'1'}</td>
                              <td className="px-4 py-3.5 text-right">{'1'}</td>
                              <td className="px-4 py-3.5 text-right text-xs text-muted-foreground">{'(합계 기준)'}</td>
                            </tr>
                            {/* 2025년 1학기 */}
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30 bg-secondary/20">
                              <td className="px-4 py-3.5 font-medium" rowSpan={3}>{'2025년 1학기'}</td>
                              <td className="px-4 py-3.5">{'석사'}</td>
                              <td className="px-4 py-3.5 text-right">{'18'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30 bg-secondary/20">
                              <td className="px-4 py-3.5">{'박사'}</td>
                              <td className="px-4 py-3.5 text-right">{'4'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30 bg-secondary/20">
                              <td className="px-4 py-3.5">{'석·박사 통합'}</td>
                              <td className="px-4 py-3.5 text-right">{'8'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                            </tr>
                            {/* 2025년 8월 졸업 */}
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5 font-medium" rowSpan={2}>{'2025년 8월 졸업'}</td>
                              <td className="px-4 py-3.5">{'석사'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 text-right">{'4'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                            </tr>
                            <tr className="transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5">{'박사'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 text-right">{'1'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  ) : indicator.id === "research-funding" ? (
                    <div className="space-y-4">
                      <p className="text-sm text-muted-foreground">
                        {'교육연구단 연구비 수주 현황 (단위: 천원)'}
                      </p>
                      <div className="overflow-x-auto rounded-lg border border-border">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b border-border bg-secondary/50">
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'항목'}</th>
                              <th className="px-4 py-3.5 text-right font-semibold text-foreground">{'3년간 실적'}<br /><span className="text-xs font-normal text-muted-foreground">{'(2021.9.1.~2024.8.31.)'}</span></th>
                              <th className="px-4 py-3.5 text-right font-semibold text-foreground">{'최근 1년간 실적'}<br /><span className="text-xs font-normal text-muted-foreground">{'(2024.9.1.~2025.8.31.)'}</span></th>
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'비고'}</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5 font-medium">{'정부 연구비 수주 총 임금액'}</td>
                              <td className="px-4 py-3.5 text-right tabular-nums">{'9,109,957'}</td>
                              <td className="px-4 py-3.5 text-right tabular-nums">{'3,442,928'}</td>
                              <td className="px-4 py-3.5 text-muted-foreground">{'-'}</td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5 font-medium">{'산업체(국내) 연구비 수주 총 임금액'}</td>
                              <td className="px-4 py-3.5 text-right tabular-nums">{'342,550'}</td>
                              <td className="px-4 py-3.5 text-right tabular-nums">{'226,200'}</td>
                              <td className="px-4 py-3.5 text-muted-foreground">{'-'}</td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5 font-medium">{'해외기관 연구비 수주 총(환산) 임금액'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 text-right text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 text-muted-foreground">{'-'}</td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30 bg-secondary/30">
                              <td className="px-4 py-3.5 font-semibold">{'1인당 총 연구비 수주액'}</td>
                              <td className="px-4 py-3.5 text-right font-semibold tabular-nums">{'1,350,358'}</td>
                              <td className="px-4 py-3.5 text-right font-semibold tabular-nums">{'524,161'}</td>
                              <td className="px-4 py-3.5 text-muted-foreground">{'-'}</td>
                            </tr>
                            <tr className="transition-colors hover:bg-secondary/30 bg-secondary/30">
                              <td className="px-4 py-3.5 font-semibold">{'참여교수 수'}</td>
                              <td className="px-4 py-3.5 text-right font-semibold tabular-nums">{'7'}</td>
                              <td className="px-4 py-3.5 text-right font-semibold tabular-nums">{'7'}</td>
                              <td className="px-4 py-3.5 text-muted-foreground">{'-'}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  ) : indicator.id === "patents" ? (
                    <div className="space-y-4">
                      <p className="text-sm text-muted-foreground">
                        {'교육연구단 특허, 기술이전, 창업 실적'}
                      </p>
                      <div className="overflow-x-auto rounded-lg border border-border">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b border-border bg-secondary/50">
                              <th className="px-4 py-3.5 text-center font-semibold text-foreground w-16">{'연번'}</th>
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground w-24">{'구분'}</th>
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground w-24">{'성명'}</th>
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'연구업적물 명칭(제목)'}</th>
                              <th className="px-4 py-3.5 text-center font-semibold text-foreground w-28">{'일자 / 상태'}</th>
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'비고 (참여학생/기술료)'}</th>
                            </tr>
                          </thead>
                          <tbody>
                            {/* 특허 */}
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5 text-center">{'1'}</td>
                              <td className="px-4 py-3.5">
                                <span className="inline-flex items-center rounded-md bg-blue-50 px-2 py-1 text-xs font-medium text-blue-700 ring-1 ring-blue-700/10 ring-inset">{'특허'}</span>
                              </td>
                              <td className="px-4 py-3.5 font-medium">{'김유신'}</td>
                              <td className="px-4 py-3.5 text-muted-foreground">{'(특허 발명의 명칭)'}</td>
                              <td className="px-4 py-3.5 text-center">
                                <span className="inline-flex items-center rounded-md bg-amber-50 px-2 py-1 text-xs font-medium text-amber-700 ring-1 ring-amber-700/10 ring-inset">{'출원'}</span>
                              </td>
                              <td className="px-4 py-3.5 text-muted-foreground">{'참여대학원생: (성명)(석사과정)'}</td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30 bg-secondary/20">
                              <td className="px-4 py-3.5 text-center">{'2~8'}</td>
                              <td className="px-4 py-3.5">
                                <span className="inline-flex items-center rounded-md bg-blue-50 px-2 py-1 text-xs font-medium text-blue-700 ring-1 ring-blue-700/10 ring-inset">{'특허'}</span>
                              </td>
                              <td className="px-4 py-3.5 font-medium">{'홍길동'}</td>
                              <td className="px-4 py-3.5 text-muted-foreground">{'(기타 7건의 특허 실적 포함)'}</td>
                              <td className="px-4 py-3.5 text-center text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 font-semibold">{'(특허 총 8건)'}</td>
                            </tr>
                            {/* 기술이전 */}
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5 text-center">{'1'}</td>
                              <td className="px-4 py-3.5">
                                <span className="inline-flex items-center rounded-md bg-green-50 px-2 py-1 text-xs font-medium text-green-700 ring-1 ring-green-700/10 ring-inset">{'기술이전'}</span>
                              </td>
                              <td className="px-4 py-3.5 font-medium">{'이순신'}</td>
                              <td className="px-4 py-3.5 text-muted-foreground">{'(기술이전 명칭)'}</td>
                              <td className="px-4 py-3.5 text-center">{'2024.11.'}</td>
                              <td className="px-4 py-3.5 font-semibold text-blue-600">{'총 기술료: 30,000,000원'}</td>
                            </tr>
                            <tr className="transition-colors hover:bg-secondary/30 bg-secondary/20">
                              <td className="px-4 py-3.5 text-center">{'2'}</td>
                              <td className="px-4 py-3.5">
                                <span className="inline-flex items-center rounded-md bg-green-50 px-2 py-1 text-xs font-medium text-green-700 ring-1 ring-green-700/10 ring-inset">{'기술이전'}</span>
                              </td>
                              <td className="px-4 py-3.5 font-medium">{'홍길순'}</td>
                              <td className="px-4 py-3.5 text-muted-foreground">{'(기타 1건의 기술이전 실적 포함)'}</td>
                              <td className="px-4 py-3.5 text-center text-muted-foreground">{'-'}</td>
                              <td className="px-4 py-3.5 font-semibold">{'(기술이전 총 2건)'}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                      {/* 요약 카드 */}
                      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                        <div className="rounded-lg border border-border bg-blue-50/50 p-4">
                          <p className="text-xs text-muted-foreground">{'특허 실적'}</p>
                          <p className="mt-1 text-2xl font-bold text-blue-700">{'8건'}</p>
                        </div>
                        <div className="rounded-lg border border-border bg-green-50/50 p-4">
                          <p className="text-xs text-muted-foreground">{'기술이전 실적'}</p>
                          <p className="mt-1 text-2xl font-bold text-green-700">{'2건'}</p>
                        </div>
                        <div className="rounded-lg border border-border bg-amber-50/50 p-4">
                          <p className="text-xs text-muted-foreground">{'총 기술료'}</p>
                          <p className="mt-1 text-2xl font-bold text-amber-700">{'30,000,000원'}</p>
                        </div>
                      </div>
                    </div>
                  ) : indicator.id === "international" ? (
                    <div className="space-y-4">
                      <p className="text-sm text-muted-foreground">
                        {'교육연구단 국제공동연구 실적'}
                      </p>
                      <div className="overflow-x-auto rounded-lg border border-border">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b border-border bg-secondary/50">
                              <th className="px-4 py-3.5 text-center font-semibold text-foreground w-16">{'연번'}</th>
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground w-24">{'참여교수'}</th>
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'국외 공동연구자'}</th>
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'상대국/소속기관'}</th>
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'국제 공동연구 실적 (논문/과제명)'}</th>
                              <th className="px-4 py-3.5 text-left font-semibold text-foreground">{'DOI / Link'}</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5 text-center">{'1'}</td>
                              <td className="px-4 py-3.5 font-medium">{'김OO'}</td>
                              <td className="px-4 py-3.5">{'Prof. Robert Lewis'}</td>
                              <td className="px-4 py-3.5">
                                <span className="inline-flex items-center rounded-md bg-blue-50 px-2 py-1 text-xs font-medium text-blue-700 ring-1 ring-blue-700/10 ring-inset">{'미국'}</span>
                                <span className="ml-1 text-muted-foreground">{'/ Georgia Tech'}</span>
                              </td>
                              <td className="px-4 py-3.5 text-xs leading-relaxed">{'AI-driven Generative Design for Energy-Efficient Building Facades'}</td>
                              <td className="px-4 py-3.5">
                                <a href="https://doi.org/10.1016/j.jobe.2024.108241" target="_blank" rel="noopener noreferrer" className="text-xs text-blue-600 underline underline-offset-2 hover:text-blue-800 break-all">{'doi.org/10.1016/j.jobe.2024.108241'}</a>
                              </td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30 bg-secondary/20">
                              <td className="px-4 py-3.5 text-center">{'2'}</td>
                              <td className="px-4 py-3.5 font-medium">{'박OO'}</td>
                              <td className="px-4 py-3.5">{'Prof. Hiroshi Sato'}</td>
                              <td className="px-4 py-3.5">
                                <span className="inline-flex items-center rounded-md bg-red-50 px-2 py-1 text-xs font-medium text-red-700 ring-1 ring-red-700/10 ring-inset">{'일본'}</span>
                                <span className="ml-1 text-muted-foreground">{'/ University of Tokyo'}</span>
                              </td>
                              <td className="px-4 py-3.5 text-xs leading-relaxed">{'Smart City Digital Twin Framework for Urban Heat Island Mitigation'}</td>
                              <td className="px-4 py-3.5">
                                <a href="https://doi.org/10.1016/j.TITS.2024.3350123" target="_blank" rel="noopener noreferrer" className="text-xs text-blue-600 underline underline-offset-2 hover:text-blue-800 break-all">{'doi.org/10.1016/j.TITS.2024.3350123'}</a>
                              </td>
                            </tr>
                            <tr className="border-b border-border transition-colors hover:bg-secondary/30">
                              <td className="px-4 py-3.5 text-center">{'3'}</td>
                              <td className="px-4 py-3.5 font-medium">{'이OO'}</td>
                              <td className="px-4 py-3.5">{'Dr. Elena Rossi'}</td>
                              <td className="px-4 py-3.5">
                                <span className="inline-flex items-center rounded-md bg-green-50 px-2 py-1 text-xs font-medium text-green-700 ring-1 ring-green-700/10 ring-inset">{'이탈리아'}</span>
                                <span className="ml-1 text-muted-foreground">{'/ Politecnico di Milano'}</span>
                              </td>
                              <td className="px-4 py-3.5 text-xs leading-relaxed">{'Preservation of Historical Masonry Structures using Carbon Fiber Reinforcement'}</td>
                              <td className="px-4 py-3.5">
                                <a href="https://doi.org/10.1016/j.conbuildmat.2024.134567" target="_blank" rel="noopener noreferrer" className="text-xs text-blue-600 underline underline-offset-2 hover:text-blue-800 break-all">{'doi.org/10.1016/j.conbuildmat.2024.134567'}</a>
                              </td>
                            </tr>
                            <tr className="transition-colors hover:bg-secondary/30 bg-secondary/20">
                              <td className="px-4 py-3.5 text-center">{'4'}</td>
                              <td className="px-4 py-3.5 font-medium">{'최OO'}</td>
                              <td className="px-4 py-3.5">{'Prof. David Chen'}</td>
                              <td className="px-4 py-3.5">
                                <span className="inline-flex items-center rounded-md bg-amber-50 px-2 py-1 text-xs font-medium text-amber-700 ring-1 ring-amber-700/10 ring-inset">{'싱가포르'}</span>
                                <span className="ml-1 text-muted-foreground">{'/ NUS'}</span>
                              </td>
                              <td className="px-4 py-3.5 text-xs leading-relaxed">{'Optimization of HVAC Systems using Multi-Agent Reinforcement Learning'}</td>
                              <td className="px-4 py-3.5">
                                <a href="https://doi.org/10.1016/j.enbuild.2024.113892" target="_blank" rel="noopener noreferrer" className="text-xs text-blue-600 underline underline-offset-2 hover:text-blue-800 break-all">{'doi.org/10.1016/j.enbuild.2024.113892'}</a>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                      {/* 요약 */}
                      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                        <div className="rounded-lg border border-border bg-cyan-50/50 p-4">
                          <p className="text-xs text-muted-foreground">{'국제공동연구 건수'}</p>
                          <p className="mt-1 text-2xl font-bold text-cyan-700">{'4건'}</p>
                        </div>
                        <div className="rounded-lg border border-border bg-cyan-50/50 p-4">
                          <p className="text-xs text-muted-foreground">{'참여교수 수'}</p>
                          <p className="mt-1 text-2xl font-bold text-cyan-700">{'4명'}</p>
                        </div>
                        <div className="rounded-lg border border-border bg-cyan-50/50 p-4">
                          <p className="text-xs text-muted-foreground">{'협력 국가 수'}</p>
                          <p className="mt-1 text-2xl font-bold text-cyan-700">{'4개국'}</p>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">
                      {'엑셀 파일을 업로드하면 데이터가 여기에 표시됩니다.'}
                    </p>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
