"use client"

import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Target,
  TrendingUp,
  ArrowRight,
  BookOpen,
  FlaskConical,
  Handshake,
  Globe,
  Users,
  GraduationCap,
  DollarSign,
  Briefcase,
  Lightbulb,
} from "lucide-react"
import {
  coreFields,
  getFieldStats,
  getOverallCoreStats,
} from "@/lib/core-indicators-data"
import {
  getOverallStats as getAutonomousOverallStats,
  getCategoryStats,
  categoryOrder,
  categoryColors,
} from "@/lib/autonomous-indicators-data"

const fieldIcons: Record<string, React.ElementType> = {
  "교육": BookOpen,
  "연구": FlaskConical,
  "산학협력": Handshake,
  "국제화": Globe,
}

export default function DashboardPage() {
  const coreStats = getOverallCoreStats()
  const autoStats = getAutonomousOverallStats()
  const fieldStats = getFieldStats()
  const catStats = getCategoryStats()

  return (
    <div className="flex flex-col gap-6 p-4 md:gap-8 md:p-8">
      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-foreground/5">
              <TrendingUp className="h-5 w-5 text-foreground" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{"종합 달성률"}</p>
              <p className="text-2xl font-bold text-foreground">
                {`${Math.round((coreStats.avgAchievement + autoStats.avgAchievement) / 2)}%`}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10">
              <Target className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{"핵심성과지표"}</p>
              <p className="text-2xl font-bold text-foreground">
                {`${coreStats.avgAchievement}%`}
              </p>
              <p className="text-xs text-muted-foreground">
                {`${coreStats.achieved}/${coreStats.parentCount}개 달성`}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#16A34A]/10">
              <TrendingUp className="h-5 w-5 text-[#16A34A]" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{"자율성과지표"}</p>
              <p className="text-2xl font-bold text-foreground">
                {`${autoStats.avgAchievement}%`}
              </p>
              <p className="text-xs text-muted-foreground">
                {`${autoStats.achieved}/${autoStats.total}개 달성`}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Core Performance - field cards */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-4">
          <CardTitle className="text-base font-bold">{"핵심성과지표 분야별 달성률"}</CardTitle>
          <Link
            href="/performance/core"
            className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            {"상세보기"}
            <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {fieldStats.map((stat) => {
              const Icon = fieldIcons[stat.field] ?? Target
              return (
                <div
                  key={stat.field}
                  className="rounded-lg border border-border p-4"
                >
                  <div className="flex items-center gap-2.5 mb-3">
                    <div
                      className="flex h-8 w-8 items-center justify-center rounded-lg"
                      style={{ backgroundColor: `${stat.color}15` }}
                    >
                      <Icon className="h-4 w-4" style={{ color: stat.color }} />
                    </div>
                    <span className="text-sm font-semibold text-foreground">{stat.field}</span>
                  </div>
                  <div className="flex items-end justify-between mb-2">
                    <span className="text-2xl font-bold" style={{ color: stat.color }}>
                      {`${stat.avgAchievement}%`}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {`${stat.parentCount}개 지표`}
                    </span>
                  </div>
                  <div className="h-1.5 w-full rounded-full bg-border overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{
                        width: `${Math.min(stat.avgAchievement, 100)}%`,
                        backgroundColor: stat.color,
                      }}
                    />
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Autonomous Performance - all 12 categories */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-4">
          <CardTitle className="text-base font-bold">{"자율성과지표 카테고리별 현황"}</CardTitle>
          <Link
            href="/performance/autonomous"
            className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            {"상세보기"}
            <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {categoryOrder.map((cat) => {
              const s = catStats[cat]
              if (!s || s.count === 0) return null
              const avg = Math.round(s.totalAchievement / s.count)
              const achieved = s.items.filter((i) => i.achievementPercent >= 100).length
              const color = categoryColors[cat] || "#64748B"

              return (
                <div
                  key={cat}
                  className="flex items-center gap-3 rounded-lg border border-border p-3.5"
                >
                  <div
                    className="h-9 w-1 shrink-0 rounded-full"
                    style={{ backgroundColor: color }}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-sm font-semibold text-foreground truncate pr-2">{cat}</span>
                      <span className="text-base font-bold shrink-0" style={{ color }}>
                        {`${avg}%`}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-1.5 rounded-full bg-border overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all"
                          style={{
                            width: `${Math.min(avg, 100)}%`,
                            backgroundColor: color,
                          }}
                        />
                      </div>
                      <span className="text-xs text-muted-foreground shrink-0">
                        {`${achieved}/${s.count}`}
                      </span>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Research Team Summary */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-4">
          <CardTitle className="text-base font-bold">{"교육연구단 성과 요약"}</CardTitle>
          <Link
            href="/research-team"
            className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            {"상세보기"}
            <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div className="rounded-lg border border-border p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#DC2626]/10">
                  <Users className="h-4 w-4 text-[#DC2626]" />
                </div>
                <span className="text-sm font-semibold text-foreground">{"전임교수"}</span>
              </div>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-bold text-foreground">{"10"}</span>
                <span className="text-sm text-muted-foreground">{"명"}</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">{"참여교수 7명 (70%)"}</p>
            </div>

            <div className="rounded-lg border border-border p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#4F46E5]/10">
                  <GraduationCap className="h-4 w-4 text-[#4F46E5]" />
                </div>
                <span className="text-sm font-semibold text-foreground">{"대학원생"}</span>
              </div>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-bold text-foreground">{"34"}</span>
                <span className="text-sm text-muted-foreground">{"명"}</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">{"석사 20 / 박사 6 / 통합 8"}</p>
            </div>

            <div className="rounded-lg border border-border p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#16A34A]/10">
                  <DollarSign className="h-4 w-4 text-[#16A34A]" />
                </div>
                <span className="text-sm font-semibold text-foreground">{"연구비 수주"}</span>
              </div>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-bold text-foreground">{"34.4"}</span>
                <span className="text-sm text-muted-foreground">{"억원"}</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">{"1인당 5.2억 (최근 1년)"}</p>
            </div>

            <div className="rounded-lg border border-border p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#D97706]/10">
                  <Lightbulb className="h-4 w-4 text-[#D97706]" />
                </div>
                <span className="text-sm font-semibold text-foreground">{"특허/기술이전"}</span>
              </div>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-bold text-foreground">{"10"}</span>
                <span className="text-sm text-muted-foreground">{"건"}</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">{"특허 8건 / 기술이전 2건"}</p>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-3 mt-4">
            <div className="rounded-lg border border-border p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#7C3AED]/10">
                  <Globe className="h-4 w-4 text-[#7C3AED]" />
                </div>
                <span className="text-sm font-semibold text-foreground">{"국제공동연구"}</span>
              </div>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-bold text-foreground">{"4"}</span>
                <span className="text-sm text-muted-foreground">{"건"}</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">{"미국, 일본, 독일, 호주"}</p>
            </div>

            <div className="rounded-lg border border-border p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#DB2777]/10">
                  <Briefcase className="h-4 w-4 text-[#DB2777]" />
                </div>
                <span className="text-sm font-semibold text-foreground">{"취업 현황"}</span>
              </div>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-bold text-foreground">{"75%"}</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">{"2024년 8월 졸업생 기준"}</p>
            </div>

            <div className="rounded-lg border border-border p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#0891B2]/10">
                  <TrendingUp className="h-4 w-4 text-[#0891B2]" />
                </div>
                <span className="text-sm font-semibold text-foreground">{"대학원생 확보"}</span>
              </div>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-bold text-foreground">{"88.2%"}</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">{"2025년 1학기 참여 비율"}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
