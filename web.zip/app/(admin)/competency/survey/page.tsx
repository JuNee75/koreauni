"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import {
  Plus,
  Trash2,
  ChevronRight,
  Save,
  FileText,
  Settings,
  Edit,
  Send,
  CheckCircle2,
  Layers,
  ClipboardList,
  BarChart3
} from "lucide-react"

// 타입 정의
interface ScoreInterpretation {
  basic: { description: string }
  normal: { description: string }
  excellent: { description: string }
  outstanding: { description: string }
}

// 역량 레벨별 점수 구간 설정
interface ScoreRange {
  basic: { min: number; max: number }
  normal: { min: number; max: number }
  excellent: { min: number; max: number }
  outstanding: { min: number; max: number }
}

// 선택형 옵션 - 코드명 기반
interface ChoiceOption {
  id: string
  code: string  // A, B, C, D 등의 코드명
  weight: number  // 해당 코드의 점수
}

interface AnswerOption {
  id: string
  text: string
  weight: number
}

// 선택형 문항의 보기
interface QuestionChoice {
  code: string  // A, B, C 등 (역량 설정의 코드명과 연동)
  text: string  // 보기 내용
  weight: number  // 연동된 점수
}

interface Question {
  id: string
  text: string
  weight: number
  answers: AnswerOption[]  // 빈도형용
  choices: QuestionChoice[]  // 선택형용 보기
}

interface CalculationFormula {
  type: "sum" | "average" | "weighted_average" | "custom"
  customFormula?: string
}

interface SubCategory {
  id: string
  name: string
  weight: number  // 가중치 (총합 100%)
  questions: Question[]
  scoreInterpretation: ScoreInterpretation
}

interface Category {
  id: string
  name: string
  subCategories: SubCategory[]
}

interface Competency {
  id: string
  name: string
  answerType: "frequency" | "choice"
  calculationFormula: CalculationFormula
  frequencyOptions: AnswerOption[]
  choiceOptions: ChoiceOption[]  // 코드명 기반
  categories: Category[]
  scoreRange: ScoreRange  // 점수 구간 설정
  isDeployed?: boolean
  deployedAt?: string
}

// 초기 데이터
const initialCompetencies: Competency[] = [
  {
    id: "1",
    name: "학습연구역량",
    answerType: "choice",
    calculationFormula: { type: "weighted_average" },
    frequencyOptions: [],
    choiceOptions: [
      { id: "c1", code: "A", weight: 4 },
      { id: "c2", code: "B", weight: 3 },
      { id: "c3", code: "C", weight: 2 },
      { id: "c4", code: "D", weight: 1 },
    ],
    scoreRange: {
      basic: { min: 0, max: 25 },
      normal: { min: 26, max: 50 },
      excellent: { min: 51, max: 75 },
      outstanding: { min: 76, max: 100 }
    },
    categories: [
      {
        id: "1-1",
        name: "성격특성",
        subCategories: [
          {
            id: "1-1-1",
            name: "학업적 효능감",
            weight: 34,
            questions: [
              {
                id: "q1-1-1-1",
                text: "귀하는 현재 자신의 연구수행능력과 학업적 도전 상황에 대해 어떤 행동을 보이는지를 가장 잘 설명하는 문장을 하나 선택해 주십시오.",
                weight: 100,
                answers: [],
                choices: [
                  { code: "A", text: "나는 동료나 후배 연구자의 효능감 저하 원인을 진단하고 그들이 작은 성공 경험을 통해 스스로 효능감을 회복하도록 코칭한다.", weight: 4 },
                  { code: "B", text: "나는 연구 결과가 예상과 다르거나 진행이 막히는 상황에서도 실패 요인을 분석하여 대안을 마련하고 끝까지 완수한다.", weight: 3 },
                  { code: "C", text: "나는 전공 연구 프로젝트 수행 시 세세한 지시 없이도 자신의 지식과 기술을 응용하여 독자적으로 과업을 완수한다.", weight: 2 },
                  { code: "D", text: "나는 연구 진행의 매 단계마다 지도교수나 선배의 구체적인 피드백과 확인이 있어야만 다음 단계로 이행한다.", weight: 1 }
                ]
              }
            ],
            scoreInterpretation: {
              basic: { description: "학업적 효능감이 낮은 수준입니다." },
              normal: { description: "학업적 효능감이 보통 수준입니다." },
              excellent: { description: "학업적 효능감이 우수한 수준입니다." },
              outstanding: { description: "학업적 효능감이 탁월한 수준입니다." }
            }
          },
          {
            id: "1-1-2",
            name: "학업적 회복탄력성",
            weight: 33,
            questions: [
              {
                id: "q1-1-2-1",
                text: "귀하는 현재 연구 수행 중 겪게 되는 실패나 스트레스 상황에 대해 어떤 행동을 보이는지를 가장 잘 설명하는 문장을 하나 선택해 주십시오.",
                weight: 100,
                answers: [],
                choices: [
                  { code: "A", text: "나는 데이터 손실이나 프로젝트 중단 등 팀 차원의 위기 상황에서 침착함을 유지하며, 팀원들을 독려하여 대안적 해결책을 찾도록 이끈다.", weight: 4 },
                  { code: "B", text: "나는 가설 기각이나 실험 실패를 단순한 오류가 아닌 '새로운 발견을 위한 데이터'로 재해석하여 연구 방향을 발전적으로 수정한다.", weight: 3 },
                  { code: "C", text: "나는 연구 난항이나 심사 탈락 시 일시적으로 실망할 수 있으나, 스스로 감정을 추스르고 수정 작업이나 재실험을 재개한다.", weight: 2 },
                  { code: "D", text: "나는 논문 투고 거절이나 부정적인 피드백을 받으면 심하게 위축되어 연구실 출입을 기피하거나 학업 수행을 중단한다.", weight: 1 }
                ]
              }
            ],
            scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } }
          },
          {
            id: "1-1-3",
            name: "성실성 및 책임감",
            weight: 33,
            questions: [
              {
                id: "q1-1-3-1",
                text: "귀하는 연구 및 학업 계획의 이행과 마감 기한 준수에 대해 현재 어떤 행동을 보이는지를 가장 잘 설명하는 문장을 하나 선택해 주십시오.",
                weight: 100,
                answers: [],
                choices: [
                  { code: "A", text: "나는 공동 연구 시 자신의 역할을 넘어 팀 전체의 중요한 일정을 점검하고, 나태해지는 동료를 독려하여 프로젝트를 기한 내 끝마친다.", weight: 4 },
                  { code: "B", text: "나는 다수의 과제가 동시에 주어졌을 때 중요도와 긴급성을 판단하여 우선순위를 재조정함으로써 누락 없이 모든 과업을 완수한다.", weight: 3 },
                  { code: "C", text: "나는 학기 중 수업 과제나 실험 일정을 스스로 수립하고, 타율적인 통제 없이도 계획대로 꾸준히 실행한다.", weight: 2 },
                  { code: "D", text: "나는 구체적인 지시나 마감 독촉이 있을 때만 연구 과제를 수행하며, 스스로 계획을 세워 준비하는 행동이 부족하다.", weight: 1 }
                ]
              }
            ],
            scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } }
          }
        ]
      },
      {
        id: "1-2",
        name: "행동특성",
        subCategories: [
          { id: "1-2-1", name: "시간관리", weight: 34, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
          { id: "1-2-2", name: "집중력 및 학습환경 관리", weight: 33, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
          { id: "1-2-3", name: "학습전략 및 정보처리", weight: 33, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } }
        ]
      },
      {
        id: "1-3",
        name: "연구관련 역량",
        subCategories: [
          { id: "1-3-1", name: "연구설계 및 수행능력", weight: 34, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
          { id: "1-3-2", name: "연구윤리 및 진실성", weight: 33, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
          { id: "1-3-3", name: "연구프로젝트 관리", weight: 33, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } }
        ]
      },
      {
        id: "1-4",
        name: "자기주도학습",
        subCategories: [
          { id: "1-4-1", name: "학습동기 및 목표설정", weight: 34, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
          { id: "1-4-2", name: "자기평가 및 성찰", weight: 33, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
          { id: "1-4-3", name: "자원활용 및 네트워킹", weight: 33, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } }
        ]
      }
    ]
  },
  {
    id: "2",
    name: "융합연구역량",
    answerType: "frequency",
    calculationFormula: { type: "weighted_average" },
    frequencyOptions: [
      { id: "f1", text: "매우그렇다", weight: 5 },
      { id: "f2", text: "그렇다", weight: 4 },
      { id: "f3", text: "보통이다", weight: 3 },
      { id: "f4", text: "그렇지않다", weight: 2 },
      { id: "f5", text: "전혀그렇지않다", weight: 1 },
    ],
    choiceOptions: [],
    scoreRange: {
      basic: { min: 0, max: 25 },
      normal: { min: 26, max: 50 },
      excellent: { min: 51, max: 75 },
      outstanding: { min: 76, max: 100 }
    },
    categories: [
      {
        id: "2-1",
        name: "창의·비판적 사고 역량",
        subCategories: [
          {
            id: "2-1-1", name: "논리적 추론", weight: 25, questions: [
              { id: "q2-1-1-1", text: "나는 상충하는 복잡한 연구 데이터나 제반 이론들에 대해 객관적 기준을 적용하여 논리적 정합성을 검증한다.", weight: 34, answers: [], choices: [] },
              { id: "q2-1-1-2", text: "나는 주관적 추측을 배제하고 실증적 데이터와 사실에 기반하여 타당한 결론을 도출한다.", weight: 33, answers: [], choices: [] },
              { id: "q2-1-1-3", text: "나는 기존 연구 자료에서 논리적 비약이나 타당하지 않은 주장을 스스로 식별할 수 있다.", weight: 33, answers: [], choices: [] }
            ], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } }
          },
          { id: "2-1-2", name: "다학제간 통찰", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
          { id: "2-1-3", name: "독창적 발상", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
          { id: "2-1-4", name: "메타인지적 성찰", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } }
        ]
      },
      {
        id: "2-2",
        name: "분석적 문제해결 역량",
        subCategories: [
          { id: "2-2-1", name: "연구문제 구조화", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
          { id: "2-2-2", name: "증거기반 분석", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
          { id: "2-2-3", name: "논리적 대안 탐색", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
          { id: "2-2-4", name: "연구결과 평가", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } }
        ]
      },
      {
        id: "2-3",
        name: "협력적 의사소통 역량",
        subCategories: [
          { id: "2-3-1", name: "글로벌 소통", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
          { id: "2-3-2", name: "협력설계", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
          { id: "2-3-3", name: "협력 프로세스 관리", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
          { id: "2-3-4", name: "갈등 중재 및 관리", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } }
        ]
      },
      {
        id: "2-4",
        name: "신뢰기반 리더십 역량",
        subCategories: [
          { id: "2-4-1", name: "연구윤리 실천", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
          { id: "2-4-2", name: "다양성 존중", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
          { id: "2-4-3", name: "연구목표 정렬", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
          { id: "2-4-4", name: "성장지원", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } }
        ]
      }
    ]
  }
]

export default function SurveyManagementPage() {
  const [competencies, setCompetencies] = useState<Competency[]>(initialCompetencies)
  const [selectedCompetency, setSelectedCompetency] = useState<Competency | null>(competencies[0] || null)
  const [selectedCategoryId, setSelectedCategoryId] = useState<string | null>(null)
  const [selectedSubCategoryId, setSelectedSubCategoryId] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState("questions")

  // 모달 상태
  const [isCompetencyModalOpen, setIsCompetencyModalOpen] = useState(false)
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false)
  const [isSubCategoryModalOpen, setIsSubCategoryModalOpen] = useState(false)
  const [isQuestionModalOpen, setIsQuestionModalOpen] = useState(false)
  const [isInterpretationModalOpen, setIsInterpretationModalOpen] = useState(false)
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false)
  const [isDeployModalOpen, setIsDeployModalOpen] = useState(false)
  const [deploySuccess, setDeploySuccess] = useState(false)
  const [isEditQuestionModalOpen, setIsEditQuestionModalOpen] = useState(false)

  // 배포 폼
  const [deployForm, setDeployForm] = useState({ name: "", year: new Date().getFullYear().toString(), semester: "1" })
  const [deployingCompetency, setDeployingCompetency] = useState<Competency | null>(null)

  // 폼 상태
  const [newCompetencyName, setNewCompetencyName] = useState("")
  const [newCategoryName, setNewCategoryName] = useState("")
  const [newSubCategoryName, setNewSubCategoryName] = useState("")
  const [newQuestionText, setNewQuestionText] = useState("")
  const [newQuestionWeight, setNewQuestionWeight] = useState(100)  // 기본값 100
  const [newQuestionChoices, setNewQuestionChoices] = useState<QuestionChoice[]>([])
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null)

  // 역량 설정 폼
  const [settingsForm, setSettingsForm] = useState<{
    answerType: "frequency" | "choice"
    calculationFormula: CalculationFormula
    frequencyOptions: AnswerOption[]
    choiceOptions: ChoiceOption[]
    scoreRange: ScoreRange
  }>({
    answerType: "frequency",
    calculationFormula: { type: "weighted_average" },
    frequencyOptions: [
      { id: "f1", text: "매우그렇다", weight: 5 },
      { id: "f2", text: "그렇다", weight: 4 },
      { id: "f3", text: "보통이다", weight: 3 },
      { id: "f4", text: "그렇지않다", weight: 2 },
      { id: "f5", text: "전혀그렇지않다", weight: 1 },
    ],
    choiceOptions: [],
    scoreRange: {
      basic: { min: 0, max: 25 },
      normal: { min: 26, max: 50 },
      excellent: { min: 51, max: 75 },
      outstanding: { min: 76, max: 100 }
    }
  })

  // 점수해석 폼
  const [interpretationForm, setInterpretationForm] = useState<ScoreInterpretation>({
    basic: { description: "" },
    normal: { description: "" },
    excellent: { description: "" },
    outstanding: { description: "" }
  })

  // 현재 선택된 역량/카테고리/세부항목 가져오기
  const currentCompetency = competencies.find(c => c.id === selectedCompetency?.id) || null
  const currentCategory = currentCompetency?.categories.find(c => c.id === selectedCategoryId) || null
  const currentSubCategory = currentCategory?.subCategories.find(s => s.id === selectedSubCategoryId) || null

  // 모든 문항 가져오기 (필터링 포함)
  const getAllQuestions = () => {
    if (!currentCompetency) return []

    const questions: { question: Question; categoryName: string; subCategoryName: string; categoryId: string; subCategoryId: string }[] = []

    currentCompetency.categories.forEach(cat => {
      // 카테고리가 선택된 경우 해당 카테고리만
      if (selectedCategoryId && cat.id !== selectedCategoryId) return

      cat.subCategories.forEach(sub => {
        sub.questions.forEach(q => {
          questions.push({
            question: q,
            categoryName: cat.name,
            subCategoryName: sub.name,
            categoryId: cat.id,
            subCategoryId: sub.id
          })
        })
      })
    })

    return questions
  }

  // 통계
  const getTotalQuestions = (comp: Competency) => {
    return comp.categories.reduce((sum, cat) =>
      sum + cat.subCategories.reduce((s, sub) => s + sub.questions.length, 0), 0)
  }

  const getTotalSubCategories = (comp: Competency) => {
    return comp.categories.reduce((sum, cat) => sum + cat.subCategories.length, 0)
  }

  // 현재 세부항목의 사용된 가중치 합계
  const getUsedQuestionWeight = (subCategory: SubCategory | null) => {
    if (!subCategory) return 0
    return subCategory.questions.reduce((sum, q) => sum + q.weight, 0)
  }

  // 남은 가중치
  const getRemainingQuestionWeight = () => {
    if (!currentSubCategory) return 100
    return Math.max(0, 100 - getUsedQuestionWeight(currentSubCategory))
  }

  // 세부항목 가중치 업데이트
  const handleUpdateSubCategoryWeight = (subCategoryId: string, weight: number) => {
    if (!currentCompetency || !currentCategory) return
    setCompetencies(competencies.map(c =>
      c.id === currentCompetency.id ? {
        ...c,
        categories: c.categories.map(cat => cat.id === currentCategory.id ? {
          ...cat,
          subCategories: cat.subCategories.map(sub => sub.id === subCategoryId ? { ...sub, weight } : sub)
        } : cat)
      } : c
    ))
  }

  // 세부항목 가중치 총합 계산
  const getTotalSubCategoryWeight = () => {
    if (!currentCategory) return 0
    return currentCategory.subCategories.reduce((sum, sub) => sum + sub.weight, 0)
  }

  // 역량 추가
  const handleAddCompetency = () => {
    if (!newCompetencyName.trim()) return
    const newCompetency: Competency = {
      id: `comp-${Date.now()}`,
      name: newCompetencyName,
      answerType: "frequency",
      calculationFormula: { type: "weighted_average" },
      frequencyOptions: [
        { id: "f1", text: "매우그렇다", weight: 5 },
        { id: "f2", text: "그렇다", weight: 4 },
        { id: "f3", text: "보통이다", weight: 3 },
        { id: "f4", text: "그렇지않다", weight: 2 },
        { id: "f5", text: "전혀그렇지않다", weight: 1 },
      ],
      choiceOptions: [],
      scoreRange: {
        basic: { min: 0, max: 25 },
        normal: { min: 26, max: 50 },
        excellent: { min: 51, max: 75 },
        outstanding: { min: 76, max: 100 }
      },
      categories: []
    }
    setCompetencies([...competencies, newCompetency])
    setNewCompetencyName("")
    setIsCompetencyModalOpen(false)
  }

  // 역량 삭제
  const handleDeleteCompetency = (id: string) => {
    const updated = competencies.filter(c => c.id !== id)
    setCompetencies(updated)
    if (selectedCompetency?.id === id) {
      setSelectedCompetency(updated[0] || null)
      setSelectedCategoryId(null)
      setSelectedSubCategoryId(null)
    }
  }

  // 역량 선택
  const handleSelectCompetency = (comp: Competency) => {
    setSelectedCompetency(comp)
    setSelectedCategoryId(null)
    setSelectedSubCategoryId(null)
  }

  // 카테고리 추가
  const handleAddCategory = () => {
    if (!newCategoryName.trim() || !currentCompetency) return
    const newCategory: Category = { id: `cat-${Date.now()}`, name: newCategoryName, subCategories: [] }
    setCompetencies(competencies.map(c =>
      c.id === currentCompetency.id ? { ...c, categories: [...c.categories, newCategory] } : c
    ))
    setNewCategoryName("")
    setIsCategoryModalOpen(false)
  }

  // 카테고리 삭제
  const handleDeleteCategory = (categoryId: string) => {
    if (!currentCompetency) return
    setCompetencies(competencies.map(c =>
      c.id === currentCompetency.id ? { ...c, categories: c.categories.filter(cat => cat.id !== categoryId) } : c
    ))
    if (selectedCategoryId === categoryId) {
      setSelectedCategoryId(null)
      setSelectedSubCategoryId(null)
    }
  }

  // 세부항목 추가
  const handleAddSubCategory = () => {
    if (!newSubCategoryName.trim() || !currentCompetency || !currentCategory) return
    const newSubCategory: SubCategory = {
      id: `sub-${Date.now()}`,
      name: newSubCategoryName,
      weight: 0,  // 기본값 0, 나중에 조정
      questions: [],
      scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } }
    }
    setCompetencies(competencies.map(c =>
      c.id === currentCompetency.id ? {
        ...c,
        categories: c.categories.map(cat => cat.id === currentCategory.id ? { ...cat, subCategories: [...cat.subCategories, newSubCategory] } : cat)
      } : c
    ))
    setNewSubCategoryName("")
    setIsSubCategoryModalOpen(false)
  }

  // 세부항목 삭제
  const handleDeleteSubCategory = (subCategoryId: string) => {
    if (!currentCompetency || !currentCategory) return
    setCompetencies(competencies.map(c =>
      c.id === currentCompetency.id ? {
        ...c,
        categories: c.categories.map(cat => cat.id === currentCategory.id ? { ...cat, subCategories: cat.subCategories.filter(sub => sub.id !== subCategoryId) } : cat)
      } : c
    ))
    if (selectedSubCategoryId === subCategoryId) setSelectedSubCategoryId(null)
  }

  // 문항 추가
  const handleAddQuestion = () => {
    if (!newQuestionText.trim() || !currentCompetency || !currentCategory || !currentSubCategory) return

    const newQuestion: Question = {
      id: `q-${Date.now()}`,
      text: newQuestionText,
      weight: newQuestionWeight,
      answers: [],
      choices: currentCompetency.answerType === "choice" ? newQuestionChoices : []
    }

    setCompetencies(competencies.map(c =>
      c.id === currentCompetency.id ? {
        ...c,
        categories: c.categories.map(cat => cat.id === currentCategory.id ? {
          ...cat,
          subCategories: cat.subCategories.map(sub => sub.id === currentSubCategory.id ? { ...sub, questions: [...sub.questions, newQuestion] } : sub)
        } : cat)
      } : c
    ))

    setNewQuestionText("")
    setNewQuestionWeight(10)
    setNewQuestionChoices([])
    setIsQuestionModalOpen(false)
  }

  // 문항 수정
  const handleUpdateQuestion = (targetCategoryId: string, targetSubCategoryId: string) => {
    if (!editingQuestion || !currentCompetency) return

    setCompetencies(competencies.map(c =>
      c.id === currentCompetency.id ? {
        ...c,
        categories: c.categories.map(cat => cat.id === targetCategoryId ? {
          ...cat,
          subCategories: cat.subCategories.map(sub => sub.id === targetSubCategoryId ? {
            ...sub,
            questions: sub.questions.map(q => q.id === editingQuestion.id ? editingQuestion : q)
          } : sub)
        } : cat)
      } : c
    ))

    setEditingQuestion(null)
    setIsEditQuestionModalOpen(false)
  }

  // 문항 삭제
  const handleDeleteQuestion = (questionId: string, targetCategoryId: string, targetSubCategoryId: string) => {
    if (!currentCompetency) return

    setCompetencies(competencies.map(c =>
      c.id === currentCompetency.id ? {
        ...c,
        categories: c.categories.map(cat => cat.id === targetCategoryId ? {
          ...cat,
          subCategories: cat.subCategories.map(sub => sub.id === targetSubCategoryId ? {
            ...sub,
            questions: sub.questions.filter(q => q.id !== questionId)
          } : sub)
        } : cat)
      } : c
    ))
  }

  // 점수해석 저장
  const handleSaveInterpretation = () => {
    if (!currentCompetency || !currentCategory || !currentSubCategory) return
    setCompetencies(competencies.map(c =>
      c.id === currentCompetency.id ? {
        ...c,
        categories: c.categories.map(cat => cat.id === currentCategory.id ? {
          ...cat,
          subCategories: cat.subCategories.map(sub => sub.id === currentSubCategory.id ? { ...sub, scoreInterpretation: interpretationForm } : sub)
        } : cat)
      } : c
    ))
    setIsInterpretationModalOpen(false)
  }

  // 역량 설정 저장
  const handleSaveSettings = () => {
    if (!currentCompetency) return
    setCompetencies(competencies.map(c =>
      c.id === currentCompetency.id ? {
        ...c,
        answerType: settingsForm.answerType,
        calculationFormula: settingsForm.calculationFormula,
        frequencyOptions: settingsForm.frequencyOptions,
        choiceOptions: settingsForm.choiceOptions,
        scoreRange: settingsForm.scoreRange
      } : c
    ))
    setSelectedCompetency({
      ...currentCompetency,
      answerType: settingsForm.answerType,
      calculationFormula: settingsForm.calculationFormula,
      frequencyOptions: settingsForm.frequencyOptions,
      choiceOptions: settingsForm.choiceOptions,
      scoreRange: settingsForm.scoreRange
    })
    setIsSettingsModalOpen(false)
  }

  // 역량 배포
  const handleDeployCompetency = () => {
    if (!deployingCompetency || !deployForm.name.trim()) return
    const deployedVersion = {
      id: `ver-${Date.now()}`,
      name: deployForm.name,
      year: deployForm.year,
      semester: deployForm.semester,
      deployedAt: new Date().toISOString(),
      isActive: false,
      startDate: "",
      endDate: "",
      competencyId: deployingCompetency.id,
      competencyName: deployingCompetency.name,
      competency: JSON.parse(JSON.stringify(deployingCompetency))
    }
    const existingVersions = JSON.parse(localStorage.getItem("surveyVersions") || "[]")
    localStorage.setItem("surveyVersions", JSON.stringify([...existingVersions, deployedVersion]))
    setCompetencies(competencies.map(c =>
      c.id === deployingCompetency.id ? { ...c, isDeployed: true, deployedAt: deployedVersion.deployedAt } : c
    ))
    setDeploySuccess(true)
  }

  // 문항 추가 모달 열기
  const openQuestionModal = () => {
    // 남은 가중치 자동 설정
    const remainingWeight = getRemainingQuestionWeight()
    setNewQuestionWeight(remainingWeight)

    if (currentCompetency?.answerType === "choice" && currentCompetency.choiceOptions.length > 0) {
      setNewQuestionChoices(currentCompetency.choiceOptions.map(opt => ({ code: opt.code, text: "", weight: opt.weight })))
    } else {
      setNewQuestionChoices([])
    }
    setIsQuestionModalOpen(true)
  }

  const allQuestions = getAllQuestions()

  return (
    <div className="p-6 space-y-6">
      {/* 헤더 */}
      <div>
        <h1 className="text-2xl font-bold">설문지관리</h1>
        <p className="text-muted-foreground">핵심역량진단 설문지를 관리합니다.</p>
      </div>

      {/* 역량 목록 */}
      <Card>
        <CardHeader className="py-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Layers className="h-5 w-5" />
                <CardTitle className="text-lg">역량 목록</CardTitle>
              </div>
              {/* 역량 탭메뉴 */}
              <div className="flex items-center gap-1 border rounded-lg p-1 bg-muted/30">
                {competencies.map((comp) => (
                  <button
                    key={comp.id}
                    className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${currentCompetency?.id === comp.id
                      ? "bg-primary text-primary-foreground shadow-sm"
                      : "hover:bg-muted text-muted-foreground hover:text-foreground"
                      }`}
                    onClick={() => handleSelectCompetency(comp)}
                  >
                    {comp.name}
                  </button>
                ))}
              </div>
            </div>
            <Button size="sm" onClick={() => setIsCompetencyModalOpen(true)}>
              <Plus className="h-4 w-4 mr-1" />
              역량 추가
            </Button>
          </div>
        </CardHeader>
        {currentCompetency && (
          <CardContent className="pt-0 pb-2">
            <div className="flex items-center justify-between">
              {/* 역량 정보 - 가독성 향상 */}
              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">카테고리</span>
                  <span className="text-lg font-bold text-primary">{currentCompetency.categories.length}개</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">세부항목</span>
                  <span className="text-lg font-bold text-primary">{getTotalSubCategories(currentCompetency)}개</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">문항</span>
                  <span className="text-lg font-bold text-primary">{getTotalQuestions(currentCompetency)}개</span>
                </div>
                <Separator orientation="vertical" className="h-6" />
                <Badge variant="secondary" className="text-sm px-3 py-1">
                  {currentCompetency.answerType === "frequency" ? "빈도형" : "선택형"}
                </Badge>
                <Badge variant="outline" className="text-sm px-3 py-1">
                  {currentCompetency.calculationFormula.type === "sum" && "단순합계"}
                  {currentCompetency.calculationFormula.type === "average" && "단순평균"}
                  {currentCompetency.calculationFormula.type === "weighted_average" && "가중평균"}
                  {currentCompetency.calculationFormula.type === "custom" && "사용자정의"}
                </Badge>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setSettingsForm({
                      answerType: currentCompetency.answerType,
                      calculationFormula: currentCompetency.calculationFormula,
                      frequencyOptions: currentCompetency.frequencyOptions,
                      choiceOptions: currentCompetency.choiceOptions,
                      scoreRange: currentCompetency.scoreRange
                    })
                    setIsSettingsModalOpen(true)
                  }}
                >
                  <Settings className="h-4 w-4 mr-1" />
                  역량 설정
                </Button>
                <Button
                  variant="default"
                  size="sm"
                  className="bg-blue-600 hover:bg-blue-700"
                  onClick={() => {
                    setDeployingCompetency(currentCompetency)
                    setDeployForm({ name: `${currentCompetency.name} - ${new Date().getFullYear()}년`, year: new Date().getFullYear().toString(), semester: "1" })
                    setDeploySuccess(false)
                    setIsDeployModalOpen(true)
                  }}
                >
                  <Send className="h-4 w-4 mr-1" />
                  배포
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-destructive hover:text-destructive"
                  onClick={() => {
                    if (confirm(`"${currentCompetency.name}" 역량을 삭제하시겠습니까?`)) handleDeleteCompetency(currentCompetency.id)
                  }}
                >
                  <Trash2 className="h-4 w-4 mr-1" />
                  삭제
                </Button>
              </div>
            </div>
          </CardContent>
        )}
      </Card>

      {/* 탭 */}
      {currentCompetency && (
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="questions" className="text-sm">
              <ClipboardList className="h-4 w-4 mr-1" />
              문항관리
            </TabsTrigger>
            <TabsTrigger value="categories" className="text-sm">
              <Layers className="h-4 w-4 mr-1" />
              카테고리관리
            </TabsTrigger>
            <TabsTrigger value="interpretation" className="text-sm">
              <BarChart3 className="h-4 w-4 mr-1" />
              점수해석
            </TabsTrigger>
          </TabsList>

          {/* 문항관리 탭 */}
          <TabsContent value="questions" className="mt-4">
            <div className="grid grid-cols-12 gap-4">
              {/* 좌측: 카테고리 필터 */}
              <div className="col-span-3">
                <Card>
                  <CardHeader className="py-2 px-3">
                    <CardTitle className="text-sm font-medium">카테고리 필터</CardTitle>
                  </CardHeader>
                  <CardContent className="p-2">
                    <ScrollArea className="h-[480px]">
                      <div className="space-y-1 p-1">
                        <div
                          className={`px-3 py-2 rounded cursor-pointer text-sm ${!selectedCategoryId ? "bg-primary text-primary-foreground" : "hover:bg-muted"}`}
                          onClick={() => { setSelectedCategoryId(null); setSelectedSubCategoryId(null) }}
                        >
                          전체 문항
                        </div>
                        {currentCompetency.categories.map((cat) => (
                          <div key={cat.id}>
                            <div
                              className={`flex items-center gap-2 px-3 py-2 rounded cursor-pointer text-sm ${selectedCategoryId === cat.id ? "bg-muted font-medium" : "hover:bg-muted/50"}`}
                              onClick={() => { setSelectedCategoryId(cat.id); setSelectedSubCategoryId(null) }}
                            >
                              <ChevronRight className={`h-3.5 w-3.5 transition-transform ${selectedCategoryId === cat.id ? "rotate-90" : ""}`} />
                              <span>{cat.name}</span>
                              <Badge variant="secondary" className="ml-auto text-xs px-1.5">
                                {cat.subCategories.reduce((s, sub) => s + sub.questions.length, 0)}
                              </Badge>
                            </div>
                            {selectedCategoryId === cat.id && (
                              <div className="ml-4 space-y-0.5 mt-1">
                                {cat.subCategories.map((sub) => (
                                  <div
                                    key={sub.id}
                                    className={`flex items-center gap-2 px-3 py-1.5 rounded cursor-pointer text-sm ${selectedSubCategoryId === sub.id ? "bg-primary text-primary-foreground" : "hover:bg-muted/50"}`}
                                    onClick={() => setSelectedSubCategoryId(sub.id)}
                                  >
                                    <FileText className="h-3 w-3" />
                                    <span className="truncate">{sub.name}</span>
                                    <Badge variant={selectedSubCategoryId === sub.id ? "secondary" : "outline"} className="ml-auto text-xs px-1">
                                      {sub.questions.length}
                                    </Badge>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </div>

              {/* 우측: 문항 목록 */}
              <div className="col-span-9">
                <Card>
                  <CardHeader className="py-2 px-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm font-medium">
                        {selectedSubCategoryId
                          ? `${currentCategory?.name} > ${currentSubCategory?.name}`
                          : selectedCategoryId
                            ? currentCategory?.name
                            : "전체 문항"
                        }
                        <span className="ml-2 font-normal text-muted-foreground">({allQuestions.length}개)</span>
                      </CardTitle>
                      {selectedSubCategoryId && (
                        <div className="flex items-center gap-3">
                          <div className="flex items-center gap-2 text-sm">
                            <span className="text-muted-foreground">가중치:</span>
                            <span className={`font-medium ${getUsedQuestionWeight(currentSubCategory) === 100 ? "text-green-600" : getUsedQuestionWeight(currentSubCategory) > 100 ? "text-red-600" : "text-amber-600"}`}>
                              {getUsedQuestionWeight(currentSubCategory)}%
                            </span>
                            <span className="text-muted-foreground">/ 100%</span>
                          </div>
                          <Button size="sm" onClick={openQuestionModal}>
                            <Plus className="h-3.5 w-3.5 mr-1" />
                            문항 추가
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="p-2">
                    <ScrollArea className="h-[480px]">
                      {allQuestions.length > 0 ? (
                        <div className="border rounded-lg overflow-hidden">
                          <Table>
                            <TableHeader>
                              <TableRow className="bg-muted/30">
                                <TableHead className="w-10 text-xs">No</TableHead>
                                <TableHead className="text-xs">문항</TableHead>
                                {!selectedCategoryId && <TableHead className="w-28 text-xs">카테고리</TableHead>}
                                {!selectedSubCategoryId && <TableHead className="w-28 text-xs">세부항목</TableHead>}
                                <TableHead className="w-20 text-center text-xs">가중치</TableHead>
                                <TableHead className="w-20 text-center text-xs">관리</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {allQuestions.map((item, idx) => (
                                <TableRow key={item.question.id}>
                                  <TableCell className="text-sm font-medium">{idx + 1}</TableCell>
                                  <TableCell className="text-sm">
                                    {item.question.text}
                                    {currentCompetency.answerType === "choice" && item.question.choices.length > 0 && (
                                      <div className="flex flex-wrap gap-1 mt-1">
                                        {item.question.choices.map((c) => (
                                          <Badge key={c.code} variant="outline" className="text-xs">
                                            {c.code}: {c.text} ({c.weight}점)
                                          </Badge>
                                        ))}
                                      </div>
                                    )}
                                  </TableCell>
                                  {!selectedCategoryId && <TableCell className="text-xs text-muted-foreground">{item.categoryName}</TableCell>}
                                  {!selectedSubCategoryId && <TableCell className="text-xs text-muted-foreground">{item.subCategoryName}</TableCell>}
                                  <TableCell className="text-center">
                                    <Badge variant="secondary" className="text-xs">{item.question.weight}%</Badge>
                                  </TableCell>
                                  <TableCell>
                                    <div className="flex justify-center gap-0.5">
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        className="h-7 w-7"
                                        onClick={() => {
                                          setEditingQuestion({ ...item.question })
                                          setSelectedCategoryId(item.categoryId)
                                          setSelectedSubCategoryId(item.subCategoryId)
                                          setIsEditQuestionModalOpen(true)
                                        }}
                                      >
                                        <Edit className="h-3.5 w-3.5" />
                                      </Button>
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        className="h-7 w-7 text-destructive"
                                        onClick={() => {
                                          if (confirm("문항을 삭제하시겠습니까?")) {
                                            handleDeleteQuestion(item.question.id, item.categoryId, item.subCategoryId)
                                          }
                                        }}
                                      >
                                        <Trash2 className="h-3.5 w-3.5" />
                                      </Button>
                                    </div>
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center justify-center h-[400px] text-muted-foreground border rounded-lg">
                          <ClipboardList className="h-10 w-10 mb-3" />
                          <p className="text-sm">등록된 문항이 없습니다.</p>
                          {selectedSubCategoryId && (
                            <Button variant="link" size="sm" className="mt-1" onClick={openQuestionModal}>
                              문항 추가하기
                            </Button>
                          )}
                          {!selectedSubCategoryId && <p className="text-xs mt-1">좌측에서 세부항목을 선택한 후 문항을 추가하세요.</p>}
                        </div>
                      )}
                    </ScrollArea>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* 카��고리관리 탭 */}
          <TabsContent value="categories" className="mt-4">
            <div className="grid grid-cols-2 gap-4">
              {/* 카테고리 목록 */}
              <Card>
                <CardHeader className="py-2 px-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-medium">카테고리</CardTitle>
                    <Button size="sm" onClick={() => setIsCategoryModalOpen(true)}>
                      <Plus className="h-3.5 w-3.5 mr-1" />
                      추가
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="p-2">
                  <ScrollArea className="h-[380px]">
                    <div className="space-y-2 p-1">
                      {currentCompetency.categories.map((cat) => (
                        <div
                          key={cat.id}
                          className={`flex items-center justify-between p-3 rounded-lg border cursor-pointer text-sm ${selectedCategoryId === cat.id ? "bg-muted border-primary" : "hover:bg-muted/50"}`}
                          onClick={() => { setSelectedCategoryId(cat.id); setSelectedSubCategoryId(null) }}
                        >
                          <div>
                            <span className="font-medium">{cat.name}</span>
                            <span className="text-xs text-muted-foreground ml-2">세부항목 {cat.subCategories.length}개</span>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7 text-destructive"
                            onClick={(e) => {
                              e.stopPropagation()
                              if (confirm(`"${cat.name}" 카테고리를 삭제하시겠습니까?`)) handleDeleteCategory(cat.id)
                            }}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      ))}
                      {currentCompetency.categories.length === 0 && (
                        <div className="text-center py-10 text-muted-foreground text-sm">카테고리가 없습니다.</div>
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              {/* 세부항목 목록 - 가중치 설정 추가 */}
              <Card>
                <CardHeader className="py-2 px-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-sm font-medium">{currentCategory ? `${currentCategory.name} - 세부항목` : "세부항목"}</CardTitle>
                      {currentCategory && (
                        <p className={`text-xs mt-1 ${getTotalSubCategoryWeight() === 100 ? "text-green-600" : getTotalSubCategoryWeight() > 100 ? "text-red-600" : "text-amber-600"}`}>
                          가중치 합계: {getTotalSubCategoryWeight()}% / 100%
                        </p>
                      )}
                    </div>
                    {currentCategory && (
                      <Button size="sm" onClick={() => setIsSubCategoryModalOpen(true)}>
                        <Plus className="h-3.5 w-3.5 mr-1" />
                        추가
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="p-2">
                  <ScrollArea className="h-[380px]">
                    {currentCategory ? (
                      <div className="space-y-2 p-1">
                        {currentCategory.subCategories.map((sub) => (
                          <div key={sub.id} className="flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50">
                            <div className="flex-1">
                              <span className="font-medium text-sm">{sub.name}</span>
                            </div>
                            <div className="flex items-center gap-3">
                              <div className="flex items-center gap-2">
                                <Label className="text-xs text-muted-foreground">가중치</Label>
                                <Input
                                  type="number"
                                  className="w-20 h-8 text-sm text-center"
                                  value={sub.weight}
                                  onChange={(e) => handleUpdateSubCategoryWeight(sub.id, parseInt(e.target.value) || 0)}
                                  min={0}
                                  max={100}
                                />
                                <span className="text-xs text-muted-foreground">%</span>
                              </div>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-7 w-7 text-destructive"
                                onClick={() => {
                                  if (confirm(`"${sub.name}" 세부항목을 삭제하시겠습니까?`)) handleDeleteSubCategory(sub.id)
                                }}
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </Button>
                            </div>
                          </div>
                        ))}
                        {currentCategory.subCategories.length === 0 && (
                          <div className="text-center py-10 text-muted-foreground text-sm">세부항목이 없습니다.</div>
                        )}
                      </div>
                    ) : (
                      <div className="text-center py-10 text-muted-foreground text-sm">카테고리를 선택하세요.</div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* 점수해석 탭 */}
          <TabsContent value="interpretation" className="mt-4">
            <div className="grid grid-cols-12 gap-4">
              {/* 세부항목 선택 */}
              <div className="col-span-4">
                <Card>
                  <CardHeader className="py-2 px-3">
                    <CardTitle className="text-sm font-medium">세부항목 선택</CardTitle>
                  </CardHeader>
                  <CardContent className="p-2">
                    <ScrollArea className="h-[500px]">
                      <div className="space-y-1 p-1">
                        {currentCompetency.categories.map((cat) => (
                          <div key={cat.id}>
                            <div className="px-3 py-2 text-xs font-semibold text-muted-foreground bg-muted/30 rounded">{cat.name}</div>
                            <div className="ml-2 space-y-0.5 mt-1">
                              {cat.subCategories.map((sub) => (
                                <div
                                  key={sub.id}
                                  className={`flex items-center gap-2 px-3 py-2 rounded cursor-pointer text-sm ${selectedSubCategoryId === sub.id ? "bg-primary text-primary-foreground" : "hover:bg-muted/50"}`}
                                  onClick={() => {
                                    setSelectedCategoryId(cat.id)
                                    setSelectedSubCategoryId(sub.id)
                                    setInterpretationForm(sub.scoreInterpretation)
                                  }}
                                >
                                  <FileText className="h-3.5 w-3.5" />
                                  <span>{sub.name}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </div>

              {/* 점수해석 설정 */}
              <div className="col-span-8">
                <Card>
                  <CardHeader className="py-2 px-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-base font-semibold">{currentSubCategory ? currentSubCategory.name : "점수해석 설정"}</CardTitle>
                        {currentSubCategory && (
                          <p className="text-sm text-muted-foreground mt-0.5">각 수준별 해석 설명을 입력하세요.</p>
                        )}
                      </div>
                      {currentSubCategory && (
                        <Button onClick={handleSaveInterpretation}>
                          <Save className="h-4 w-4 mr-2" />
                          저장
                        </Button>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="p-2">
                    {currentSubCategory ? (
                      <div className="grid grid-cols-2 gap-4">
                        {[
                          { key: "basic", label: "기본", color: "border-l-gray-400", bgColor: "bg-gray-50/80", range: currentCompetency?.scoreRange.basic },
                          { key: "normal", label: "보통", color: "border-l-blue-400", bgColor: "bg-blue-50/80", range: currentCompetency?.scoreRange.normal },
                          { key: "excellent", label: "우수", color: "border-l-emerald-400", bgColor: "bg-emerald-50/80", range: currentCompetency?.scoreRange.excellent },
                          { key: "outstanding", label: "탁월", color: "border-l-amber-400", bgColor: "bg-amber-50/80", range: currentCompetency?.scoreRange.outstanding }
                        ].map((level) => (
                          <div key={level.key} className={`rounded-lg border border-l-4 ${level.color} ${level.bgColor} p-4`}>
                            <div className="flex items-center justify-between mb-2">
                              <h4 className="font-semibold text-base">{level.label}</h4>
                              <Badge variant="outline" className="font-mono text-xs">
                                {level.range?.min} ~ {level.range?.max}점
                              </Badge>
                            </div>
                            <Textarea
                              placeholder={`${level.label} 수준의 해석 설명을 입력하세요...`}
                              value={interpretationForm[level.key as keyof ScoreInterpretation].description}
                              onChange={(e) => setInterpretationForm({
                                ...interpretationForm,
                                [level.key]: { description: e.target.value }
                              })}
                              rows={6}
                              className="bg-white resize-none text-sm"
                            />
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center h-[420px] text-muted-foreground border rounded-lg">
                        <BarChart3 className="h-12 w-12 mb-4 text-muted-foreground/50" />
                        <p className="text-base font-medium">세부항목을 선택하세요</p>
                        <p className="text-sm mt-1">좌측 목록에서 점수해석을 설정할 세부항목을 선택해주세요.</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      )}

      {/* 역량 없음 */}
      {competencies.length === 0 && (
        <Card className="py-10">
          <CardContent className="flex flex-col items-center justify-center text-muted-foreground">
            <Layers className="h-10 w-10 mb-3" />
            <p className="text-sm">등록된 역량이 없습니다.</p>
            <Button variant="link" size="sm" className="mt-1" onClick={() => setIsCompetencyModalOpen(true)}>
              역량 추가하기
            </Button>
          </CardContent>
        </Card>
      )}

      {/* 역량 추가 모달 */}
      <Dialog open={isCompetencyModalOpen} onOpenChange={setIsCompetencyModalOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>역량 추가</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1">
              <Label className="text-sm">역량명</Label>
              <Input placeholder="예: 학습연구역량" value={newCompetencyName} onChange={(e) => setNewCompetencyName(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setIsCompetencyModalOpen(false)}>취소</Button>
            <Button size="sm" onClick={handleAddCompetency}>추가</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 카테고리 추가 모달 */}
      <Dialog open={isCategoryModalOpen} onOpenChange={setIsCategoryModalOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>카테고리 추가</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1">
              <Label className="text-sm">카테고리명</Label>
              <Input placeholder="예: 성격특성" value={newCategoryName} onChange={(e) => setNewCategoryName(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setIsCategoryModalOpen(false)}>취소</Button>
            <Button size="sm" onClick={handleAddCategory}>추가</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 세부항목 추가 모달 */}
      <Dialog open={isSubCategoryModalOpen} onOpenChange={setIsSubCategoryModalOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>세부항목 추가</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1">
              <Label className="text-sm">세부항���명</Label>
              <Input placeholder="예: 학업적 효능감" value={newSubCategoryName} onChange={(e) => setNewSubCategoryName(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setIsSubCategoryModalOpen(false)}>취소</Button>
            <Button size="sm" onClick={handleAddSubCategory}>추가</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ���항 추가 모달 */}
      <Dialog open={isQuestionModalOpen} onOpenChange={setIsQuestionModalOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>문항 추가</DialogTitle>
            <DialogDescription className="text-xs">{currentSubCategory?.name}에 새로운 문항을 추가합니다.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1">
              <Label className="text-sm">문항 내용</Label>
              <Textarea placeholder="문항 내용을 입력하세요." value={newQuestionText} onChange={(e) => setNewQuestionText(e.target.value)} rows={2} />
            </div>
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <Label className="text-sm">가중치</Label>
                <span className="text-xs text-muted-foreground">
                  사용 가능: <span className={getRemainingQuestionWeight() > 0 ? "text-green-600" : "text-red-600"}>{getRemainingQuestionWeight()}%</span>
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Input type="number" className="w-24" value={newQuestionWeight} onChange={(e) => setNewQuestionWeight(parseInt(e.target.value) || 0)} min={0} max={100} />
                <span className="text-sm text-muted-foreground">%</span>
              </div>
            </div>

            {/* 빈도형인 경우 */}
            {currentCompetency?.answerType === "frequency" && (
              <div className="bg-muted/50 rounded p-3">
                <p className="text-xs text-muted-foreground mb-1">적용되는 빈도형 답변 옵션:</p>
                <div className="flex flex-wrap gap-1">
                  {currentCompetency.frequencyOptions.map(opt => (
                    <Badge key={opt.id} variant="outline" className="text-xs">{opt.text} ({opt.weight}점)</Badge>
                  ))}
                </div>
              </div>
            )}

            {/* 선택형인 경우 - 보기 입력 */}
            {currentCompetency?.answerType === "choice" && currentCompetency.choiceOptions.length > 0 && (
              <div className="space-y-2">
                <Label className="text-sm">보기 입력</Label>
                <div className="space-y-2">
                  {newQuestionChoices.map((choice, idx) => (
                    <div key={choice.code} className="flex items-center gap-2">
                      <Badge variant="secondary" className="w-8 justify-center">{choice.code}</Badge>
                      <Input
                        className="flex-1"
                        placeholder={`${choice.code} 보기 내용`}
                        value={choice.text}
                        onChange={(e) => {
                          const updated = [...newQuestionChoices]
                          updated[idx] = { ...choice, text: e.target.value }
                          setNewQuestionChoices(updated)
                        }}
                      />
                      <Badge variant="outline" className="w-16 justify-center">{choice.weight}점</Badge>
                    </div>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground">* 보기 수량과 점수는 역량 설정에서 정의된 코드명과 연동됩니다.</p>
              </div>
            )}

            {currentCompetency?.answerType === "choice" && currentCompetency.choiceOptions.length === 0 && (
              <div className="bg-yellow-50 border border-yellow-200 rounded p-3">
                <p className="text-xs text-yellow-800">선택형 답변 옵션이 설정되지 않았습니다. 역량 설정에서 코드명을 먼저 추가해주세요.</p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setIsQuestionModalOpen(false)}>취소</Button>
            <Button size="sm" onClick={handleAddQuestion}>추가</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 문항 수정 모달 */}
      <Dialog open={isEditQuestionModalOpen} onOpenChange={setIsEditQuestionModalOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>문항 수정</DialogTitle>
          </DialogHeader>
          {editingQuestion && (
            <div className="space-y-3 py-2">
              <div className="space-y-1">
                <Label className="text-sm">문항 내용</Label>
                <Textarea value={editingQuestion.text} onChange={(e) => setEditingQuestion({ ...editingQuestion, text: e.target.value })} rows={2} />
              </div>
              <div className="space-y-1">
                <Label className="text-sm">가중치</Label>
                <div className="flex items-center gap-2">
                  <Input type="number" className="w-24" value={editingQuestion.weight} onChange={(e) => setEditingQuestion({ ...editingQuestion, weight: parseInt(e.target.value) || 0 })} min={0} max={100} />
                  <span className="text-sm text-muted-foreground">%</span>
                </div>
              </div>

              {/* 선택형인 경우 보기 수정 */}
              {currentCompetency?.answerType === "choice" && editingQuestion.choices.length > 0 && (
                <div className="space-y-2">
                  <Label className="text-sm">보기 수정</Label>
                  <div className="space-y-2">
                    {editingQuestion.choices.map((choice, idx) => (
                      <div key={choice.code} className="flex items-center gap-2">
                        <Badge variant="secondary" className="w-8 justify-center">{choice.code}</Badge>
                        <Input
                          className="flex-1"
                          value={choice.text}
                          onChange={(e) => {
                            const updated = [...editingQuestion.choices]
                            updated[idx] = { ...choice, text: e.target.value }
                            setEditingQuestion({ ...editingQuestion, choices: updated })
                          }}
                        />
                        <Badge variant="outline" className="w-16 justify-center">{choice.weight}점</Badge>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setIsEditQuestionModalOpen(false)}>취소</Button>
            <Button size="sm" onClick={() => handleUpdateQuestion(selectedCategoryId!, selectedSubCategoryId!)}>저장</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 역량 설정 모달 */}
      <Dialog open={isSettingsModalOpen} onOpenChange={setIsSettingsModalOpen}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>{currentCompetency?.name} - 역량 설정</DialogTitle>
            <DialogDescription className="text-xs">해당 역량의 모든 문항에 공통으로 적용되는 설정입니다.</DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="answerType" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="answerType" className="text-sm">답변유형 설정</TabsTrigger>
              <TabsTrigger value="calculation" className="text-sm">계산식 설정</TabsTrigger>
              <TabsTrigger value="scoreRange" className="text-sm">점수 구간 설정</TabsTrigger>
            </TabsList>

            <TabsContent value="answerType" className="space-y-3 mt-3">
              <div className="space-y-3">
                <div className="space-y-2">
                  <Label className="text-sm">답변유형 선택</Label>
                  <RadioGroup
                    value={settingsForm.answerType}
                    onValueChange={(value: "frequency" | "choice") => setSettingsForm({ ...settingsForm, answerType: value })}
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="frequency" id="frequency" />
                      <Label htmlFor="frequency" className="text-sm">빈도형 (매우그렇다 ~ 전혀그렇지않다)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="choice" id="choice" />
                      <Label htmlFor="choice" className="text-sm">선택형 (코드명 기반 보기)</Label>
                    </div>
                  </RadioGroup>
                </div>

                <Separator />

                {settingsForm.answerType === "frequency" ? (
                  <div className="space-y-2">
                    <Label className="text-sm">빈도형 답변 옵션</Label>
                    <div className="space-y-1.5">
                      {settingsForm.frequencyOptions.map((opt, idx) => (
                        <div key={opt.id} className="flex items-center gap-2">
                          <Input
                            className="flex-1 h-8 text-sm"
                            value={opt.text}
                            onChange={(e) => {
                              const updated = [...settingsForm.frequencyOptions]
                              updated[idx] = { ...opt, text: e.target.value }
                              setSettingsForm({ ...settingsForm, frequencyOptions: updated })
                            }}
                          />
                          <div className="flex items-center gap-1.5 w-20">
                            <Label className="text-xs">점수:</Label>
                            <Input
                              type="number"
                              className="w-12 h-8 text-sm"
                              value={opt.weight}
                              onChange={(e) => {
                                const updated = [...settingsForm.frequencyOptions]
                                updated[idx] = { ...opt, weight: parseInt(e.target.value) || 0 }
                                setSettingsForm({ ...settingsForm, frequencyOptions: updated })
                              }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm">선택형 코드명 설정</Label>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          const nextCode = String.fromCharCode(65 + settingsForm.choiceOptions.length) // A, B, C...
                          setSettingsForm({
                            ...settingsForm,
                            choiceOptions: [...settingsForm.choiceOptions, { id: `c-${Date.now()}`, code: nextCode, weight: 0 }]
                          })
                        }}
                      >
                        <Plus className="h-3.5 w-3.5 mr-1" />
                        코드 추가
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground">코드명은 계산식에서 참조되며, 문항 출제 시 보기 수량과 점수가 연동됩니다.</p>
                    <div className="space-y-1.5">
                      {settingsForm.choiceOptions.map((opt, idx) => (
                        <div key={opt.id} className="flex items-center gap-2">
                          <Input
                            className="w-16 h-8 text-sm text-center font-mono"
                            value={opt.code}
                            onChange={(e) => {
                              const updated = [...settingsForm.choiceOptions]
                              updated[idx] = { ...opt, code: e.target.value.toUpperCase() }
                              setSettingsForm({ ...settingsForm, choiceOptions: updated })
                            }}
                            placeholder="코드"
                          />
                          <div className="flex items-center gap-1.5 flex-1">
                            <Label className="text-xs whitespace-nowrap">점수:</Label>
                            <Input
                              type="number"
                              className="w-16 h-8 text-sm"
                              value={opt.weight}
                              onChange={(e) => {
                                const updated = [...settingsForm.choiceOptions]
                                updated[idx] = { ...opt, weight: parseInt(e.target.value) || 0 }
                                setSettingsForm({ ...settingsForm, choiceOptions: updated })
                              }}
                            />
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7 text-destructive"
                            onClick={() => {
                              setSettingsForm({
                                ...settingsForm,
                                choiceOptions: settingsForm.choiceOptions.filter(o => o.id !== opt.id)
                              })
                            }}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      ))}
                      {settingsForm.choiceOptions.length === 0 && (
                        <p className="text-sm text-muted-foreground text-center py-4">코드명을 추가하세요.</p>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="calculation" className="space-y-3 mt-3">
              <div className="space-y-3">
                <Label className="text-sm">계산식 유형</Label>
                <RadioGroup
                  value={settingsForm.calculationFormula.type}
                  onValueChange={(value: "sum" | "average" | "weighted_average" | "custom") =>
                    setSettingsForm({ ...settingsForm, calculationFormula: { ...settingsForm.calculationFormula, type: value } })
                  }
                >
                  <div className="space-y-2">
                    <div className="flex items-start space-x-2">
                      <RadioGroupItem value="sum" id="sum" className="mt-0.5" />
                      <div>
                        <Label htmlFor="sum" className="text-sm">단순합계</Label>
                        <p className="text-xs text-muted-foreground">모든 문항 점수의 합계</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-2">
                      <RadioGroupItem value="average" id="average" className="mt-0.5" />
                      <div>
                        <Label htmlFor="average" className="text-sm">단순평균</Label>
                        <p className="text-xs text-muted-foreground">모든 문항 점수의 평균</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-2">
                      <RadioGroupItem value="weighted_average" id="weighted_average" className="mt-0.5" />
                      <div>
                        <Label htmlFor="weighted_average" className="text-sm">가중평균</Label>
                        <p className="text-xs text-muted-foreground">문항별 가중치를 적용한 평균</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-2">
                      <RadioGroupItem value="custom" id="custom" className="mt-0.5" />
                      <div>
                        <Label htmlFor="custom" className="text-sm">사용자정의</Label>
                        <p className="text-xs text-muted-foreground">직접 계산식 입력</p>
                      </div>
                    </div>
                  </div>
                </RadioGroup>

                {settingsForm.calculationFormula.type === "custom" && (
                  <div className="space-y-1.5 mt-3">
                    <Label className="text-sm">사용자정의 계산식</Label>
                    <Textarea
                      className="text-sm"
                      placeholder="예: (Q1 * 0.3) + (Q2 * 0.3) + (Q3 * 0.4) 또는 (A * 2) + (B * 1)"
                      value={settingsForm.calculationFormula.customFormula || ""}
                      onChange={(e) => setSettingsForm({
                        ...settingsForm,
                        calculationFormula: { ...settingsForm.calculationFormula, customFormula: e.target.value }
                      })}
                      rows={2}
                    />
                    <p className="text-xs text-muted-foreground">
                      Q1, Q2, Q3... 등으로 문항을 참조하거나, 선택형인 경우 코드명(A, B, C...)을 사용할 수 있습니다.
                    </p>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="scoreRange" className="space-y-3 mt-3">
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  점수 구간을 설정합니다. 이 설정은 해당 역량의 모든 세부항목에 공통으로 적용됩니다.
                </p>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { key: "basic", label: "기본", color: "border-gray-300 bg-gray-50" },
                    { key: "normal", label: "보통", color: "border-blue-300 bg-blue-50" },
                    { key: "excellent", label: "우수", color: "border-emerald-300 bg-emerald-50" },
                    { key: "outstanding", label: "탁월", color: "border-amber-300 bg-amber-50" }
                  ].map((level) => (
                    <div key={level.key} className={`rounded-lg border-2 ${level.color} p-4`}>
                      <h4 className="font-semibold mb-3">{level.label}</h4>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <Label className="text-xs">최소점수</Label>
                          <Input
                            type="number"
                            className="h-9"
                            value={settingsForm.scoreRange[level.key as keyof ScoreRange].min}
                            onChange={(e) => setSettingsForm({
                              ...settingsForm,
                              scoreRange: {
                                ...settingsForm.scoreRange,
                                [level.key]: { ...settingsForm.scoreRange[level.key as keyof ScoreRange], min: parseInt(e.target.value) || 0 }
                              }
                            })}
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">최대점수</Label>
                          <Input
                            type="number"
                            className="h-9"
                            value={settingsForm.scoreRange[level.key as keyof ScoreRange].max}
                            onChange={(e) => setSettingsForm({
                              ...settingsForm,
                              scoreRange: {
                                ...settingsForm.scoreRange,
                                [level.key]: { ...settingsForm.scoreRange[level.key as keyof ScoreRange], max: parseInt(e.target.value) || 0 }
                              }
                            })}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>
          </Tabs>

          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setIsSettingsModalOpen(false)}>취소</Button>
            <Button size="sm" onClick={handleSaveSettings}>저장</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 배포 모달 */}
      <Dialog open={isDeployModalOpen} onOpenChange={setIsDeployModalOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>역량 배포</DialogTitle>
            <DialogDescription className="text-xs">&quot;{deployingCompetency?.name}&quot; 역량을 버전으로 배포합니다.</DialogDescription>
          </DialogHeader>

          {deploySuccess ? (
            <div className="py-6 flex flex-col items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                <CheckCircle2 className="h-6 w-6 text-green-600" />
              </div>
              <div className="text-center">
                <h3 className="font-semibold">배포 완료</h3>
                <p className="text-xs text-muted-foreground mt-1">버전관리 메뉴에서 설문 기간을 설정하세요.</p>
              </div>
              <Button size="sm" onClick={() => setIsDeployModalOpen(false)}>확인</Button>
            </div>
          ) : (
            <>
              <div className="space-y-3 py-2">
                <div className="space-y-1">
                  <Label className="text-sm">관리용 명칭</Label>
                  <Input placeholder="예: 2024년 1학기 학습연구역량" value={deployForm.name} onChange={(e) => setDeployForm({ ...deployForm, name: e.target.value })} />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label className="text-sm">년도</Label>
                    <Select value={deployForm.year} onValueChange={(value) => setDeployForm({ ...deployForm, year: value })}>
                      <SelectTrigger className="h-9"><SelectValue placeholder="년도 선택" /></SelectTrigger>
                      <SelectContent>
                        {[2024, 2025, 2026, 2027, 2028].map((year) => (
                          <SelectItem key={year} value={year.toString()}>{year}년</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-sm">학기</Label>
                    <Select value={deployForm.semester} onValueChange={(value) => setDeployForm({ ...deployForm, semester: value })}>
                      <SelectTrigger className="h-9"><SelectValue placeholder="학기 선택" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1학기</SelectItem>
                        <SelectItem value="2">2학기</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {deployingCompetency && (
                  <div className="bg-muted/50 rounded p-3 space-y-1">
                    <h4 className="font-medium text-xs">배포 내용</h4>
                    <div className="text-xs text-muted-foreground">
                      <p>역량: {deployingCompetency.name}</p>
                      <p>카테고리: {deployingCompetency.categories.length}개 · 세부항목: {getTotalSubCategories(deployingCompetency)}개 · 문항: {getTotalQuestions(deployingCompetency)}개</p>
                    </div>
                  </div>
                )}
              </div>

              <DialogFooter>
                <Button variant="outline" size="sm" onClick={() => setIsDeployModalOpen(false)}>취소</Button>
                <Button size="sm" onClick={handleDeployCompetency}>
                  <Send className="h-3.5 w-3.5 mr-1" />
                  배포하기
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
