"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { 
  Calendar,
  Eye,
  Trash2,
  Clock,
  FolderOpen,
  FileText
} from "lucide-react"

// 타입 정의 (설문지 관리 페이지와 동일)
interface AnswerOption {
  id: string
  text: string
  weight: number
}

interface ChoiceOption {
  id: string
  code: string
  weight: number
}

interface QuestionChoice {
  code: string
  text: string
  weight: number
}

interface Question {
  id: string
  text: string
  weight: number
  answers: AnswerOption[]
  choices: QuestionChoice[]
}

interface ScoreInterpretation {
  basic: { description: string }
  normal: { description: string }
  excellent: { description: string }
  outstanding: { description: string }
}

interface ScoreRange {
  basic: { min: number; max: number }
  normal: { min: number; max: number }
  excellent: { min: number; max: number }
  outstanding: { min: number; max: number }
}

interface CalculationFormula {
  type: "sum" | "average" | "weighted_average" | "custom"
  customFormula?: string
}

interface SubCategory {
  id: string
  name: string
  weight: number
  questions: Question[]
  scoreInterpretation: ScoreInterpretation
}

interface Category {
  id: string
  name: string
  subCategories: SubCategory[]
}

interface Competency {
  id: string
  name: string
  answerType: "frequency" | "choice"
  calculationFormula: CalculationFormula
  frequencyOptions: AnswerOption[]
  choiceOptions: ChoiceOption[]
  scoreRange: ScoreRange
  categories: Category[]
}

interface SurveyVersion {
  id: string
  name: string
  year: string
  semester: string
  deployedAt: string
  isActive: boolean
  startDate: string
  endDate: string
  competencies: Competency[]
}

// 예시 배포 버전 데이터 (설문지 관리 페이지와 동일한 구조)
const initialVersions: SurveyVersion[] = [
  {
    id: "ver-2025-1",
    name: "2025학년도 1학기 핵심역량진단",
    year: "2025",
    semester: "1",
    deployedAt: "2025-02-15",
    isActive: true,
    startDate: "2025-03-01",
    endDate: "2026-06-30",
    competencies: [
      {
        id: "1",
        name: "학습연구역량",
        answerType: "choice",
        calculationFormula: { type: "weighted_average" },
        frequencyOptions: [],
        choiceOptions: [
          { id: "c1", code: "A", weight: 4 },
          { id: "c2", code: "B", weight: 3 },
          { id: "c3", code: "C", weight: 2 },
          { id: "c4", code: "D", weight: 1 },
        ],
        scoreRange: {
          basic: { min: 0, max: 25 },
          normal: { min: 26, max: 50 },
          excellent: { min: 51, max: 75 },
          outstanding: { min: 76, max: 100 }
        },
        categories: [
          {
            id: "1-1",
            name: "성격특성",
            subCategories: [
              {
                id: "1-1-1",
                name: "학업적 효능감",
                weight: 34,
                questions: [
                  {
                    id: "q1-1-1-1",
                    text: "귀하는 현재 자신의 연구수행능력과 학업적 도전 상황에 대해 어떤 행동을 보이는지를 가장 잘 설명하는 문장을 하나 선택해 주십시오.",
                    weight: 100,
                    answers: [],
                    choices: [
                      { code: "A", text: "나는 동료나 후배 연구자의 효능감 저하 원인을 진단하고 그들이 작은 성공 경험을 통해 스스로 효능감을 회복하도록 코칭한다.", weight: 4 },
                      { code: "B", text: "나는 연구 결과가 예상과 다르거나 진행이 막히는 상황에서도 실패 요인을 분석하여 대안을 마련하고 끝까지 완수한다.", weight: 3 },
                      { code: "C", text: "나는 전공 연구 프로젝트 수행 시 세세한 지시 없이도 자신의 지식과 기술을 응용하여 독자적으로 과업을 완수한다.", weight: 2 },
                      { code: "D", text: "나는 연구 진행의 매 단계마다 지도교수나 선배의 구체적인 피드백과 확인이 있어야만 다음 단계로 이행한다.", weight: 1 }
                    ]
                  }
                ],
                scoreInterpretation: {
                  basic: { description: "학업적 효능감이 낮은 수준입니다." },
                  normal: { description: "학업적 효능감이 보통 수준입니다." },
                  excellent: { description: "학업적 효능감이 우수한 수준입니다." },
                  outstanding: { description: "학업적 효능감이 탁월한 수준입니다." }
                }
              },
              {
                id: "1-1-2",
                name: "학업적 회복탄력성",
                weight: 33,
                questions: [
                  {
                    id: "q1-1-2-1",
                    text: "귀하는 현재 연구 수행 중 겪게 되는 실패나 스트레스 상황에 대해 어떤 행동을 보이는지를 가장 잘 설명하는 문장을 하나 선택해 주십시오.",
                    weight: 100,
                    answers: [],
                    choices: [
                      { code: "A", text: "나는 데이터 손실이나 프로젝트 중단 등 팀 차원의 위기 상황에서 침착함을 유지하며, 팀원들을 독려하여 대안적 해결책을 찾도록 이끈다.", weight: 4 },
                      { code: "B", text: "나는 가설 기각이나 실험 실패를 단순한 오류가 아닌 '새로운 발견을 위한 데이터'로 재해석하여 연구 방향을 발전적으로 수정한다.", weight: 3 },
                      { code: "C", text: "나는 연구 난항이나 심사 탈락 시 일시적으로 실망할 수 있으나, 스스로 감정을 추스르고 수정 작업이나 재실험을 재개한다.", weight: 2 },
                      { code: "D", text: "나는 논문 투고 거절이나 부정적인 피드백을 받으면 심하게 위축되어 연구실 출입을 기피하거나 학업 수행을 중단한다.", weight: 1 }
                    ]
                  }
                ],
                scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } }
              },
              {
                id: "1-1-3",
                name: "성실성 및 책임감",
                weight: 33,
                questions: [
                  {
                    id: "q1-1-3-1",
                    text: "귀하는 연구 및 학업 계획의 이행과 마감 기한 준수에 대해 현재 어떤 행동을 보이는지를 가장 잘 설명하는 문장을 하나 선택해 주십시오.",
                    weight: 100,
                    answers: [],
                    choices: [
                      { code: "A", text: "나는 공동 연구 시 자신의 역할을 넘어 팀 전체의 중요한 일정을 점검하고, 나태해지는 동료를 독려하여 프로젝트를 기한 내 끝마친다.", weight: 4 },
                      { code: "B", text: "나는 다수의 과제가 동시에 주어졌을 때 중요도와 긴급성을 판단하여 우선순위를 재조정함으로써 누락 없이 모든 과업을 완수한다.", weight: 3 },
                      { code: "C", text: "나는 학기 중 수업 과제나 실험 일정을 스스로 수립하고, 타율적인 통제 없이도 계획대로 꾸준히 실행한다.", weight: 2 },
                      { code: "D", text: "나는 구체적인 지시나 마감 독촉이 있을 때만 연구 과제를 수행하며, 스스로 계획을 세워 준비하는 행동이 부족하다.", weight: 1 }
                    ]
                  }
                ],
                scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } }
              }
            ]
          },
          {
            id: "1-2",
            name: "행동특성",
            subCategories: [
              { id: "1-2-1", name: "시간관리", weight: 34, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
              { id: "1-2-2", name: "집중력 및 학습환경 관리", weight: 33, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
              { id: "1-2-3", name: "학습전략 및 정보처리", weight: 33, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } }
            ]
          },
          {
            id: "1-3",
            name: "연구관련 역량",
            subCategories: [
              { id: "1-3-1", name: "연구설계 및 수행능력", weight: 34, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
              { id: "1-3-2", name: "연구윤리 및 진실성", weight: 33, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
              { id: "1-3-3", name: "연구프로젝트 관리", weight: 33, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } }
            ]
          },
          {
            id: "1-4",
            name: "자기주도학습",
            subCategories: [
              { id: "1-4-1", name: "학습동기 및 목표설정", weight: 34, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
              { id: "1-4-2", name: "자기평가 및 성찰", weight: 33, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
              { id: "1-4-3", name: "자원활용 및 네트워킹", weight: 33, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } }
            ]
          }
        ]
      },
      {
        id: "2",
        name: "융합연구역량",
        answerType: "frequency",
        calculationFormula: { type: "weighted_average" },
        frequencyOptions: [
          { id: "f1", text: "매우그렇다", weight: 5 },
          { id: "f2", text: "그렇다", weight: 4 },
          { id: "f3", text: "보통이다", weight: 3 },
          { id: "f4", text: "그렇지않다", weight: 2 },
          { id: "f5", text: "전혀그렇지않다", weight: 1 },
        ],
        choiceOptions: [],
        scoreRange: {
          basic: { min: 0, max: 25 },
          normal: { min: 26, max: 50 },
          excellent: { min: 51, max: 75 },
          outstanding: { min: 76, max: 100 }
        },
        categories: [
          {
            id: "2-1",
            name: "창의·비판적 사고 역량",
            subCategories: [
              {
                id: "2-1-1", name: "논리적 추론", weight: 25, questions: [
                  { id: "q2-1-1-1", text: "나는 상충하는 복잡한 연구 데이터나 제반 이론들에 대해 객관적 기준을 적용하여 논리적 정합성을 검증한다.", weight: 34, answers: [], choices: [] },
                  { id: "q2-1-1-2", text: "나는 주관적 추측을 배제하고 실증적 데이터와 사실에 기반하여 타당한 결론을 도출한다.", weight: 33, answers: [], choices: [] },
                  { id: "q2-1-1-3", text: "나는 기존 연구 자료에서 논리적 비약이나 타당하지 않은 주장을 스스로 식별할 수 있다.", weight: 33, answers: [], choices: [] }
                ], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } }
              },
              { id: "2-1-2", name: "다학제간 통찰", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
              { id: "2-1-3", name: "독창적 발상", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
              { id: "2-1-4", name: "메타인지적 성찰", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } }
            ]
          },
          {
            id: "2-2",
            name: "분석적 문제해결 역량",
            subCategories: [
              { id: "2-2-1", name: "연구문제 구조화", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
              { id: "2-2-2", name: "증거기반 분석", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
              { id: "2-2-3", name: "논리적 대안 탐색", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
              { id: "2-2-4", name: "연구결과 평가", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } }
            ]
          },
          {
            id: "2-3",
            name: "협력적 의사소통 역량",
            subCategories: [
              { id: "2-3-1", name: "글로벌 소통", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
              { id: "2-3-2", name: "협력설계", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
              { id: "2-3-3", name: "협력 프로세스 관리", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
              { id: "2-3-4", name: "갈등 중재 및 관리", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } }
            ]
          },
          {
            id: "2-4",
            name: "신뢰기반 리더십 역량",
            subCategories: [
              { id: "2-4-1", name: "연구윤리 실천", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
              { id: "2-4-2", name: "다양성 존중", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
              { id: "2-4-3", name: "연구목표 정렬", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } },
              { id: "2-4-4", name: "성장지원", weight: 25, questions: [], scoreInterpretation: { basic: { description: "" }, normal: { description: "" }, excellent: { description: "" }, outstanding: { description: "" } } }
            ]
          }
        ]
      }
    ]
  }
]

export default function VersionManagementPage() {
  const router = useRouter()
  const [versions, setVersions] = useState<SurveyVersion[]>([])
  const [selectedVersion, setSelectedVersion] = useState<SurveyVersion | null>(null)
  const [filterYear, setFilterYear] = useState<string>("all")
  const [filterSemester, setFilterSemester] = useState<string>("all")
  
  // 모달 상태
  const [isPeriodModalOpen, setIsPeriodModalOpen] = useState(false)
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false)
  
  // 기간 설정 상태
  const [periodForm, setPeriodForm] = useState({
    startDate: "",
    endDate: ""
  })

  // localStorage에서 버전 데이터 로드 (없으면 초기 데이터 사용)
  useEffect(() => {
    const savedVersions = localStorage.getItem("surveyVersions")
    if (savedVersions) {
      const parsed = JSON.parse(savedVersions)
      // 기존 데이터가 있으면 사용, 없으면 초기 데이터
      if (parsed.length > 0) {
        setVersions(parsed)
      } else {
        setVersions(initialVersions)
        localStorage.setItem("surveyVersions", JSON.stringify(initialVersions))
      }
    } else {
      // localStorage에 데이터가 없으면 초기 데이터 설정
      setVersions(initialVersions)
      localStorage.setItem("surveyVersions", JSON.stringify(initialVersions))
    }
  }, [])

  // 버전 데이터 저장
  const saveVersions = (newVersions: SurveyVersion[]) => {
    setVersions(newVersions)
    localStorage.setItem("surveyVersions", JSON.stringify(newVersions))
  }

  // 활성/비활성 토글
  const handleToggleActive = (versionId: string) => {
    const updatedVersions = versions.map(v => {
      if (v.id === versionId) {
        return { ...v, isActive: !v.isActive }
      }
      return v
    })
    saveVersions(updatedVersions)
  }

  // 기간 설정
  const handleSavePeriod = () => {
    if (!selectedVersion) return
    
    const updatedVersions = versions.map(v => {
      if (v.id === selectedVersion.id) {
        return { 
          ...v, 
          startDate: periodForm.startDate,
          endDate: periodForm.endDate
        }
      }
      return v
    })
    saveVersions(updatedVersions)
    setIsPeriodModalOpen(false)
  }

  // 버전 삭제
  const handleDeleteVersion = () => {
    if (!selectedVersion) return
    
    const updatedVersions = versions.filter(v => v.id !== selectedVersion.id)
    saveVersions(updatedVersions)
    setSelectedVersion(null)
    setIsDeleteConfirmOpen(false)
  }

  // 필터링된 버전 목록
  const filteredVersions = versions.filter(v => {
    if (filterYear !== "all" && v.year !== filterYear) return false
    if (filterSemester !== "all" && v.semester !== filterSemester) return false
    return true
  })

  // 년도 목록 추출
  const years = [...new Set(versions.map(v => v.year))].sort((a, b) => parseInt(b) - parseInt(a))

  // 설문 상태 확인
  const getSurveyStatus = (version: SurveyVersion) => {
    if (!version.isActive) return { label: "비활성", color: "bg-gray-100 text-gray-700" }
    
    const now = new Date()
    const start = version.startDate ? new Date(version.startDate) : null
    const end = version.endDate ? new Date(version.endDate) : null
    
    if (!start || !end) return { label: "기간 미설정", color: "bg-yellow-100 text-yellow-700" }
    if (now < start) return { label: "대기중", color: "bg-blue-100 text-blue-700" }
    if (now > end) return { label: "종료", color: "bg-gray-100 text-gray-700" }
    return { label: "진행중", color: "bg-green-100 text-green-700" }
  }

  return (
    <div className="flex flex-col gap-6 p-4 md:gap-8 md:p-8">
      {/* 헤더 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">버전관리</h1>
          <p className="text-sm text-muted-foreground mt-1">
            배포된 설문지 버전을 관리하고 설문 기간을 설정합니다.
          </p>
        </div>
      </div>

      {/* 필터 */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-wrap gap-4 items-end">
            <div className="space-y-2">
              <Label>년도</Label>
              <Select value={filterYear} onValueChange={setFilterYear}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="전체" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">전체</SelectItem>
                  {years.map((year) => (
                    <SelectItem key={year} value={year}>{year}년</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label>학기</Label>
              <Select value={filterSemester} onValueChange={setFilterSemester}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="전체" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">전체</SelectItem>
                  <SelectItem value="1">1학기</SelectItem>
                  <SelectItem value="2">2학기</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="ml-auto text-sm text-muted-foreground">
              총 {filteredVersions.length}개의 버전
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 버전 목록 */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <FileText className="h-5 w-5" />
            배포된 설문지 버전
          </CardTitle>
          <CardDescription>
            설문지관리에서 배포한 설문지 버전 목록입니다. 활성화 및 설문 기간을 설정할 수 있습니다.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredVersions.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <FolderOpen className="h-12 w-12 text-muted-foreground/50 mb-4" />
              <h3 className="font-medium text-lg">배포된 설문지가 없습니다</h3>
              <p className="text-sm text-muted-foreground mt-1">
                설문지관리 메뉴에서 설문지를 배포하세요.
              </p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">활성화</TableHead>
                  <TableHead>관리용 명칭</TableHead>
                  <TableHead className="w-24">년도</TableHead>
                  <TableHead className="w-20">학기</TableHead>
                  <TableHead className="w-40">설문 기간</TableHead>
                  <TableHead className="w-24">상태</TableHead>
                  <TableHead className="w-32">배포일</TableHead>
                  <TableHead className="w-28 text-right">관리</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredVersions.map((version) => {
                  const status = getSurveyStatus(version)
                  return (
                    <TableRow key={version.id}>
                      <TableCell>
                        <Switch
                          checked={version.isActive}
                          onCheckedChange={() => handleToggleActive(version.id)}
                        />
                      </TableCell>
                      <TableCell className="font-medium">{version.name}</TableCell>
                      <TableCell>{version.year}년</TableCell>
                      <TableCell>{version.semester}학기</TableCell>
                      <TableCell>
                        {version.startDate && version.endDate ? (
                          <span className="text-sm">
                            {new Date(version.startDate).toLocaleDateString("ko-KR")} ~ {new Date(version.endDate).toLocaleDateString("ko-KR")}
                          </span>
                        ) : (
                          <span className="text-sm text-muted-foreground">미설정</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary" className={status.color}>
                          {status.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {new Date(version.deployedAt).toLocaleDateString("ko-KR")}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              setSelectedVersion(version)
                              setPeriodForm({
                                startDate: version.startDate,
                                endDate: version.endDate
                              })
                              setIsPeriodModalOpen(true)
                            }}
                            title="기간 설정"
                          >
                            <Calendar className="h-4 w-4" />
                          </Button>
<Button
                                            variant="ghost"
                                            size="icon"
                                            onClick={() => router.push(`/competency/version/${version.id}`)}
                                            title="상세보기"
                                          >
                                            <Eye className="h-4 w-4" />
                                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              setSelectedVersion(version)
                              setIsDeleteConfirmOpen(true)
                            }}
                            title="삭제"
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* 기간 설정 모달 */}
      <Dialog open={isPeriodModalOpen} onOpenChange={setIsPeriodModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>설문 기간 설정</DialogTitle>
            <DialogDescription>
              {selectedVersion?.name}의 설문 참여 기간을 설정합니다.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="start-date">시작일</Label>
                <Input
                  id="start-date"
                  type="date"
                  value={periodForm.startDate}
                  onChange={(e) => setPeriodForm({ ...periodForm, startDate: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="end-date">종료일</Label>
                <Input
                  id="end-date"
                  type="date"
                  value={periodForm.endDate}
                  onChange={(e) => setPeriodForm({ ...periodForm, endDate: e.target.value })}
                />
              </div>
            </div>
            
            {periodForm.startDate && periodForm.endDate && (
              <div className="bg-muted/50 rounded-lg p-4">
                <div className="flex items-center gap-2 text-sm">
                  <Clock className="h-4 w-4" />
                  <span>
                    설문 기간: {Math.ceil((new Date(periodForm.endDate).getTime() - new Date(periodForm.startDate).getTime()) / (1000 * 60 * 60 * 24))}일
                  </span>
                </div>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsPeriodModalOpen(false)}>
              취소
            </Button>
            <Button onClick={handleSavePeriod}>
              저장
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 삭제 확인 모달 */}
      <Dialog open={isDeleteConfirmOpen} onOpenChange={setIsDeleteConfirmOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>버전 삭제</DialogTitle>
            <DialogDescription>
              정말로 이 설문지 버전을 삭제하시겠습니까? 이 작업은 되돌릴 수 없습니다.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4">
              <p className="font-medium">{selectedVersion?.name}</p>
              <p className="text-sm text-muted-foreground">
                {selectedVersion?.year}년 {selectedVersion?.semester}학기
              </p>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteConfirmOpen(false)}>
              취소
            </Button>
            <Button variant="destructive" onClick={handleDeleteVersion}>
              ��제
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
