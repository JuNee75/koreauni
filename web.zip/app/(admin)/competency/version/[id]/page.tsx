"use client"

import { useState, useEffect, use } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  ArrowLeft,
  Layers,
  FileText,
  ClipboardList,
  BarChart3,
  Calendar,
  Lock,
  Info
} from "lucide-react"

// 타입 정의
interface AnswerOption {
  id: string
  text: string
  weight: number
}

interface ChoiceOption {
  id: string
  code: string
  weight: number
}

interface QuestionChoice {
  code: string
  text: string
  weight: number
}

interface Question {
  id: string
  text: string
  weight: number
  answers: AnswerOption[]
  choices: QuestionChoice[]
}

interface ScoreInterpretation {
  basic: { description: string }
  normal: { description: string }
  excellent: { description: string }
  outstanding: { description: string }
}

interface ScoreRange {
  basic: { min: number; max: number }
  normal: { min: number; max: number }
  excellent: { min: number; max: number }
  outstanding: { min: number; max: number }
}

interface CalculationFormula {
  type: "sum" | "average" | "weighted_average" | "custom"
  customFormula?: string
}

interface SubCategory {
  id: string
  name: string
  weight: number
  questions: Question[]
  scoreInterpretation: ScoreInterpretation
}

interface Category {
  id: string
  name: string
  subCategories: SubCategory[]
}

interface Competency {
  id: string
  name: string
  answerType: "frequency" | "choice"
  calculationFormula: CalculationFormula
  frequencyOptions: AnswerOption[]
  choiceOptions: ChoiceOption[]
  scoreRange: ScoreRange
  categories: Category[]
}

interface SurveyVersion {
  id: string
  name: string
  year: string
  semester: string
  deployedAt: string
  isActive: boolean
  startDate: string
  endDate: string
  competencies: Competency[]
}

const statusColors: Record<string, string> = {
  "진행중": "bg-green-100 text-green-700 border-green-200",
  "예정": "bg-blue-100 text-blue-700 border-blue-200",
  "종료": "bg-gray-100 text-gray-700 border-gray-200",
}

export default function VersionDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const router = useRouter()
  const [version, setVersion] = useState<SurveyVersion | null>(null)
  const [loading, setLoading] = useState(true)
  const [selectedCompetency, setSelectedCompetency] = useState<Competency | null>(null)
  const [selectedCategoryId, setSelectedCategoryId] = useState<string | null>(null)
  const [selectedSubCategoryId, setSelectedSubCategoryId] = useState<string | null>(null)

  useEffect(() => {
    try {
      const savedVersions = localStorage.getItem("surveyVersions")
      if (savedVersions) {
        const versions: SurveyVersion[] = JSON.parse(savedVersions)
        const found = versions.find(v => v.id === id)
        if (found) {
          console.log("[v0] Found version:", found.name)
          setVersion(found)
          if (found.competencies && found.competencies.length > 0) {
            setSelectedCompetency(found.competencies[0])
            if (found.competencies[0].categories && found.competencies[0].categories.length > 0) {
              setSelectedCategoryId(found.competencies[0].categories[0].id)
            }
          }
        }
      }
    } catch (error) {
      console.error("[v0] Error loading version:", error)
    } finally {
      setLoading(false)
    }
  }, [id])

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-muted-foreground">로딩 중...</div>
      </div>
    )
  }

  if (!version) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] gap-4">
        <div className="text-muted-foreground">설문지 버전을 찾을 수 없습니다.</div>
        <Button variant="outline" onClick={() => router.push("/competency/version")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          버전 목록으로 돌아가기
        </Button>
      </div>
    )
  }

  // 설문 상태 계산
  const getSurveyStatus = () => {
    if (!version.isActive) return "예정"
    const now = new Date()
    const start = version.startDate ? new Date(version.startDate) : null
    const end = version.endDate ? new Date(version.endDate) : null
    if (!start || !end) return "예정"
    if (now < start) return "예정"
    if (now > end) return "종료"
    return "진행중"
  }

  const surveyStatus = getSurveyStatus()
  const isEditable = surveyStatus === "예정"

  // 통계 함수
  const getTotalSubCategories = (comp: Competency) => {
    return (comp.categories || []).reduce((sum, cat) => sum + (cat.subCategories || []).length, 0)
  }

  const getTotalQuestions = (comp: Competency) => {
    return (comp.categories || []).reduce((sum, cat) =>
      sum + (cat.subCategories || []).reduce((s, sub) => s + (sub.questions || []).length, 0), 0)
  }

  const currentCategory = selectedCompetency?.categories?.find(c => c.id === selectedCategoryId) || null
  const currentSubCategory = currentCategory?.subCategories?.find(s => s.id === selectedSubCategoryId) || null

  return (
    <div className="p-6 space-y-6">
      {/* 헤더 */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.push("/competency/version")}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold">{version.name}</h1>
            <Badge variant="outline" className={statusColors[surveyStatus]}>
              {surveyStatus}
            </Badge>
            {!isEditable && (
              <Badge variant="secondary" className="gap-1">
                <Lock className="h-3 w-3" />
                읽기 전용
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
            <span className="flex items-center gap-1">
              <Calendar className="h-4 w-4" />
              설문기간: {version.startDate} ~ {version.endDate}
            </span>
            <span>배포일: {version.deployedAt}</span>
          </div>
        </div>
      </div>

      {/* 읽기 전용 안내 */}
      {!isEditable && (
        <div className="flex items-center gap-2 p-3 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-700">
          <Info className="h-4 w-4" />
          <span>진행중이거나 종료된 설문지는 수정 및 삭제가 불가능합니다.</span>
        </div>
      )}

      {/* 역량 목록 */}
      {version.competencies && version.competencies.length > 0 ? (
        <>
          <Card>
            <CardHeader className="py-2">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Layers className="h-5 w-5" />
                  <CardTitle className="text-lg">역량 목록</CardTitle>
                </div>
                <div className="flex items-center gap-1 border rounded-lg p-1 bg-muted/30">
                  {version.competencies.map((comp) => (
                    <button
                      key={comp.id}
                      className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${
                        selectedCompetency?.id === comp.id
                          ? "bg-primary text-primary-foreground shadow-sm"
                          : "hover:bg-muted text-muted-foreground hover:text-foreground"
                      }`}
                      onClick={() => {
                        setSelectedCompetency(comp)
                        setSelectedCategoryId(null)
                        setSelectedSubCategoryId(null)
                      }}
                    >
                      {comp.name}
                    </button>
                  ))}
                </div>
              </div>
            </CardHeader>
            {selectedCompetency && (
              <CardContent className="pt-0 pb-2">
                <div className="flex items-center gap-6">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">카테고리</span>
                    <span className="font-bold text-primary">{(selectedCompetency.categories || []).length}개</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">세부항목</span>
                    <span className="font-bold text-primary">{getTotalSubCategories(selectedCompetency)}개</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">문항</span>
                    <span className="font-bold text-primary">{getTotalQuestions(selectedCompetency)}개</span>
                  </div>
                </div>
              </CardContent>
            )}
          </Card>

          {/* 탭 콘텐츠 */}
          {selectedCompetency && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">배포 내용</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="questions">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="questions" className="gap-1">
                      <FileText className="h-4 w-4" />
                      문항관리
                    </TabsTrigger>
                    <TabsTrigger value="categories" className="gap-1">
                      <ClipboardList className="h-4 w-4" />
                      카테고리관리
                    </TabsTrigger>
                    <TabsTrigger value="interpretation" className="gap-1">
                      <BarChart3 className="h-4 w-4" />
                      점수해석
                    </TabsTrigger>
                  </TabsList>

                  {/* 문항관리 */}
                  <TabsContent value="questions" className="space-y-4">
                    <div className="flex gap-4">
                      <div className="w-64 border rounded-lg p-3 max-h-[500px] overflow-y-auto">
                        {(selectedCompetency.categories || []).map((cat) => (
                          <div key={cat.id} className="space-y-1">
                            <button
                              onClick={() => setSelectedCategoryId(cat.id)}
                              className={`w-full text-left px-3 py-2 rounded text-sm font-medium transition ${
                                selectedCategoryId === cat.id ? "bg-blue-100 text-blue-700" : "hover:bg-muted"
                              }`}
                            >
                              {cat.name}
                            </button>
                            {selectedCategoryId === cat.id && (
                              <div className="ml-2 space-y-1">
                                {(cat.subCategories || []).map((sub) => (
                                  <button
                                    key={sub.id}
                                    onClick={() => setSelectedSubCategoryId(sub.id)}
                                    className={`w-full text-left px-3 py-2 rounded text-xs transition ${
                                      selectedSubCategoryId === sub.id ? "bg-blue-200 text-blue-800" : "hover:bg-muted"
                                    }`}
                                  >
                                    {sub.name}
                                  </button>
                                ))}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>

                      <div className="flex-1 space-y-3 max-h-[500px] overflow-y-auto">
                        {currentSubCategory?.questions && currentSubCategory.questions.length > 0 ? (
                          currentSubCategory.questions.map((q, idx) => (
                            <div key={q.id} className="p-3 bg-muted/30 rounded-lg">
                              <div className="flex items-start gap-2">
                                <span className="font-medium text-muted-foreground text-sm">{idx + 1}.</span>
                                <div className="flex-1">
                                  <p className="text-sm font-medium">{q.text}</p>
                                  <div className="flex flex-wrap gap-1 mt-2">
                                    {selectedCompetency.answerType === "frequency" ? (
                                      (selectedCompetency.frequencyOptions || []).map((opt) => (
                                        <Badge key={opt.id} variant="secondary" className="text-xs">
                                          {opt.text} ({opt.weight}점)
                                        </Badge>
                                      ))
                                    ) : (
                                      (q.choices || []).map((c, idx) => (
                                        <span key={idx} className="text-xs text-muted-foreground">
                                          {c.code}. {c.text} ({c.weight}점)
                                        </span>
                                      ))
                                    )}
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))
                        ) : (
                          <div className="text-center text-muted-foreground py-8 text-sm">
                            카테고리를 선택하여 문항을 확인하세요
                          </div>
                        )}
                      </div>
                    </div>
                  </TabsContent>

                  {/* 카테고리관리 */}
                  <TabsContent value="categories" className="space-y-3">
                    {(selectedCompetency.categories || []).map((cat) => (
                      <Card key={cat.id} className="p-4">
                        <h3 className="font-semibold text-sm mb-2">{cat.name}</h3>
                        <div className="space-y-2">
                          {(cat.subCategories || []).map((sub) => (
                            <div key={sub.id} className="pl-4 py-2 border-l-2 border-blue-200 flex items-center justify-between">
                              <span className="text-sm">{sub.name}</span>
                              <div className="flex gap-2">
                                <Badge variant="outline" className="text-xs">가중치: {sub.weight}%</Badge>
                                <Badge variant="secondary" className="text-xs">{(sub.questions || []).length}문항</Badge>
                              </div>
                            </div>
                          ))}
                        </div>
                      </Card>
                    ))}
                  </TabsContent>

                  {/* 점수해석 */}
                  <TabsContent value="interpretation" className="space-y-4">
                    <div className="grid grid-cols-4 gap-2">
                      <div className="p-3 rounded bg-gray-50 text-center text-xs">
                        <Badge className="bg-gray-200 text-gray-700 mb-1">기본</Badge>
                        <p>{selectedCompetency.scoreRange?.basic?.min}-{selectedCompetency.scoreRange?.basic?.max}점</p>
                      </div>
                      <div className="p-3 rounded bg-blue-50 text-center text-xs">
                        <Badge className="bg-blue-100 text-blue-700 mb-1">보통</Badge>
                        <p>{selectedCompetency.scoreRange?.normal?.min}-{selectedCompetency.scoreRange?.normal?.max}점</p>
                      </div>
                      <div className="p-3 rounded bg-green-50 text-center text-xs">
                        <Badge className="bg-green-100 text-green-700 mb-1">우수</Badge>
                        <p>{selectedCompetency.scoreRange?.excellent?.min}-{selectedCompetency.scoreRange?.excellent?.max}점</p>
                      </div>
                      <div className="p-3 rounded bg-amber-50 text-center text-xs">
                        <Badge className="bg-amber-100 text-amber-700 mb-1">탁월</Badge>
                        <p>{selectedCompetency.scoreRange?.outstanding?.min}-{selectedCompetency.scoreRange?.outstanding?.max}점</p>
                      </div>
                    </div>
                    <div className="space-y-2 max-h-[400px] overflow-y-auto">
                      {(selectedCompetency.categories || []).map((cat) => (
                        (cat.subCategories || []).map((sub) => (
                          <Card key={sub.id} className="p-3">
                            <div className="text-sm font-semibold mb-2">{cat.name} - {sub.name}</div>
                            <Table className="text-xs">
                              <TableHeader>
                                <TableRow>
                                  <TableHead>구간</TableHead>
                                  <TableHead>해석</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                <TableRow>
                                  <TableCell><Badge className="bg-gray-100 text-gray-700 text-xs">기본</Badge></TableCell>
                                  <TableCell>{sub.scoreInterpretation?.basic?.description || "-"}</TableCell>
                                </TableRow>
                                <TableRow>
                                  <TableCell><Badge className="bg-blue-100 text-blue-700 text-xs">보통</Badge></TableCell>
                                  <TableCell>{sub.scoreInterpretation?.normal?.description || "-"}</TableCell>
                                </TableRow>
                                <TableRow>
                                  <TableCell><Badge className="bg-green-100 text-green-700 text-xs">우수</Badge></TableCell>
                                  <TableCell>{sub.scoreInterpretation?.excellent?.description || "-"}</TableCell>
                                </TableRow>
                                <TableRow>
                                  <TableCell><Badge className="bg-amber-100 text-amber-700 text-xs">탁월</Badge></TableCell>
                                  <TableCell>{sub.scoreInterpretation?.outstanding?.description || "-"}</TableCell>
                                </TableRow>
                              </TableBody>
                            </Table>
                          </Card>
                        ))
                      ))}
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          )}
        </>
      ) : (
        <Card>
          <CardContent className="py-8 text-center text-muted-foreground">
            배포된 역량 정보가 없습니다.
          </CardContent>
        </Card>
      )}
    </div>
  )
}
