"use client"

import { useParams, useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, ChevronRight, FileText, Download, User, GraduationCap, Building2 } from "lucide-react"
import { AIAnalysisResult } from "@/components/competency/ai-analysis-result"
import { CompetencyProfileAnalysis } from "@/components/competency/competency-profile-analysis"

// 설문 참여 기록 (학생 데이터 기반 mock)
const surveyParticipations = [
  { id: "p1", surveyId: "v1", studentId: "S001", studentName: "김민준", department: "경영학과", program: "박사", completedAt: "2025-03-15 14:32", status: "완료" },
  { id: "p2", surveyId: "v1", studentId: "S002", studentName: "이서연", department: "AI경영학과", program: "석사", completedAt: "2025-03-18 09:15", status: "완료" },
  { id: "p3", surveyId: "v1", studentId: "S003", studentName: "박현우", department: "데이터사이언스학과", program: "통합", completedAt: null, status: "미완료" },
  { id: "p4", surveyId: "v1", studentId: "S004", studentName: "Wang Fang", department: "경영학과", program: "박사", completedAt: "2025-03-20 16:45", status: "완료" },
  { id: "p5", surveyId: "v1", studentId: "S005", studentName: "정하은", department: "마케팅학과", program: "석사", completedAt: null, status: "미완료" },
  { id: "p6", surveyId: "v1", studentId: "S007", studentName: "Nguyen Thi Mai", department: "국제경영학과", program: "석사", completedAt: "2025-03-22 11:20", status: "완료" },
  { id: "p7", surveyId: "v1", studentId: "S008", studentName: "최예진", department: "재무학과", program: "석사", completedAt: "2025-03-25 10:05", status: "완료" },
  { id: "p8", surveyId: "v1", studentId: "S009", studentName: "한승우", department: "경영정보학과", program: "통합", completedAt: null, status: "미완료" },
  { id: "p9", surveyId: "v1", studentId: "S011", studentName: "유태현", department: "데이터사이언스학과", program: "박사", completedAt: "2025-03-28 15:30", status: "완료" },
  { id: "p10", surveyId: "v2", studentId: "S001", studentName: "김민준", department: "경영학과", program: "박사", completedAt: "2024-09-12 10:20", status: "완료" },
  { id: "p11", surveyId: "v2", studentId: "S002", studentName: "이서연", department: "AI경영학과", program: "석사", completedAt: "2024-09-15 14:45", status: "완료" },
  { id: "p12", surveyId: "v2", studentId: "S003", studentName: "박현우", department: "데이터사이언스학과", program: "통합", completedAt: "2024-09-18 09:30", status: "완료" },
  { id: "p13", surveyId: "v2", studentId: "S006", studentName: "오진석", department: "회계학과", program: "박사", completedAt: "2024-09-20 11:15", status: "완료" },
  { id: "p14", surveyId: "v2", studentId: "S010", studentName: "강수빈", department: "경영학과", program: "석사", completedAt: "2024-09-22 16:00", status: "완료" },
]

// 학과별 평균 데이터
const departmentAverages: Record<string, { name: string; score: number }[]> = {
  "경영학과": [
    { name: "학습연구역량", score: 76 },
    { name: "융합연구역량", score: 72 }
  ]
}

// 학교 전체 평균 데이터
const schoolAverages = [
  { name: "학습연구역량", score: 73 },
  { name: "융합연구역량", score: 70 }
]

// 설문 결과 데이터 (상세보기용)
const surveyResults: Record<string, {
  competencies: {
    name: string
    score: number
    level: string
    categories: {
      name: string
      score: number
      subCategories: {
        name: string
        score: number
        level: string
        interpretation: string
        answer?: string
      }[]
    }[]
  }[]
}> = {
  "p1": {
    competencies: [
      {
        name: "학습연구역량",
        score: 78,
        level: "우수",
        categories: [
          {
            name: "성격특성",
            score: 82,
            subCategories: [
              { 
                name: "학업적 효능감", 
                score: 85, 
                level: "탁월", 
                interpretation: "학업적 효능감이 탁월한 수준입니다. 연구 수행능력과 도전 상황에서 적극적이고 신뢰감 있는 태도를 보이며, 동료 연구자들의 효능감 저하 상황을 진단하고 코칭하는 리더십을 발휘합니다.",
                answer: "나는 동료나 후배 연구자의 효능감 저하 원인을 진단하고 그들이 작은 성공 경험을 통해 스스로 효능감을 회복하도록 코칭한다. (A)"
              },
              { 
                name: "학업적 회복탄력성", 
                score: 80, 
                level: "우수", 
                interpretation: "학업적 회복탄력성이 우수한 수준입니다. 연구 과정에서의 실패나 스트레스를 건설적으로 대처하며, 새로운 발견의 기회로 재해석하는 능력이 뛰어납니다.",
                answer: "나는 가설 기각이나 실험 실패를 단순한 오류가 아닌 '새로운 발견을 위한 데이터'로 재해석하여 연구 방향을 발전적으로 수정한다. (B)"
              },
              { 
                name: "성실성 및 책임감", 
                score: 81, 
                level: "우수", 
                interpretation: "성실성 및 책임감이 우수한 수준입니다. 공동 연구 시 자신의 역할을 넘어 팀 전체의 일정을 관리하며 책임감 있게 프로젝트를 완수합니다.",
                answer: "나는 공동 연구 시 자신의 역할을 넘어 팀 전체의 중요한 일정을 점검하고, 나태해지는 동료를 독려하여 프로젝트를 기한 내 끝마친다. (A)"
              },
            ]
          },
          {
            name: "행동특성",
            score: 75,
            subCategories: [
              { 
                name: "시간관리", 
                score: 72, 
                level: "보통", 
                interpretation: "시간관리가 보통 수준입니다. 기본적인 계획을 수립하여 일정을 관리하고 있으나, 더욱 체계적이고 효율적인 시간 활용 전략이 필요합니다.",
                answer: "나는 학기 중 수업 과제나 실험 일정을 스스로 수립하고, 타율적인 통제 없이도 계획대로 꾸준히 실행한다. (C)"
              },
              { 
                name: "집중력 및 학습환경 관리", 
                score: 78, 
                level: "우수", 
                interpretation: "집중력 및 학습환경 관리가 우수한 수준입니다. 연구에 집중하고 학습 환경을 효과적으로 조성하는 능력이 뛰어납니다.",
                answer: "나는 연구 환경을 최적으로 조성하여 깊이 있는 집중 작업이 가능하도록 한다. (B)"
              },
              { 
                name: "학습전략 및 정보처리", 
                score: 75, 
                level: "보통", 
                interpretation: "학습전략 및 정보처리가 보통 수준입니다. 기본적인 학습 방법을 사용하고 있으며, 대량의 정보를 효율적으로 분석하고 활용하는 고급 전략을 개발할 필요가 있습니다.",
                answer: "나는 다양한 학습 자료를 수집하고 정보를 체계적으로 정리하여 연구에 활용한다. (C)"
              },
            ]
          },
          {
            name: "연구관련 역량",
            score: 76,
            subCategories: [
              { 
                name: "연구설계 및 수행능력", 
                score: 78, 
                level: "우수", 
                interpretation: "연구설계 및 수행능력이 우수한 수준입니다. 명확한 연구 목표를 설정하고 적절한 방법론을 선택하여 체계적으로 연구를 수행합니다.",
                answer: "나는 선행연구를 충분히 검토한 후 명확한 연구문제를 설정하고 적절한 연구방법론을 설계한다. (B)"
              },
              { 
                name: "연구윤리 및 진실성", 
                score: 76, 
                level: "우수", 
                interpretation: "연구윤리 및 진실성이 우수한 수준입니다. 연구 과정에서 높은 윤리 기준을 유지하고 데이터 조작이나 표절을 엄격히 거부합니다.",
                answer: "나는 출처를 명확히 표기하고 인용 기준을 준수하며, 타인의 아이디어를 존중한다. (B)"
              },
              { 
                name: "연구프로젝트 관리", 
                score: 74, 
                level: "보통", 
                interpretation: "연구프로젝트 관리가 보통 수준입니다. 기본적인 프로젝트 관리 능력을 갖추고 있으나, 예산 관리나 일정 조정에서 더욱 체계적인 접근이 필요합니다.",
                answer: "나는 프로젝트의 주요 마일스톤을 설정하고 정기적으로 진행 상황을 점검한다. (C)"
              },
            ]
          },
          {
            name: "자기주도학습",
            score: 74,
            subCategories: [
              { 
                name: "학습동기 및 목표설정", 
                score: 76, 
                level: "우수", 
                interpretation: "학습동기 및 목표설정이 우수한 수준입니다. 내재적 학습 동기가 강하며, 구체적이고 도전적인 목표를 설정하여 자기주도적으로 학습을 진행합니다.",
                answer: "나는 장기 목표를 설정하고 이를 단계적인 단기 목표로 구체화하여 체계적으로 추진한다. (B)"
              },
              { 
                name: "자기평가 및 성찰", 
                score: 74, 
                level: "보통", 
                interpretation: "자기평가 및 성찰이 보통 수준입니다. 정기적으로 자신의 학습 과정을 평가하고 있으나, 더욱 깊이 있고 비판적인 자기 성찰이 필요합니다.",
                answer: "나는 학습 결과를 평가하고 부족한 점을 파악하여 개선방안을 모색한다. (C)"
              },
              { 
                name: "자원활용 및 네트워킹", 
                score: 72, 
                level: "보통", 
                interpretation: "자원활용 및 네트워킹이 보통 수준입니다. 학습에 필요한 자원을 활용하고 있으며, 더욱 적극적인 학습 공동체 참여와 멘토링 관계 구축을 권장합니다.",
                answer: "나는 필요한 학습 자원을 찾아 활용하고, 동료들과 학습 경험을 공유한다. (C)"
              },
            ]
          }
        ]
      },
      {
        name: "융합연구역량",
        score: 65,
        level: "개선필요",
        categories: [
          {
            name: "창의·비판적 사고 역량",
            score: 62,
            subCategories: [
              { 
                name: "논리적 추론", 
                score: 68, 
                level: "보통", 
                interpretation: "논리적 추론이 보통 수준입니다. 기본적인 논리적 분석은 가능하나, 더욱 정교하고 엄밀한 논리적 검증 능력 개발이 필요합니다.",
                answer: "나는 연구 데이터를 기본적으로 분석하지만 깊이 있는 논리적 검증에는 어려움이 있다. (보통이다)"
              },
              { 
                name: "다학제간 통찰", 
                score: 58, 
                level: "개선필요", 
                interpretation: "다학제간 통찰이 개선 필요 수준입니다. 자신의 전공 영역에 집중하고 있어 다양한 분야의 지식 통합에 어려움을 겪고 있습니다. 정기적인 크로스 디시플린 워크샵 참여가 권장됩니다.",
                answer: "나는 주로 경영학 관점에서만 연구하며 다른 분야 지식을 적극적으로 활용하지 못한다. (그렇지 않다)"
              },
              { 
                name: "독창적 발상", 
                score: 55, 
                level: "개선필요", 
                interpretation: "독창적 발상이 개선 필요 수준입니다. 기존의 증명된 방법론에 의존하는 경향이 있으며, 새로운 아이디어 도출을 위한 창의적 사고 훈련이 시급합니다.",
                answer: "나는 기존의 검증된 연구 방법을 따르려 하며 새로운 방식 시도에 신중하다. (그렇지 않다)"
              },
              { 
                name: "메타인지적 성찰", 
                score: 62, 
                level: "보통", 
                interpretation: "메타인지적 성찰이 보통 수준입니다. 자신의 학습 과정을 부분적으로 검토하지만, 더욱 심층적인 자기 성찰을 통한 개선이 필요합니다.",
                answer: "나는 가끔 내 연구 방식을 되돌아보지만 체계적으로 분석하지는 못한다. (보통이다)"
              },
            ]
          },
          {
            name: "분석적 문제해결 역량",
            score: 67,
            subCategories: [
              { 
                name: "연구문제 구조화", 
                score: 69, 
                level: "보통", 
                interpretation: "연구문제 구조화가 보통 수준입니다. 기본적인 문제 분석은 가능하나, 복잡한 문제의 다층적 분해와 프레임워킹이 필요합니다.",
                answer: "나는 연구 문제를 분석하지만 체계적인 프레임워크를 적용하는 데는 미흡하다. (보통이다)"
              },
              { 
                name: "증거기반 분석", 
                score: 71, 
                level: "보통", 
                interpretation: "증거기반 분석이 보통 수준입니다. 데이터 수집은 적절하나, 데이터의 타당성과 신뢰도 검증 절차 강화가 필요합니다.",
                answer: "나는 데이터를 수집하여 분석하지만 증거의 충분성 검증에는 시간을 충분히 들이지 못한다. (보통이다)"
              },
              { 
                name: "논리적 대안 탐색", 
                score: 62, 
                level: "개선필요", 
                interpretation: "논리적 대안 탐색이 개선 필요 수준입니다. 첫 번째 해결 방안에 만족하는 경향이 있으며, 다각적 접근과 대안 비교 분석이 필요합니다.",
                answer: "나는 처음 생각한 해결 방법으로 진행하려 하며 다른 대안을 충분히 검토하지 않는다. (그렇지 않다)"
              },
              { 
                name: "연구결과 평가", 
                score: 64, 
                level: "개선필요", 
                interpretation: "연구결과 평가가 개선 필요 수준입니다. 결과 해석에 있어 한��� 인식 부족과 무비판적 수용 경향이 있으며, 비판적 평가 능력 개발이 시급합니다.",
                answer: "나는 나온 결과를 긍정적으로 해석하려 하며 결과의 한계를 충분히 검토하지 못한다. (그렇지 않다)"
              },
            ]
          },
          {
            name: "협력적 의사소통 역량",
            score: 68,
            subCategories: [
              { 
                name: "글로벌 소통", 
                score: 65, 
                level: "개선필요", 
                interpretation: "글로벌 소통이 ��선 필요 수준입니다. 국제 학술 활동 참여가 제한적이며, 다양한 문화적 배경의 연구자와의 협력 기회 확대가 필요합니다.",
                answer: "나는 언어나 문화 차이로 인해 국제 학술 활동에 자주 참여하지 못한다. (그렇지 않다)"
              },
              { 
                name: "협력설계", 
                score: 70, 
                level: "보통", 
                interpretation: "협력설계가 보통 수준입니다. 기본적인 역할 분담은 수행하나, 더욱 명확한 책임 체계와 협력 구조 설계가 필요합니다.",
                answer: "나는 팀 프로젝트에서 역할을 나누지만 때로 책임 경계가 모호할 수 있다. (보통이다)"
              },
              { 
                name: "협력 프로세스 관리", 
                score: 69, 
                level: "보통", 
                interpretation: "협력 프로세스 관리가 보통 수준입니다. 정기적 커뮤니케이션은 이루어지나, 더욱 효율적인 협력 프로토콜과 피드백 시스템이 필요합니다.",
                answer: "나는 팀과 정기적으로 만나지만 효율적 회의 진행에는 개선의 여지가 있다. (보통이다)"
              },
              { 
                name: "갈등 중재 및 관리", 
                score: 68, 
                level: "보통", 
                interpretation: "갈등 중재 및 관리가 보통 수준입니다. 갈등 상황 회피 경향이 있으며, 건설적 갈등 해결을 위한 의사소통 기법 학습이 필요합니다.",
                answer: "나는 팀 내 갈등이 생기면 시간이 지나기를 기다리는 경향이 있다. (보통이다)"
              },
            ]
          },
          {
            name: "신뢰기반 리더십 역량",
            score: 63,
            subCategories: [
              { 
                name: "연구윤리 실천", 
                score: 71, 
                level: "보통", 
                interpretation: "연구윤리 실천이 보통 수준입니다. 기본적인 윤리 기준은 준수하나, 더욱 심화된 윤리 상황에 대한 이해와 판단 능력 개발이 필요합니다.",
                answer: "나는 연구 윤리를 기본적으로 준수하지만 회색 영역의 판단에는 확신이 서지 않을 때가 있다. (보통이다)"
              },
              { 
                name: "다양성 존중", 
                score: 62, 
                level: "개선필요", 
                interpretation: "다양성 존중이 개선 필요 수준입니다. 다양한 배경의 팀원들과의 상호작용에 어려움이 있으며, 포용적 태도와 의사소통 능력 개발이 필요합니다.",
                answer: "나는 다른 배경의 팀원들과 의견이 맞지 않을 때 소극적으로 대응하는 경향이 있다. (그렇지 않다)"
              },
              { 
                name: "연구목표 정렬", 
                score: 58, 
                level: "개선필요", 
                interpretation: "연구목표 정렬이 개선 필요 수준입니다. 팀과 목표 공유의 명확성이 부족하며, 목표 설정과 주기적 점검 프로세스 구축이 시급합니다.",
                answer: "나는 개인 목표와 팀 목표의 연결이 명확하지 않을 때가 있다. (그렇지 않다)"
              },
              { 
                name: "성장지원", 
                score: 59, 
                level: "개선필요", 
                interpretation: "성장지원이 개선 필요 수준입니다. 후배나 팀원의 역량 개발에 대한 책임감이 낮으며, 멘토링 마인드셋 개발과 실천이 필요합니다.",
                answer: "나는 팀원의 개발보다 현재의 업무 완수에 더 집중하는 경향이 있다. (그렇지 않다)"
              },
            ]
          }
        ]
      }
    ]
  },
  "p2": {
    competencies: [
      {
        name: "학습연구역량",
        score: 85,
        level: "탁월",
        categories: [
          {
            name: "성격특성",
            score: 88,
            subCategories: [
              { name: "학업적 효능감", score: 90, level: "탁월", interpretation: "학업적 효능감이 탁월한 수준입니다." },
              { name: "학업적 회복탄력성", score: 86, level: "탁월", interpretation: "학업적 회복탄력성이 탁월한 수준입니다." },
              { name: "성실성 및 책임감", score: 88, level: "탁월", interpretation: "성실성 및 책임감이 탁월한 수준입니다." },
            ]
          },
        ]
      },
      {
        name: "융합연구역량",
        score: 82,
        level: "우수",
        categories: [
          {
            name: "창의·비판적 사고 역량",
            score: 82,
            subCategories: [
              { name: "논리적 추론", score: 84, level: "탁월", interpretation: "논리적 추론이 탁월한 수준입니다." },
              { name: "다학제간 통찰", score: 80, level: "우수", interpretation: "다학제간 통찰이 우수한 수준입니다." },
              { name: "독창적 발상", score: 82, level: "우수", interpretation: "독창적 발상이 우수한 수준입니다." },
              { name: "메타인지적 성찰", score: 82, level: "우수", interpretation: "��타인지적 성찰이 우수한 수준입니다." },
            ]
          },
        ]
      }
    ]
  },
  "p4": {
    competencies: [
      {
        name: "학습연구역량",
        score: 76,
        level: "우수",
        categories: [
          {
            name: "성격특성",
            score: 78,
            subCategories: [
              { name: "학업적 효능감", score: 80, level: "우수", interpretation: "학업적 효능감이 우수한 수준입니다." },
              { name: "학업적 회복탄력성", score: 75, level: "보통", interpretation: "학업적 회복탄력성이 보통 수준입니다." },
              { name: "성실성 및 책임감", score: 79, level: "우수", interpretation: "성실성 및 책임감이 우수한 수준입니다." },
            ]
          },
        ]
      },
    ]
  },
  "p6": {
    competencies: [
      {
        name: "학습연구역량",
        score: 70,
        level: "보통",
        categories: [
          {
            name: "성격특성",
            score: 72,
            subCategories: [
              { name: "학업적 효능감", score: 74, level: "보통", interpretation: "학업적 효능감이 보통 수준입니다." },
              { name: "학업적 회복탄력성", score: 70, level: "보통", interpretation: "학업적 회복탄력성이 보통 수준입니다." },
              { name: "성실성 및 책임감", score: 72, level: "보통", interpretation: "성실성 및 책임감이 보통 수준입니다." },
            ]
          },
        ]
      },
    ]
  },
  "p7": {
    competencies: [
      {
        name: "학습연구역량",
        score: 88,
        level: "탁월",
        categories: [
          {
            name: "성격특성",
            score: 90,
            subCategories: [
              { name: "학업적 효능감", score: 92, level: "탁월", interpretation: "학업적 효능감이 탁월한 수준입니다." },
              { name: "학업적 회복탄력성", score: 88, level: "탁월", interpretation: "학업적 회복탄력성이 탁월한 수준입니다." },
              { name: "성실성 및 책임감", score: 90, level: "탁월", interpretation: "성실성 및 책임감이 탁월한 수준입니다." },
            ]
          },
        ]
      },
    ]
  },
  "p9": {
    competencies: [
      {
        name: "학습연구역량",
        score: 82,
        level: "우수",
        categories: [
          {
            name: "성격특성",
            score: 84,
            subCategories: [
              { name: "학업적 효능감", score: 86, level: "탁월", interpretation: "학업적 효능감이 탁월한 수준입니다." },
              { name: "학업적 회복탄력성", score: 82, level: "우수", interpretation: "학업적 회복탄력성이 우수한 수준입니다." },
              { name: "성실성 및 책임감", score: 84, level: "탁월", interpretation: "성실성 및 책임감이 탁월한 수준입니다." },
            ]
          },
        ]
      },
    ]
  },
}

const programColors: Record<string, string> = {
  "석사": "bg-blue-50 text-blue-700 border-blue-200",
  "박사": "bg-indigo-50 text-indigo-700 border-indigo-200",
  "통합": "bg-gray-100 text-gray-600 border-gray-200",
}

const levelColors: Record<string, string> = {
  "기본": "bg-gray-100 text-gray-700",
  "보통": "bg-blue-100 text-blue-700",
  "우수": "bg-emerald-100 text-emerald-700",
  "탁월": "bg-amber-100 text-amber-700",
}

export default function DiagnosisResultPage() {
  const params = useParams()
  const router = useRouter()
  const participationId = params.id as string

  const participation = surveyParticipations.find(p => p.id === participationId)
  const resultData = surveyResults[participationId]

  if (!participation) {
    return (
      <div className="flex flex-col gap-4 p-4 md:gap-6 md:p-6">
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16 text-muted-foreground">
            <FileText className="h-12 w-12 mb-4" />
            <p className="text-base font-medium">진단 결과를 찾을 수 없습니다.</p>
            <Button variant="outline" className="mt-4" onClick={() => router.back()}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              돌아가기
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  // PDF 다운로드 기능 (실제로는 PDF 라이브러리 사용)
  const handlePdfDownload = () => {
    alert("PDF 다운로드 기능은 추후 구현 예정입니다.")
  }

  return (
    <div className="flex flex-col gap-4 p-4 md:gap-6 md:p-6">
      {/* 헤더 */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-xl font-bold text-foreground">진단결과</h1>
            <p className="text-sm text-muted-foreground mt-0.5">학생 핵심역량 진단 결과 상세</p>
          </div>
        </div>
        <Button variant="outline" onClick={handlePdfDownload} className="gap-1">
          <Download className="h-4 w-4" />
          PDF 다운로드
        </Button>
      </div>

      {/* 학생 정보 */}
      <Card>
        <CardContent className="py-4">
          <div className="flex flex-wrap items-center gap-6">
            <div className="flex items-center gap-2">
              <User className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">이름</span>
              <span className="font-semibold">{participation.studentName}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">학번</span>
              <span className="font-mono text-sm">{participation.studentId}</span>
            </div>
            <div className="flex items-center gap-2">
              <Building2 className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">학과</span>
              <span className="font-medium">{participation.department}</span>
            </div>
            <div className="flex items-center gap-2">
              <GraduationCap className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">과정</span>
              <Badge variant="outline" className={programColors[participation.program]}>
                {participation.program}
              </Badge>
            </div>
            <div className="flex items-center gap-2 ml-auto">
              <span className="text-sm text-muted-foreground">진단 완료일</span>
              <span className="text-sm">{participation.completedAt}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* AI 분석결과 + 학생상담 가이드 */}
      {resultData && (
        <AIAnalysisResult
          studentName={participation.studentName}
          competencies={resultData.competencies.map(comp => ({
            name: comp.name,
            score: comp.score,
            level: comp.level
          }))}
          detailedData={resultData}
          departmentAverage={departmentAverages[participation.department] || []}
        />
      )}

      {/* 역량 프로필 분석 (탭 메뉴) */}
      {resultData && (
        <CompetencyProfileAnalysis
          studentName={participation.studentName}
          detailedData={resultData}
          departmentAverage={departmentAverages[participation.department] || []}
          schoolAverage={schoolAverages}
        />
      )}

      {/* 진단 결과 상세 */}
      {resultData ? (
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <h2 className="text-lg font-semibold">상세 진단 결과</h2>
          </div>
          {resultData.competencies.map((comp, compIdx) => (
            <Card key={compIdx}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <CardTitle className="text-base">{comp.name}</CardTitle>
                    <Badge className={levelColors[comp.level]}>{comp.level}</Badge>
                  </div>
                  <div className="flex items-center gap-3">
                    <Progress value={comp.score} className="w-32 h-2" />
                    <span className="font-bold text-lg">{comp.score}점</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-4">
                  {comp.categories.map((cat, catIdx) => (
                    <div key={catIdx} className="space-y-3">
                      <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground border-b pb-2">
                        <ChevronRight className="h-4 w-4" />
                        {cat.name}
                        <span className="ml-auto font-semibold text-foreground">{cat.score}점</span>
                      </div>
                      
                      <div className="grid gap-2 pl-6">
                        {cat.subCategories.map((sub, subIdx) => (
                          <div key={subIdx} className="p-3 border rounded-lg bg-muted/20">
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-2">
                                <span className="font-medium text-sm">{sub.name}</span>
                                <Badge variant="outline" className={levelColors[sub.level]}>{sub.level}</Badge>
                              </div>
                              <div className="flex items-center gap-2">
                                <Progress value={sub.score} className="w-24 h-1.5" />
                                <span className="font-semibold text-sm w-12 text-right">{sub.score}점</span>
                              </div>
                            </div>
                            <p className="text-xs text-muted-foreground mb-2">{sub.interpretation}</p>
                            {sub.answer && (
                              <div className="mt-2 p-2 bg-white rounded border-l-2 border-primary">
                                <p className="text-xs font-medium text-foreground mb-1">응답 내용:</p>
                                <p className="text-xs text-muted-foreground italic">{sub.answer}</p>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16 text-muted-foreground">
            <FileText className="h-12 w-12 mb-4" />
            <p className="text-base font-medium">상세 결과 데이터가 없습니다.</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
