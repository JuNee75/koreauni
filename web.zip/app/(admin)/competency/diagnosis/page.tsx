"use client"

import { useState, useMemo } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Search,
  X,
  ChevronRight,
  ChevronLeft,
  Users,
  CheckCircle2,
  Clock,
  ClipboardList,
  FileText,
  Download,
} from "lucide-react"
import { students } from "@/lib/student-data"

// 배포된 설문지 목록 (버전관리와 연동 가정)
const deployedSurveys = [
  { id: "v1", year: "2025", semester: "1", name: "2025학년도 1학기 핵심역량진단", startDate: "2025-03-01", endDate: "2025-03-31", status: "진행중" },
  { id: "v2", year: "2024", semester: "2", name: "2024학년도 2학기 핵심역량진단", startDate: "2024-09-01", endDate: "2024-09-30", status: "완료" },
  { id: "v3", year: "2024", semester: "1", name: "2024학년도 1학기 핵심역량진단", startDate: "2024-03-01", endDate: "2024-03-31", status: "완료" },
]

// 설문 참여 기록 (학생 데이터 기반 mock)
const surveyParticipations = [
  // 2025-1학기 참여자
  { id: "p1", surveyId: "v1", studentId: "S001", studentName: "김민준", department: "경영학과", program: "박사", completedAt: "2025-03-15 14:32", status: "완료", finalScore: 78 },
  { id: "p2", surveyId: "v1", studentId: "S002", studentName: "이서연", department: "AI경영학과", program: "석사", completedAt: "2025-03-18 09:15", status: "완료", finalScore: 85 },
  { id: "p3", surveyId: "v1", studentId: "S003", studentName: "박현우", department: "데이터사이언스학과", program: "통합", completedAt: null, status: "미완료", finalScore: null },
  { id: "p4", surveyId: "v1", studentId: "S004", studentName: "Wang Fang", department: "경영학과", program: "박사", completedAt: "2025-03-20 16:45", status: "완료", finalScore: 72 },
  { id: "p5", surveyId: "v1", studentId: "S005", studentName: "정하은", department: "마케팅학과", program: "석사", completedAt: null, status: "미완료", finalScore: null },
  { id: "p6", surveyId: "v1", studentId: "S007", studentName: "Nguyen Thi Mai", department: "국제경영학과", program: "석사", completedAt: "2025-03-22 11:20", status: "완료", finalScore: 81 },
  { id: "p7", surveyId: "v1", studentId: "S008", studentName: "최예진", department: "재무학과", program: "석사", completedAt: "2025-03-25 10:05", status: "완료", finalScore: 76 },
  { id: "p8", surveyId: "v1", studentId: "S009", studentName: "한승우", department: "경영정보학과", program: "통합", completedAt: null, status: "미완료", finalScore: null },
  { id: "p9", surveyId: "v1", studentId: "S011", studentName: "유태현", department: "데이터사이언스학과", program: "박사", completedAt: "2025-03-28 15:30", status: "완료", finalScore: 88 },
  // 2024-2학기 참여자
  { id: "p10", surveyId: "v2", studentId: "S001", studentName: "김민준", department: "경영학과", program: "박사", completedAt: "2024-09-12 10:20", status: "완료", finalScore: 75 },
  { id: "p11", surveyId: "v2", studentId: "S002", studentName: "이서연", department: "AI경영학과", program: "석사", completedAt: "2024-09-15 14:45", status: "완료", finalScore: 82 },
  { id: "p12", surveyId: "v2", studentId: "S003", studentName: "박현우", department: "데이터사이언스학과", program: "통합", completedAt: "2024-09-18 09:30", status: "완료", finalScore: 79 },
  { id: "p13", surveyId: "v2", studentId: "S006", studentName: "오진석", department: "회계학과", program: "박사", completedAt: "2024-09-20 11:15", status: "완료", finalScore: 84 },
  { id: "p14", surveyId: "v2", studentId: "S010", studentName: "강수빈", department: "경영학과", program: "석사", completedAt: "2024-09-22 16:00", status: "완료", finalScore: 73 },
]

// 설문 결과 데이터 (상세보기용)
const surveyResults: Record<string, {
  competencies: {
    name: string
    score: number
    level: string
    categories: {
      name: string
      score: number
      subCategories: {
        name: string
        score: number
        level: string
        interpretation: string
      }[]
    }[]
  }[]
}> = {
  "p1": {
    competencies: [
      {
        name: "학습연구역량",
        score: 78,
        level: "우수",
        categories: [
          {
            name: "성격특성",
            score: 82,
            subCategories: [
              { name: "학업적 효능감", score: 85, level: "탁월", interpretation: "학업적 효능감이 탁월한 수준입니다. 어려운 연구 과제도 자신감을 가지고 수행합니다." },
              { name: "학업적 회복탄력성", score: 80, level: "우수", interpretation: "학업적 회복탄력성이 우수한 수준입니다. 연구 과정의 어려움을 잘 극복합니다." },
              { name: "성실성 및 책임감", score: 81, level: "우수", interpretation: "성실성 및 책임감이 우수한 수준입니다. 연구 과제를 책임감 있게 수행합니다." },
            ]
          },
          {
            name: "자기관리",
            score: 75,
            subCategories: [
              { name: "시간관리", score: 72, level: "보통", interpretation: "시간관리가 보통 수준입니다. 체계적인 계획 수립이 필요합니다." },
              { name: "집중력 및 학습환경 관리", score: 78, level: "우수", interpretation: "집중력 및 학습환경 관리가 우수한 수준입니다." },
              { name: "학습전략 및 정보처리", score: 75, level: "보통", interpretation: "학습전략 및 정보처리가 보통 수준입니다." },
            ]
          },
        ]
      },
      {
        name: "융합연구역량",
        score: 72,
        level: "보통",
        categories: [
          {
            name: "창의·비판적 사고 역량",
            score: 74,
            subCategories: [
              { name: "논리적 추론", score: 76, level: "우수", interpretation: "논리적 추론이 우수한 수준입니다." },
              { name: "다학제간 통찰", score: 72, level: "보통", interpretation: "다학제간 통찰이 보통 수준입니다." },
              { name: "독창적 발상", score: 70, level: "보통", interpretation: "독창적 발상이 보통 수준입니다." },
              { name: "메타인지적 성찰", score: 78, level: "우수", interpretation: "메타인지적 성찰이 우수한 수준입니다." },
            ]
          },
        ]
      }
    ]
  },
  "p2": {
    competencies: [
      {
        name: "학습연구역량",
        score: 85,
        level: "탁월",
        categories: [
          {
            name: "성격특성",
            score: 88,
            subCategories: [
              { name: "학업적 효능감", score: 90, level: "탁월", interpretation: "학업적 효능감이 탁월한 수준입니다." },
              { name: "학업적 회복탄��성", score: 86, level: "탁월", interpretation: "학업적 회복탄력성이 탁월한 수준입니다." },
              { name: "성실성 및 책임감", score: 88, level: "탁월", interpretation: "성실성 및 책임감이 탁월한 수준입니다." },
            ]
          },
        ]
      },
    ]
  },
}

const programColors: Record<string, string> = {
  "석사": "bg-blue-50 text-blue-700 border-blue-200",
  "박사": "bg-indigo-50 text-indigo-700 border-indigo-200",
  "통합": "bg-gray-100 text-gray-600 border-gray-200",
}

const statusColors: Record<string, string> = {
  "완료": "bg-green-50 text-green-700 border-green-200",
  "미완료": "bg-amber-50 text-amber-700 border-amber-200",
  "진행중": "bg-blue-50 text-blue-700 border-blue-200",
}

const levelColors: Record<string, string> = {
  "기본": "bg-gray-100 text-gray-700",
  "보통": "bg-blue-100 text-blue-700",
  "우수": "bg-emerald-100 text-emerald-700",
  "탁월": "bg-amber-100 text-amber-700",
}

const ITEMS_PER_PAGE = 10

// 학과 목록 (surveyParticipations에서 추출)
const departments = [...new Set(surveyParticipations.map(p => p.department))].sort()

// 역량 목록
const competencyList = ["학습연구역량", "융합연구역량"]

// 이름 마스킹 함수 (중간 글자 숨기기)
const maskName = (name: string): string => {
  if (name.length <= 2) return name
  const first = name[0]
  const last = name[name.length - 1]
  const asterisks = "*".repeat(name.length - 2)
  return `${first}${asterisks}${last}`
}

export default function DiagnosisPage() {
  const router = useRouter()
  
  // 필터 상태
  const [selectedYear, setSelectedYear] = useState<string>("2025")
  const [selectedSemester, setSelectedSemester] = useState<string>("1")
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [departmentFilter, setDepartmentFilter] = useState<string>("all")
  const [competencyFilter, setCompetencyFilter] = useState<string>("all")
  const [currentPage, setCurrentPage] = useState(1)

  // 선택된 설문지
  const selectedSurvey = deployedSurveys.find(
    s => s.year === selectedYear && s.semester === selectedSemester
  )

  // 해당 설문지의 참여 목록
  const participations = useMemo(() => {
    if (!selectedSurvey) return []
    return surveyParticipations.filter(p => p.surveyId === selectedSurvey.id)
  }, [selectedSurvey])

  // 필터링된 참여 목록
  const filteredParticipations = useMemo(() => {
    return participations.filter(p => {
      const query = searchQuery.toLowerCase()
      const matchesSearch = !searchQuery || 
        p.studentName.toLowerCase().includes(query) ||
        p.studentId.includes(query) ||
        p.department.toLowerCase().includes(query)
      const matchesStatus = statusFilter === "all" || p.status === statusFilter
      const matchesDepartment = departmentFilter === "all" || p.department === departmentFilter
      return matchesSearch && matchesStatus && matchesDepartment
    })
  }, [participations, searchQuery, statusFilter, departmentFilter])

  // 페이지네이션
  const totalPages = Math.max(1, Math.ceil(filteredParticipations.length / ITEMS_PER_PAGE))
  const safePage = Math.min(currentPage, totalPages)
  const paginatedParticipations = filteredParticipations.slice(
    (safePage - 1) * ITEMS_PER_PAGE,
    safePage * ITEMS_PER_PAGE
  )

  // 통계
  const totalParticipants = participations.length
  const completedCount = participations.filter(p => p.status === "완료").length
  const pendingCount = participations.filter(p => p.status === "미완료").length
  const completionRate = totalParticipants > 0 ? Math.round((completedCount / totalParticipants) * 100) : 0

  // 연도 목록
  const years = [...new Set(deployedSurveys.map(s => s.year))].sort((a, b) => b.localeCompare(a))

  const handleSearchClear = () => {
    setSearchQuery("")
    setCurrentPage(1)
  }

  const handleFilterReset = () => {
    setSearchQuery("")
    setStatusFilter("all")
    setDepartmentFilter("all")
    setCompetencyFilter("all")
    setCurrentPage(1)
  }

  const handleViewResult = (participationId: string) => {
    router.push(`/competency/diagnosis/${participationId}`)
  }

  // 엑셀 다운로드 기능
  const handleExcelDownload = () => {
    const headers = ["No", "이름", "학번", "학과", "최종 점수", "상태", "완료일시"]
    const data = filteredParticipations.map((p, idx) => [
      idx + 1,
      maskName(p.studentName),
      p.studentId,
      p.department,
      p.finalScore !== null ? p.finalScore : "-",
      p.status,
      p.completedAt || "-"
    ])

    // CSV 형식으로 변환
    const csvContent = [
      headers.join(","),
      ...data.map(row => row.map(cell => `"${cell}"`).join(","))
    ].join("\n")

    // BOM 추가 (한글 깨짐 방지)
    const BOM = "\uFEFF"
    const blob = new Blob([BOM + csvContent], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    
    const link = document.createElement("a")
    link.href = url
    link.download = `진단현황_${selectedYear}학년도_${selectedSemester}학기_${departmentFilter === "all" ? "전체학과" : departmentFilter}.csv`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  }

  return (
    <div className="flex flex-col gap-4 p-4 md:gap-6 md:p-6">
      {/* Page Header */}
      <div>
        <h1 className="text-xl font-bold text-foreground">진단현황</h1>
        <p className="text-sm text-muted-foreground mt-1">배포된 설문지에 대한 학생들의 참여 현황을 확인합니다.</p>
      </div>

      {/* 설문지 선택 */}
      <Card>
        <CardContent className="py-3">
          <div className="flex flex-col gap-3">
            {/* 1줄: 선택 + 년도/학기/역량/학과 */}
            <div className="flex flex-wrap items-center gap-3">
              <span className="text-sm font-semibold text-foreground">선택</span>
              <Select value={selectedYear} onValueChange={(v) => { setSelectedYear(v); setCurrentPage(1) }}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="연도" />
                </SelectTrigger>
                <SelectContent>
                  {years.map(year => (
                    <SelectItem key={year} value={year}>{year}학년도</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={selectedSemester} onValueChange={(v) => { setSelectedSemester(v); setCurrentPage(1) }}>
                <SelectTrigger className="w-28">
                  <SelectValue placeholder="학기" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1학기</SelectItem>
                  <SelectItem value="2">2학기</SelectItem>
                </SelectContent>
              </Select>
              <Select value={competencyFilter} onValueChange={(v) => { setCompetencyFilter(v); setCurrentPage(1) }}>
                <SelectTrigger className="w-36">
                  <SelectValue placeholder="역량 선택" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">전체 역량</SelectItem>
                  {competencyList.map(comp => (
                    <SelectItem key={comp} value={comp}>{comp}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={departmentFilter} onValueChange={(v) => { setDepartmentFilter(v); setCurrentPage(1) }}>
                <SelectTrigger className="w-44">
                  <SelectValue placeholder="학과 선택" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">전체 학과</SelectItem>
                  {departments.map(dept => (
                    <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {/* 2줄: 선택된 옵션 정보 표시 + 엑셀 다운로드 */}
            {selectedSurvey && (
              <div className="flex flex-wrap items-center justify-between gap-2 text-sm">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-muted-foreground">선택 조건:</span>
                  <Badge variant="secondary">{selectedYear}학년도 {selectedSemester}학기</Badge>
                  <Badge variant="secondary">{competencyFilter === "all" ? "전체 역량" : competencyFilter}</Badge>
                  <Badge variant="secondary">{departmentFilter === "all" ? "전체 학과" : departmentFilter}</Badge>
                  <span className="mx-1 text-muted-foreground">|</span>
                  <Badge variant="outline" className={statusColors[selectedSurvey.status]}>
                    {selectedSurvey.status}
                  </Badge>
                  <span className="text-muted-foreground">
                    {selectedSurvey.startDate} ~ {selectedSurvey.endDate}
                  </span>
                </div>
                <Button variant="outline" size="sm" onClick={handleExcelDownload} className="gap-1">
                  <Download className="h-4 w-4" />
                  엑셀 다운로드
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {selectedSurvey ? (
        <>
          {/* 통계 카드 */}
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <Card>
              <CardContent className="flex items-center gap-3 p-3">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                  <Users className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">대상 학생</p>
                  <p className="text-lg font-bold text-foreground">{totalParticipants}<span className="text-sm font-normal text-muted-foreground ml-1">명</span></p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="flex items-center gap-3 p-3">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-green-50">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">완료</p>
                  <p className="text-lg font-bold text-foreground">{completedCount}<span className="text-sm font-normal text-muted-foreground ml-1">명</span></p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="flex items-center gap-3 p-3">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-amber-50">
                  <Clock className="h-4 w-4 text-amber-600" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">미완료</p>
                  <p className="text-lg font-bold text-foreground">{pendingCount}<span className="text-sm font-normal text-muted-foreground ml-1">명</span></p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="flex items-center gap-3 p-3">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-blue-50">
                  <ClipboardList className="h-4 w-4 text-blue-600" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">참여율</p>
                  <p className="text-lg font-bold text-foreground">{completionRate}<span className="text-sm font-normal text-muted-foreground ml-1">%</span></p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* 참여 목록 */}
          <Card>
            <CardHeader>
              <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                <CardTitle className="text-sm font-semibold">
                  참여 현황 {departmentFilter !== "all" && <span className="text-primary">- {departmentFilter}</span>}
                </CardTitle>
                <div className="flex flex-col gap-2 md:flex-row md:items-center">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder="이름, 학번, 학과 검색"
                      value={searchQuery}
                      onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1) }}
                      className="pl-9 pr-9 w-full md:w-60"
                    />
                    {searchQuery && (
                      <button
                        onClick={handleSearchClear}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                  <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setCurrentPage(1) }}>
                    <SelectTrigger className="w-full md:w-28">
                      <SelectValue placeholder="상태" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">전체</SelectItem>
                      <SelectItem value="완료">완료</SelectItem>
                      <SelectItem value="미완료">미완료</SelectItem>
                    </SelectContent>
                  </Select>
                  {(searchQuery || statusFilter !== "all" || departmentFilter !== "all" || competencyFilter !== "all") && (
                    <Button variant="ghost" size="sm" onClick={handleFilterReset} className="text-muted-foreground">
                      <X className="h-4 w-4 mr-1" />
                      초기화
                    </Button>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="overflow-x-auto rounded-lg border border-border">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border bg-muted/40">
                      <th className="px-3 py-2 text-left text-xs font-semibold text-muted-foreground">No</th>
                      <th className="px-3 py-2 text-left text-xs font-semibold text-muted-foreground">이름</th>
                      <th className="px-3 py-2 text-left text-xs font-semibold text-muted-foreground">학번</th>
                      <th className="px-3 py-2 text-left text-xs font-semibold text-muted-foreground">학과</th>
                      <th className="px-3 py-2 text-center text-xs font-semibold text-muted-foreground">최종 점수</th>
                      <th className="px-3 py-2 text-center text-xs font-semibold text-muted-foreground">상태</th>
                      <th className="px-3 py-2 text-center text-xs font-semibold text-muted-foreground">완료일시</th>
                      <th className="px-3 py-2 text-center text-xs font-semibold text-muted-foreground">상세</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {paginatedParticipations.length > 0 ? (
                      paginatedParticipations.map((p, idx) => (
                        <tr key={p.id} className="hover:bg-muted/30 transition-colors">
                          <td className="px-3 py-2 text-sm">{(safePage - 1) * ITEMS_PER_PAGE + idx + 1}</td>
                          <td className="px-3 py-2 font-medium text-foreground">{maskName(p.studentName)}</td>
                          <td className="px-3 py-2 font-mono text-xs text-muted-foreground">{p.studentId}</td>
                          <td className="px-3 py-2 text-foreground">{p.department}</td>
                          <td className="px-3 py-2 text-center">
                            {p.finalScore !== null ? (
                              <span className="inline-block rounded-full bg-blue-50 border border-blue-200 px-2 py-0.5 text-[11px] font-semibold text-blue-700">
                                {p.finalScore}점
                              </span>
                            ) : (
                              <span className="text-xs text-muted-foreground">-</span>
                            )}
                          </td>
                          <td className="px-3 py-2 text-center">
                            <span className={`inline-block rounded-full border px-2 py-0.5 text-[11px] font-semibold ${statusColors[p.status]}`}>
                              {p.status}
                            </span>
                          </td>
                          <td className="px-3 py-2 text-center text-xs text-muted-foreground">
                            {p.completedAt || "-"}
                          </td>
                          <td className="px-3 py-2 text-center">
                            {p.status === "완료" ? (
                              <Button
                                variant="outline"
                                size="sm"
                                className="h-7 text-xs"
                                onClick={() => handleViewResult(p.id)}
                              >
                                진단결과
                              </Button>
                            ) : (
                              <span className="text-xs text-muted-foreground">-</span>
                            )}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={8} className="px-4 py-12 text-center text-muted-foreground">
                          검색 결과가 없습니다.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Pagination */}
              <div className="mt-3 flex items-center justify-between">
                <p className="text-sm text-muted-foreground">
                  총 <span className="font-semibold text-foreground">{filteredParticipations.length}</span>명
                </p>
                <div className="flex items-center gap-1">
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={safePage <= 1}
                    onClick={() => setCurrentPage(1)}
                    className="h-7 w-7 p-0"
                  >
                    <ChevronLeft className="h-4 w-4" />
                    <ChevronLeft className="h-4 w-4 -ml-2" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={safePage <= 1}
                    onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                    className="h-7 w-7 p-0"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                    <Button
                      key={page}
                      variant={page === safePage ? "default" : "outline"}
                      size="sm"
                      onClick={() => setCurrentPage(page)}
                      className="h-7 w-7 p-0 text-xs"
                    >
                      {page}
                    </Button>
                  ))}
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={safePage >= totalPages}
                    onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                    className="h-7 w-7 p-0"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={safePage >= totalPages}
                    onClick={() => setCurrentPage(totalPages)}
                    className="h-7 w-7 p-0"
                  >
                    <ChevronRight className="h-4 w-4" />
                    <ChevronRight className="h-4 w-4 -ml-2" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16 text-muted-foreground">
            <FileText className="h-12 w-12 mb-4" />
            <p className="text-base font-medium">해당 학기에 배포된 설문지가 없습니다.</p>
            <p className="text-sm mt-1">다른 학년도/학기를 선택해주세요.</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
