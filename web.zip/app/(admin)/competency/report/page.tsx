import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function ReportPage() {
  return (
    <div className="flex flex-col gap-6 p-4 md:gap-8 md:p-8">
      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-bold">{'리포트관리'}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            {'핵심역량 리포트 내용이 여기에 표시됩니다.'}
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
