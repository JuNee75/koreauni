"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Plus, Search, Pencil, Trash2, Eye, ChevronLeft, ChevronRight } from "lucide-react"
import Link from "next/link"

interface Notice {
  id: number
  title: string
  author: string
  date: string
  views: number
  isPinned: boolean
}

const mockNotices: Notice[] = [
  {
    id: 1,
    title: "2026학년도 1학기 학사일정 안내",
    author: "관리자",
    date: "2026-02-15",
    views: 1245,
    isPinned: true,
  },
  {
    id: 2,
    title: "대학원 장학금 신청 안내",
    author: "관리자",
    date: "2026-02-10",
    views: 892,
    isPinned: true,
  },
  {
    id: 3,
    title: "학위논문 심사 일정 공고",
    author: "교학팀",
    date: "2026-02-05",
    views: 567,
    isPinned: false,
  },
  {
    id: 4,
    title: "대학원 연구실 배정 결과 안내",
    author: "관리자",
    date: "2026-01-28",
    views: 423,
    isPinned: false,
  },
  {
    id: 5,
    title: "2026년 국제학술대회 참가 지원 안내",
    author: "교학팀",
    date: "2026-01-20",
    views: 356,
    isPinned: false,
  },
  {
    id: 6,
    title: "대학원생 연구윤리교육 이수 안내",
    author: "관리자",
    date: "2026-01-15",
    views: 289,
    isPinned: false,
  },
  {
    id: 7,
    title: "학생증 재발급 신청 안내",
    author: "행정팀",
    date: "2026-01-10",
    views: 234,
    isPinned: false,
  },
  {
    id: 8,
    title: "도서관 이용시간 변경 안내",
    author: "도서관",
    date: "2026-01-05",
    views: 198,
    isPinned: false,
  },
  {
    id: 9,
    title: "2026학년도 수강신청 안내",
    author: "교학팀",
    date: "2025-12-28",
    views: 456,
    isPinned: false,
  },
  {
    id: 10,
    title: "대학원 세미나실 예약 안내",
    author: "행정팀",
    date: "2025-12-20",
    views: 312,
    isPinned: false,
  },
  {
    id: 11,
    title: "학위수여식 일정 공지",
    author: "관리자",
    date: "2025-12-15",
    views: 789,
    isPinned: false,
  },
  {
    id: 12,
    title: "연구비 집행 지침 안내",
    author: "행정팀",
    date: "2025-12-10",
    views: 267,
    isPinned: false,
  },
  {
    id: 13,
    title: "대학원생 건강검진 안내",
    author: "보건센터",
    date: "2025-12-05",
    views: 523,
    isPinned: false,
  },
  {
    id: 14,
    title: "학기 중 연구활동 지원 프로그램",
    author: "교학팀",
    date: "2025-11-28",
    views: 445,
    isPinned: false,
  },
  {
    id: 15,
    title: "대학원 오리엔테이션 안내",
    author: "관리자",
    date: "2025-11-20",
    views: 678,
    isPinned: false,
  },
]

export default function NoticeBoardPage() {
  const [notices, setNotices] = useState<Notice[]>(mockNotices)
  const [searchQuery, setSearchQuery] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 10

  const filteredNotices = notices.filter((notice) =>
    notice.title.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const totalPages = Math.ceil(filteredNotices.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const endIndex = startIndex + itemsPerPage
  const currentNotices = filteredNotices.slice(startIndex, endIndex)

  const handleDelete = (id: number) => {
    if (confirm("정말 삭제하시겠습니까?")) {
      setNotices(notices.filter((notice) => notice.id !== id))
    }
  }

  const handlePageChange = (page: number) => {
    setCurrentPage(page)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  return (
    <div className="flex flex-col gap-6 p-4 md:gap-8 md:p-8">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <CardTitle className="text-xl font-bold">공지사항 관리</CardTitle>
          <Link href="/board/notice/create">
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              등록
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          <div className="mb-6 flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="제목으로 검색..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          <div className="overflow-hidden rounded-lg border border-border">
            <table className="w-full">
              <thead className="bg-muted/50">
                <tr className="border-b border-border">
                  <th className="px-4 py-3 text-left text-sm font-semibold">번호</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold">제목</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold">작성자</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold">작성일</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold">조회수</th>
                  <th className="px-4 py-3 text-center text-sm font-semibold">관리</th>
                </tr>
              </thead>
              <tbody>
                {currentNotices.map((notice) => (
                  <tr
                    key={notice.id}
                    className="border-b border-border transition-colors hover:bg-muted/30"
                  >
                    <td className="px-4 py-3 text-sm">
                      {notice.isPinned ? (
                        <span className="inline-flex items-center rounded-full bg-primary px-2 py-1 text-xs font-medium text-primary-foreground">
                          공지
                        </span>
                      ) : (
                        notice.id
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-sm ${notice.isPinned ? "font-semibold" : ""}`}>
                        {notice.title}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">
                      {notice.author}
                    </td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">
                      {notice.date}
                    </td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Eye className="h-3 w-3" />
                        {notice.views}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-2">
                        <Link href={`/board/notice/edit/${notice.id}`}>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Pencil className="h-4 w-4" />
                          </Button>
                        </Link>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-destructive hover:text-destructive"
                          onClick={() => handleDelete(notice.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredNotices.length === 0 && (
            <div className="py-12 text-center text-sm text-muted-foreground">
              검색 결과가 없습니다.
            </div>
          )}

          {filteredNotices.length > 0 && totalPages > 1 && (
            <div className="mt-6 flex items-center justify-center gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
                className="h-8 w-8"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <Button
                  key={page}
                  variant={currentPage === page ? "default" : "outline"}
                  size="sm"
                  onClick={() => handlePageChange(page)}
                  className="h-8 min-w-8 px-3"
                >
                  {page}
                </Button>
              ))}

              <Button
                variant="outline"
                size="icon"
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
                className="h-8 w-8"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
