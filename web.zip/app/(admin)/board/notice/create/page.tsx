"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function NoticeCreatePage() {
  const router = useRouter()
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  const [isPinned, setIsPinned] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    // Here you would typically send the data to your backend
    console.log("[v0] Creating notice:", { title, content, isPinned })
    
    alert("공지사항이 등록되었습니다.")
    router.push("/board/notice")
  }

  const handleCancel = () => {
    if (title || content) {
      if (confirm("작성 중인 내용이 있습니다. 취소하시겠습니까?")) {
        router.push("/board/notice")
      }
    } else {
      router.push("/board/notice")
    }
  }

  return (
    <div className="flex flex-col gap-6 p-4 md:gap-8 md:p-8">
      <div className="flex items-center gap-4">
        <Link href="/board/notice">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">공지사항 등록</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold">공지사항 정보</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="title">제목</Label>
              <Input
                id="title"
                placeholder="공지사항 제목을 입력하세요"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="content">내용</Label>
              <Textarea
                id="content"
                placeholder="공지사항 내용을 입력하세요"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                rows={12}
                required
                className="resize-none"
              />
            </div>

            <div className="flex items-center justify-between rounded-lg border border-border bg-muted/20 p-4">
              <div className="space-y-0.5">
                <Label htmlFor="pinned" className="text-base">
                  상단 고정
                </Label>
                <p className="text-sm text-muted-foreground">
                  이 공지사항을 목록 상단에 고정합니다
                </p>
              </div>
              <Switch
                id="pinned"
                checked={isPinned}
                onCheckedChange={setIsPinned}
              />
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={handleCancel}>
                취소
              </Button>
              <Button type="submit">등록</Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
