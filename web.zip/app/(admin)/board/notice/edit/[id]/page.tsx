"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { useRouter, useParams } from "next/navigation"

// Mock data for demonstration
const mockNoticeData: Record<string, { title: string; content: string; isPinned: boolean }> = {
  "1": {
    title: "2024학년도 1학기 학사일정 안내",
    content: "2024학년도 1학기 학사일정을 다음과 같이 안내드립니다.\n\n1. 개강: 2024년 3월 4일(월)\n2. 수강신청: 2024년 2월 19일(월) ~ 2월 23일(금)\n3. 중간고사: 2024년 4월 22일(월) ~ 4월 26일(금)\n4. 종강: 2024년 6월 21일(금)\n\n자세한 사항은 학사공지를 참고해주시기 바랍니다.",
    isPinned: true,
  },
  "2": {
    title: "대학원 장학금 신청 안내",
    content: "2024학년도 1학기 대학원 장학금 신청을 다음과 같이 안내합니다.\n\n■ 신청 기간: 2024년 2월 26일(월) ~ 3월 8일(금)\n■ 신청 대상: 재학생 전체\n■ 제출 서류: 장학금 신청서, 성적증명서\n\n자세한 내용은 첨부 파일을 확인해주시기 바랍니다.",
    isPinned: true,
  },
}

export default function NoticeEditPage() {
  const router = useRouter()
  const params = useParams()
  const id = params.id as string
  
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  const [isPinned, setIsPinned] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate fetching data
    const noticeData = mockNoticeData[id]
    if (noticeData) {
      setTitle(noticeData.title)
      setContent(noticeData.content)
      setIsPinned(noticeData.isPinned)
    }
    setIsLoading(false)
  }, [id])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    // Here you would typically send the data to your backend
    console.log("[v0] Updating notice:", { id, title, content, isPinned })
    
    alert("공지사항이 수정되었습니다.")
    router.push("/board/notice")
  }

  const handleCancel = () => {
    if (confirm("수정을 취소하시겠습니까?")) {
      router.push("/board/notice")
    }
  }

  if (isLoading) {
    return (
      <div className="flex min-h-[400px] items-center justify-center">
        <p className="text-muted-foreground">로딩 중...</p>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6 p-4 md:gap-8 md:p-8">
      <div className="flex items-center gap-4">
        <Link href="/board/notice">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">공지사항 수정</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold">공지사항 정보</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="title">제목</Label>
              <Input
                id="title"
                placeholder="공지사항 제목을 입력하세요"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="content">내용</Label>
              <Textarea
                id="content"
                placeholder="공지사항 내용을 입력하세요"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                rows={12}
                required
                className="resize-none"
              />
            </div>

            <div className="flex items-center justify-between rounded-lg border border-border bg-muted/20 p-4">
              <div className="space-y-0.5">
                <Label htmlFor="pinned" className="text-base">
                  상단 고정
                </Label>
                <p className="text-sm text-muted-foreground">
                  이 공지사항을 목록 상단에 고정합니다
                </p>
              </div>
              <Switch
                id="pinned"
                checked={isPinned}
                onCheckedChange={setIsPinned}
              />
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={handleCancel}>
                취소
              </Button>
              <Button type="submit">저장</Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
