"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, Upload, FileText, X } from "lucide-react"
import Link from "next/link"
import { useRouter, useParams } from "next/navigation"

// Mock data for demonstration
const mockArchiveData: Record<string, { 
  title: string
  content: string
  fileName: string
  fileSize: number
}> = {
  "1": {
    title: "2024학년도 대학원 입학전형 요강",
    content: "2024학년도 대학원 석사과정 및 박사과정 입학전형 요강입니다.\n\n주요 전형일정, 지원자격, 제출서류 등이 포함되어 있습니다.",
    fileName: "입학전형요강_2024.pdf",
    fileSize: 2457600,
  },
  "2": {
    title: "학위논문 작성 지침서",
    content: "대학원 학위논문 작성을 위한 상세 지침서입니다.\n\n논문 형식, 인용 방법, 제출 절차 등을 안내합니다.",
    fileName: "논문작성지침서.pdf",
    fileSize: 1843200,
  },
}

export default function ArchiveEditPage() {
  const router = useRouter()
  const params = useParams()
  const id = params.id as string
  const fileInputRef = useRef<HTMLInputElement>(null)
  
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  const [existingFileName, setExistingFileName] = useState("")
  const [existingFileSize, setExistingFileSize] = useState(0)
  const [newFile, setNewFile] = useState<File | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate fetching data
    const archiveData = mockArchiveData[id]
    if (archiveData) {
      setTitle(archiveData.title)
      setContent(archiveData.content)
      setExistingFileName(archiveData.fileName)
      setExistingFileSize(archiveData.fileSize)
    }
    setIsLoading(false)
  }, [id])

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (selectedFile) {
      // Check file size (max 10MB)
      if (selectedFile.size > 10 * 1024 * 1024) {
        alert("파일 크기는 10MB를 초과할 수 없습니다.")
        return
      }
      setNewFile(selectedFile)
    }
  }

  const handleRemoveNewFile = () => {
    setNewFile(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    // Here you would typically send the data to your backend
    console.log("[v0] Updating archive:", { 
      id, 
      title, 
      content, 
      newFile: newFile?.name || "No new file" 
    })
    
    alert("자료가 수정되었습니다.")
    router.push("/board/archive")
  }

  const handleCancel = () => {
    if (confirm("수정을 취소하시겠습니까?")) {
      router.push("/board/archive")
    }
  }

  if (isLoading) {
    return (
      <div className="flex min-h-[400px] items-center justify-center">
        <p className="text-muted-foreground">로딩 중...</p>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6 p-4 md:gap-8 md:p-8">
      <div className="flex items-center gap-4">
        <Link href="/board/archive">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">자료 수정</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold">자료 정보</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="title">제목</Label>
              <Input
                id="title"
                placeholder="자료 제목을 입력하세요"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="content">설명</Label>
              <Textarea
                id="content"
                placeholder="자료에 대한 설명을 입력하세요"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                rows={8}
                className="resize-none"
              />
            </div>

            <div className="space-y-2">
              <Label>현재 파일</Label>
              <div className="flex items-center gap-3 rounded-lg border border-border bg-muted/20 p-4">
                <FileText className="h-8 w-8 text-muted-foreground" />
                <div className="flex-1">
                  <p className="text-sm font-medium">{existingFileName}</p>
                  <p className="text-xs text-muted-foreground">
                    {(existingFileSize / 1024).toFixed(2)} KB
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="file">새 파일 첨부 (선택)</Label>
              {!newFile ? (
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed border-border bg-muted/20 p-8 transition-colors hover:bg-muted/30"
                >
                  <Upload className="h-10 w-10 text-muted-foreground" />
                  <div className="text-center">
                    <p className="text-sm font-medium">
                      파일을 변경하려면 클릭하세요
                    </p>
                    <p className="text-xs text-muted-foreground">
                      최대 파일 크기: 10MB
                    </p>
                  </div>
                  <input
                    ref={fileInputRef}
                    id="file"
                    type="file"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                </div>
              ) : (
                <div className="flex items-center gap-3 rounded-lg border border-primary bg-primary/5 p-4">
                  <FileText className="h-10 w-10 text-primary" />
                  <div className="flex-1">
                    <p className="font-medium">{newFile.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {(newFile.size / 1024).toFixed(2)} KB
                    </p>
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={handleRemoveNewFile}
                  >
                    <X className="h-5 w-5" />
                  </Button>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={handleCancel}>
                취소
              </Button>
              <Button type="submit">저장</Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
