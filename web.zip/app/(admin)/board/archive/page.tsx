"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Plus, Search, Pencil, Trash2, Download, FileText, ChevronLeft, ChevronRight } from "lucide-react"
import Link from "next/link"

interface Archive {
  id: number
  title: string
  author: string
  date: string
  downloads: number
  fileSize: string
  fileName: string
}

const mockArchives: Archive[] = [
  {
    id: 1,
    title: "2026학년도 대학원 입학전형 요강",
    author: "관리자",
    date: "2026-02-20",
    downloads: 543,
    fileSize: "2.4 MB",
    fileName: "입학전형요강_2026.pdf",
  },
  {
    id: 2,
    title: "학위논문 작성 지침서",
    author: "교학팀",
    date: "2026-02-15",
    downloads: 892,
    fileSize: "1.8 MB",
    fileName: "논문작성지침서.pdf",
  },
  {
    id: 3,
    title: "연구윤리 교육자료",
    author: "관리자",
    date: "2026-02-10",
    downloads: 456,
    fileSize: "3.2 MB",
    fileName: "연구윤리교육.pdf",
  },
  {
    id: 4,
    title: "장학금 신청서 양식",
    author: "행정팀",
    date: "2026-02-05",
    downloads: 723,
    fileSize: "0.5 MB",
    fileName: "장학금신청서.docx",
  },
  {
    id: 5,
    title: "대학원 종합시험 과거문제",
    author: "교학팀",
    date: "2026-01-28",
    downloads: 1245,
    fileSize: "4.1 MB",
    fileName: "종합시험_과거문제.pdf",
  },
  {
    id: 6,
    title: "학위논문 심사 신청서",
    author: "관리자",
    date: "2026-01-20",
    downloads: 634,
    fileSize: "0.3 MB",
    fileName: "논문심사신청서.docx",
  },
  {
    id: 7,
    title: "대학원생 연구실 사용 규정",
    author: "행정팀",
    date: "2026-01-15",
    downloads: 289,
    fileSize: "0.8 MB",
    fileName: "연구실사용규정.pdf",
  },
  {
    id: 8,
    title: "국제학술대회 지원신청서",
    author: "교학팀",
    date: "2026-01-10",
    downloads: 412,
    fileSize: "0.6 MB",
    fileName: "학술대회지원신청서.docx",
  },
  {
    id: 9,
    title: "대학원생 연구실적 입력 가이드",
    author: "행정팀",
    date: "2025-12-28",
    downloads: 567,
    fileSize: "1.2 MB",
    fileName: "연구실적입력가이드.pdf",
  },
  {
    id: 10,
    title: "학위논문 표지 서식",
    author: "교학팀",
    date: "2025-12-20",
    downloads: 834,
    fileSize: "0.2 MB",
    fileName: "논문표지서식.docx",
  },
  {
    id: 11,
    title: "대학원 연구윤리 서약서",
    author: "관리자",
    date: "2025-12-15",
    downloads: 345,
    fileSize: "0.3 MB",
    fileName: "연구윤리서약서.pdf",
  },
  {
    id: 12,
    title: "학위청구논문 심사료 납부 안내",
    author: "행정팀",
    date: "2025-12-10",
    downloads: 423,
    fileSize: "0.4 MB",
    fileName: "심사료납부안내.pdf",
  },
  {
    id: 13,
    title: "대학원 수료증명서 발급 신청서",
    author: "교학팀",
    date: "2025-12-05",
    downloads: 298,
    fileSize: "0.3 MB",
    fileName: "수료증명서신청서.docx",
  },
  {
    id: 14,
    title: "연구실안전교육 이수증",
    author: "안전관리팀",
    date: "2025-11-28",
    downloads: 512,
    fileSize: "0.7 MB",
    fileName: "안전교육이수증.pdf",
  },
  {
    id: 15,
    title: "대학원생 학회발표 지원 신청서",
    author: "교학팀",
    date: "2025-11-20",
    downloads: 689,
    fileSize: "0.5 MB",
    fileName: "학회발표지원신청서.docx",
  },
]

export default function ArchiveBoardPage() {
  const [archives, setArchives] = useState<Archive[]>(mockArchives)
  const [searchQuery, setSearchQuery] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 10

  const filteredArchives = archives.filter((archive) =>
    archive.title.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const totalPages = Math.ceil(filteredArchives.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const endIndex = startIndex + itemsPerPage
  const currentArchives = filteredArchives.slice(startIndex, endIndex)

  const handleDelete = (id: number) => {
    if (confirm("정말 삭제하시겠습니까?")) {
      setArchives(archives.filter((archive) => archive.id !== id))
    }
  }

  const handlePageChange = (page: number) => {
    setCurrentPage(page)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  return (
    <div className="flex flex-col gap-6 p-4 md:gap-8 md:p-8">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <CardTitle className="text-xl font-bold">자료실 관리</CardTitle>
          <Link href="/board/archive/create">
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              등록
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          <div className="mb-6 flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="제목으로 검색..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          <div className="overflow-hidden rounded-lg border border-border">
            <table className="w-full">
              <thead className="bg-muted/50">
                <tr className="border-b border-border">
                  <th className="px-4 py-3 text-left text-sm font-semibold">번호</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold">제목</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold">작성자</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold">파일명</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold">작성일</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold">다운로드</th>
                  <th className="px-4 py-3 text-center text-sm font-semibold">관리</th>
                </tr>
              </thead>
              <tbody>
                {currentArchives.map((archive) => (
                  <tr
                    key={archive.id}
                    className="border-b border-border transition-colors hover:bg-muted/30"
                  >
                    <td className="px-4 py-3 text-sm">{archive.id}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">{archive.title}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">
                      {archive.author}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex flex-col">
                        <span className="text-xs text-muted-foreground">
                          {archive.fileName}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {archive.fileSize}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">
                      {archive.date}
                    </td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Download className="h-3 w-3" />
                        {archive.downloads}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-2">
                        <Link href={`/board/archive/edit/${archive.id}`}>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Pencil className="h-4 w-4" />
                          </Button>
                        </Link>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-destructive hover:text-destructive"
                          onClick={() => handleDelete(archive.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredArchives.length === 0 && (
            <div className="py-12 text-center text-sm text-muted-foreground">
              검색 결과가 없습니다.
            </div>
          )}

          {filteredArchives.length > 0 && totalPages > 1 && (
            <div className="mt-6 flex items-center justify-center gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
                className="h-8 w-8"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <Button
                  key={page}
                  variant={currentPage === page ? "default" : "outline"}
                  size="sm"
                  onClick={() => handlePageChange(page)}
                  className="h-8 min-w-8 px-3"
                >
                  {page}
                </Button>
              ))}

              <Button
                variant="outline"
                size="icon"
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
                className="h-8 w-8"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
