"use client"

import { useState, useMemo } from "react"
import Link from "next/link"
import { students, studentCareers } from "@/lib/student-data"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Users,
  GraduationCap,
  BookOpen,
  FlaskConical,
  ChevronRight,
  ChevronLeft,
  Search,
  X,
} from "lucide-react"

const statusColors: Record<string, string> = {
  "재학": "bg-green-50 text-green-700 border-green-200",
  "휴학": "bg-amber-50 text-amber-700 border-amber-200",
  "수료": "bg-blue-50 text-blue-700 border-blue-200",
  "졸업": "bg-gray-100 text-gray-600 border-gray-200",
}

const programColors: Record<string, string> = {
  "석사": "bg-blue-50 text-blue-700 border-blue-200",
  "박사": "bg-indigo-50 text-indigo-700 border-indigo-200",
  "통합": "bg-gray-100 text-gray-600 border-gray-200",
}

const ITEMS_PER_PAGE = 10

export default function StudentsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [programFilter, setProgramFilter] = useState<string>("all")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [currentPage, setCurrentPage] = useState(1)

  const filteredStudents = useMemo(() => {
    return students.filter((student) => {
      const query = searchQuery.toLowerCase()
      const matchesSearch =
        !searchQuery ||
        student.name.toLowerCase().includes(query) ||
        student.studentId.includes(query) ||
        student.department.toLowerCase().includes(query) ||
        student.advisor.toLowerCase().includes(query) ||
        student.researchLab.toLowerCase().includes(query)

      const matchesProgram = programFilter === "all" || student.program === programFilter
      const matchesStatus = statusFilter === "all" || student.status === statusFilter

      return matchesSearch && matchesProgram && matchesStatus
    })
  }, [searchQuery, programFilter, statusFilter])

  const totalPages = Math.max(1, Math.ceil(filteredStudents.length / ITEMS_PER_PAGE))
  const safePage = Math.min(currentPage, totalPages)
  const paginatedStudents = filteredStudents.slice(
    (safePage - 1) * ITEMS_PER_PAGE,
    safePage * ITEMS_PER_PAGE
  )

  const totalStudents = students.length
  const activeStudents = students.filter((s) => s.status === "재학").length
  const phdStudents = students.filter((s) => s.program === "박사").length
  const masterStudents = students.filter((s) => s.program === "석사").length

  const handleSearchClear = () => {
    setSearchQuery("")
    setCurrentPage(1)
  }

  const handleFilterReset = () => {
    setSearchQuery("")
    setProgramFilter("all")
    setStatusFilter("all")
    setCurrentPage(1)
  }

  return (
    <div className="flex flex-col gap-6 p-4 md:gap-8 md:p-8">
      {/* Page Header */}
      <div>
        <h1 className="text-xl font-bold text-foreground">{"학생정보 관리"}</h1>
        <p className="text-sm text-muted-foreground mt-1">{"등록된 대학원생 정보를 조회하고 관리합니다."}</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Card>
          <CardContent className="flex items-center gap-3 p-4">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
              <Users className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{"전체 학생"}</p>
              <p className="text-xl font-bold text-foreground">{totalStudents}<span className="text-sm font-normal text-muted-foreground ml-1">{"명"}</span></p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-3 p-4">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-green-50">
              <GraduationCap className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{"재학중"}</p>
              <p className="text-xl font-bold text-foreground">{activeStudents}<span className="text-sm font-normal text-muted-foreground ml-1">{"명"}</span></p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-3 p-4">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-indigo-50">
              <BookOpen className="h-5 w-5 text-indigo-600" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{"박사과정"}</p>
              <p className="text-xl font-bold text-foreground">{phdStudents}<span className="text-sm font-normal text-muted-foreground ml-1">{"명"}</span></p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-3 p-4">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-blue-50">
              <FlaskConical className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{"석사과정"}</p>
              <p className="text-xl font-bold text-foreground">{masterStudents}<span className="text-sm font-normal text-muted-foreground ml-1">{"명"}</span></p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Student Table */}
      <Card>
        <CardHeader className="pb-4">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <CardTitle className="text-base font-bold">{"학생 목록"}</CardTitle>
            <div className="flex flex-col gap-2 md:flex-row md:items-center">
              {/* Search Input */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="이름, 학번, 학과, 지도교수 검색"
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value)
                    setCurrentPage(1)
                  }}
                  className="pl-9 pr-9 w-full md:w-72"
                />
                {searchQuery && (
                  <button
                    onClick={handleSearchClear}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    aria-label="검색어 지우기"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
              {/* Program Filter */}
              <Select value={programFilter} onValueChange={(v) => { setProgramFilter(v); setCurrentPage(1) }}>
                <SelectTrigger className="w-full md:w-28">
                  <SelectValue placeholder="과정" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{"전체 과정"}</SelectItem>
                  <SelectItem value="석사">{"석사"}</SelectItem>
                  <SelectItem value="박사">{"박사"}</SelectItem>
                  <SelectItem value="통합">{"통합"}</SelectItem>
                </SelectContent>
              </Select>
              {/* Status Filter */}
              <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setCurrentPage(1) }}>
                <SelectTrigger className="w-full md:w-28">
                  <SelectValue placeholder="상태" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{"전체 상태"}</SelectItem>
                  <SelectItem value="재학">{"재학"}</SelectItem>
                  <SelectItem value="휴학">{"휴학"}</SelectItem>
                  <SelectItem value="수료">{"수료"}</SelectItem>
                  <SelectItem value="졸업">{"졸업"}</SelectItem>
                </SelectContent>
              </Select>
              {/* Reset */}
              {(searchQuery || programFilter !== "all" || statusFilter !== "all") && (
                <Button variant="ghost" size="sm" onClick={handleFilterReset} className="text-muted-foreground">
                  <X className="h-4 w-4 mr-1" />
                  {"초기화"}
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="overflow-x-auto rounded-lg border border-border">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/40">
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">{"이름"}</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">{"학번"}</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">{"학과"}</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-muted-foreground">{"과정"}</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-muted-foreground">{"학년/학기"}</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">{"지도교수"}</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">{"연구실"}</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-muted-foreground">{"상태"}</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-muted-foreground">{"논문"}</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-muted-foreground">{"상세"}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {paginatedStudents.length > 0 ? (
                  paginatedStudents.map((student) => {
                    const career = studentCareers[student.id]
                    const paperCount = career?.papers?.length ?? 0
                    return (
                      <tr key={student.id} className="hover:bg-muted/30 transition-colors">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-foreground">{student.name}</span>
                            {student.nationality === "외국인" && (
                              <span className="rounded-full border border-orange-200 bg-orange-50 px-1.5 py-0.5 text-[10px] font-semibold text-orange-700">
                                {"외국인"}
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{student.studentId}</td>
                        <td className="px-4 py-3 text-foreground">{student.department}</td>
                        <td className="px-4 py-3 text-center">
                          <span className={`inline-block rounded-full border px-2 py-0.5 text-[11px] font-semibold ${programColors[student.program]}`}>
                            {student.program}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center text-muted-foreground">{student.grade + "학년 " + student.semester + "학기"}</td>
                        <td className="px-4 py-3 text-muted-foreground">{student.advisor}</td>
                        <td className="px-4 py-3 text-muted-foreground">{student.researchLab}</td>
                        <td className="px-4 py-3 text-center">
                          <span className={`inline-block rounded-full border px-2 py-0.5 text-[11px] font-semibold ${statusColors[student.status]}`}>
                            {student.status}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center font-medium text-foreground">{paperCount}</td>
                        <td className="px-4 py-3 text-center">
                          <Link
                            href={"/students/" + student.id}
                            className="inline-flex items-center gap-1 rounded-md border border-border px-2.5 py-1.5 text-xs font-medium text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
                          >
                            {"상세보기"}
                            <ChevronRight className="h-3 w-3" />
                          </Link>
                        </td>
                      </tr>
                    )
                  })
                ) : (
                  <tr>
                    <td colSpan={10} className="px-4 py-12 text-center text-muted-foreground">
                      {"검색 결과가 없습니다."}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="mt-4 flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              {"총 "}<span className="font-semibold text-foreground">{filteredStudents.length}</span>{"명"}
              {filteredStudents.length !== students.length && (
                <span className="text-muted-foreground">{" (전체 " + students.length + "명)"}</span>
              )}
            </p>
            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="sm"
                disabled={safePage <= 1}
                onClick={() => setCurrentPage(1)}
                className="h-8 w-8 p-0"
                aria-label="첫 페이지"
              >
                <ChevronLeft className="h-4 w-4" />
                <ChevronLeft className="h-4 w-4 -ml-2" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled={safePage <= 1}
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                className="h-8 w-8 p-0"
                aria-label="이전 페이지"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <Button
                  key={page}
                  variant={page === safePage ? "default" : "outline"}
                  size="sm"
                  onClick={() => setCurrentPage(page)}
                  className="h-8 w-8 p-0 text-xs"
                >
                  {page}
                </Button>
              ))}
              <Button
                variant="outline"
                size="sm"
                disabled={safePage >= totalPages}
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                className="h-8 w-8 p-0"
                aria-label="다음 페이지"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled={safePage >= totalPages}
                onClick={() => setCurrentPage(totalPages)}
                className="h-8 w-8 p-0"
                aria-label="마지막 페이지"
              >
                <ChevronRight className="h-4 w-4" />
                <ChevronRight className="h-4 w-4 -ml-2" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
