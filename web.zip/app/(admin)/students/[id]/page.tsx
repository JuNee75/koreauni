"use client"

import { use } from "react"
import Link from "next/link"
import { students, studentCareers } from "@/lib/student-data"
import { StudentBasicInfo } from "@/components/students/student-basic-info"
import { CareerSection } from "@/components/students/career-section"
import { ArrowLeft } from "lucide-react"
import { notFound } from "next/navigation"

interface StudentDetailPageProps {
  params: Promise<{ id: string }>
}

export default function StudentDetailPage({ params }: StudentDetailPageProps) {
  const { id } = use(params)

  const student = students.find((s) => s.id === id)
  if (!student) {
    notFound()
  }

  const career = studentCareers[id]

  return (
    <div className="flex flex-col gap-6 p-4 md:gap-8 md:p-8">
      {/* Back Navigation */}
      <div className="flex items-center gap-3">
        <Link
          href="/students"
          className="inline-flex items-center gap-1.5 rounded-md border border-border px-3 py-1.5 text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          {"학생 목록"}
        </Link>
        <span className="text-sm text-muted-foreground">{"/"}</span>
        <span className="text-sm font-semibold text-foreground">{student.name}</span>
      </div>

      {/* Basic Info */}
      <StudentBasicInfo student={student} />

      {/* Career Section */}
      <CareerSection career={career} />
    </div>
  )
}
