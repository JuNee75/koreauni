"use client"

import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { useState } from "react"
import { ChevronDown, User, LogOut, Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

const navItems = [
  {
    title: "역량 관리시스템 소개",
    items: [
      { title: "시스템 소개", href: "#" },
      { title: "이용 가이드", href: "#" },
    ],
  },
  {
    title: "역량 관리",
    items: [
      { title: "역량설문 참가", href: "#" },
      { title: "역량설문 결과", href: "#" },
    ],
  },
  {
    title: "정보마당",
    items: [
      { title: "공지사항", href: "/user/information/notice" },
      { title: "자료실", href: "/user/information/archive" },
    ],
  },
]

export default function UserLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const router = useRouter()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const isLoggedIn = pathname.startsWith("/user/mypage")

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-card">
        <div className="mx-auto flex h-[72px] max-w-7xl items-center justify-between px-4 md:px-8">
          {/* Logo */}
          <Link href="/user" className="flex items-center gap-3 shrink-0">
            <img
              src="/images/korea-univ-logo.png"
              alt="고려대학교 대학원"
              className="h-9 w-auto object-contain"
            />
            <div className="hidden sm:flex flex-col leading-tight">
              <span className="text-sm font-bold text-foreground">{"고려대학교 대학원"}</span>
              <span className="text-[11px] text-muted-foreground">{"Korea University Graduate School"}</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-10">
            {navItems.map((item) => (
              <DropdownMenu key={item.title}>
                <DropdownMenuTrigger className="flex items-center gap-1.5 text-base font-semibold text-foreground hover:text-primary transition-colors outline-none py-1">
                  {item.title}
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                </DropdownMenuTrigger>
                <DropdownMenuContent align="center" className="min-w-[180px]">
                  {item.items.map((sub) => (
                    <DropdownMenuItem key={sub.title} asChild className="text-sm py-2.5">
                      <Link href={sub.href}>{sub.title}</Link>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            ))}
          </nav>

          {/* Right side */}
          <div className="flex items-center gap-2">
            {isLoggedIn ? (
              <div className="hidden sm:flex items-center gap-2">
                <Link href="/user/mypage">
                  <Button variant="ghost" size="sm" className="gap-2 text-sm font-medium">
                    <User className="h-4 w-4" />
                    {"마이페이지"}
                  </Button>
                </Link>
                <Link href="/user">
                  <Button variant="ghost" size="sm" className="gap-2 text-sm font-medium text-muted-foreground">
                    <LogOut className="h-4 w-4" />
                    {"로그아웃"}
                  </Button>
                </Link>
              </div>
            ) : (
              <Link href="/user/mypage" className="hidden sm:block">
                <Button size="sm" className="rounded-full px-5 text-sm font-semibold gap-2">
                  <User className="h-4 w-4" />
                  {"마이페이지"}
                </Button>
              </Link>
            )}
            <Link href="/">
              <Button variant="outline" size="sm" className="text-xs font-medium">
                {"관리자모드"}
              </Button>
            </Link>
            {/* Mobile menu toggle */}
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden h-9 w-9"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Nav */}
        {mobileMenuOpen && (
          <div className="border-t border-border bg-card lg:hidden">
            <div className="mx-auto max-w-7xl px-4 py-4 space-y-3">
              {navItems.map((item) => (
                <div key={item.title}>
                  <p className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-2">{item.title}</p>
                  <div className="space-y-1 pl-2">
                    {item.items.map((sub) => (
                      <Link
                        key={sub.title}
                        href={sub.href}
                        className="block text-base text-foreground py-2"
                        onClick={() => setMobileMenuOpen(false)}
                      >
                        {sub.title}
                      </Link>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-1">{children}</main>

      {/* Footer */}
      <footer className="border-t border-border bg-muted/30">
        <div className="mx-auto max-w-7xl px-4 py-8 md:px-8">
          <div className="flex flex-col gap-6 md:flex-row md:items-start md:justify-between">
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <Link href="#" className="text-xs font-semibold text-foreground hover:underline">
                  {"개인정보처리방침"}
                </Link>
                <span className="text-xs text-muted-foreground">{"/"}</span>
                <Link href="#" className="text-xs font-bold text-foreground hover:underline">
                  {"이메일무단수집거부"}
                </Link>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed">
                {"서울캠퍼스 [02841] 서울특별시 성북구 안암로 145 | 세종캠퍼스 [30019] 세종특별자치시 세종로 2511"}
              </p>
              <p className="text-xs text-muted-foreground">
                {"대표전화 : 02-3290-5146  이메일 : graduate2@korea.ac.kr"}
              </p>
              <p className="text-xs text-muted-foreground">
                {"Copyright (C)2026 Korea University. All Rights Reserved"}
              </p>
            </div>
            <div className="shrink-0">
              <select className="rounded-md border border-border bg-card px-3 py-2 text-xs text-foreground">
                <option>{"관련사이트"}</option>
                <option>{"고려대학교"}</option>
                <option>{"고려대학교 대학원"}</option>
                <option>{"한국연구재단"}</option>
              </select>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
