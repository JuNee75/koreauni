'use client'

import { SurveyParticipation } from '@/components/competency/survey-participation'

export default function CompetencySurveyPage() {
  const competencies = [
    {
      id: 'learning-research',
      name: '학습연구역량',
      selected: false,
      participationPeriod: {
        startDate: '2024.01.01',
        endDate: '2024.03.31',
      },
      categories: [
        {
          id: 'learning-1',
          name: '학습동기 및 효능감',
          questions: [
            {
              id: 'q1',
              text: '나는 학습 목표를 달성하기 위해 적극적으로 노력한다.',
              options: [
                { value: '5', label: '매우 그렇다' },
                { value: '4', label: '그렇다' },
                { value: '3', label: '보통이다' },
                { value: '2', label: '그렇지 않다' },
                { value: '1', label: '매우 그렇지 않다' },
              ],
            },
            {
              id: 'q2',
              text: '나는 어려운 과제도 충분히 해낼 수 있다고 믿는다.',
              options: [
                { value: '5', label: '매우 그렇다' },
                { value: '4', label: '그렇다' },
                { value: '3', label: '보통이다' },
                { value: '2', label: '그렇지 않다' },
                { value: '1', label: '매우 그렇지 않다' },
              ],
            },
          ],
        },
        {
          id: 'learning-2',
          name: '학습전략 및 시간관리',
          questions: [
            {
              id: 'q3',
              text: '나는 효과적인 학습 방법을 활용하여 공부한다.',
              options: [
                { value: '5', label: '매우 그렇다' },
                { value: '4', label: '그렇다' },
                { value: '3', label: '보통이다' },
                { value: '2', label: '그렇지 않다' },
                { value: '1', label: '매우 그렇지 않다' },
              ],
            },
            {
              id: 'q4',
              text: '나는 시간을 효율적으로 관리하여 학습을 진행한다.',
              options: [
                { value: '5', label: '매우 그렇다' },
                { value: '4', label: '그렇다' },
                { value: '3', label: '보통이다' },
                { value: '2', label: '그렇지 않다' },
                { value: '1', label: '매우 그렇지 않다' },
              ],
            },
            {
              id: 'q5',
              text: '나는 학습 목표를 명확하게 설정하고 추진한다.',
              options: [
                { value: '5', label: '매우 그렇다' },
                { value: '4', label: '그렇다' },
                { value: '3', label: '보통이다' },
                { value: '2', label: '그렇지 않다' },
                { value: '1', label: '매우 그렇지 않다' },
              ],
            },
          ],
        },
      ],
    },
    {
      id: 'convergence-research',
      name: '융합연구역량',
      selected: false,
      participationPeriod: {
        startDate: '2024.01.15',
        endDate: '2024.04.15',
      },
      categories: [
        {
          id: 'convergence-1',
          name: '창의적 사고',
          questions: [
            {
              id: 'q6',
              text: '나는 새로운 아이디어를 자주 생각해낸다.',
              options: [
                { value: '5', label: '매우 그렇다' },
                { value: '4', label: '그렇다' },
                { value: '3', label: '보통이다' },
                { value: '2', label: '그렇지 않다' },
                { value: '1', label: '매우 그렇지 않다' },
              ],
            },
            {
              id: 'q7',
              text: '나는 기존의 틀을 벗어나 다양한 관점에서 문제를 해결한다.',
              options: [
                { value: '5', label: '매우 그렇다' },
                { value: '4', label: '그렇다' },
                { value: '3', label: '보통이다' },
                { value: '2', label: '그렇지 않다' },
                { value: '1', label: '매우 그렇지 않다' },
              ],
            },
          ],
        },
        {
          id: 'convergence-2',
          name: '협력 및 소통',
          questions: [
            {
              id: 'q8',
              text: '나는 팀 프로젝트에서 효과적으로 협력한다.',
              options: [
                { value: '5', label: '매우 그렇다' },
                { value: '4', label: '그렇다' },
                { value: '3', label: '보통이다' },
                { value: '2', label: '그렇지 않다' },
                { value: '1', label: '매우 그렇지 않다' },
              ],
            },
          ],
        },
      ],
    },
  ]

  const handleSurveySubmit = (responses: Record<string, string>) => {
    console.log('Survey submitted:', responses)
    alert('설문이 완료되었습니다. 감사합니다!')
    window.close()
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="mx-auto max-w-2xl px-4 py-8 md:px-8 md:py-10">
        <SurveyParticipation
          competencies={competencies}
          onSubmit={handleSurveySubmit}
        />
      </div>
    </div>
  )
}
