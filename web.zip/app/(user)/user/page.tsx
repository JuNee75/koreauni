"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import {
  User,
  Lock,
  ArrowRight,
  ClipboardList,
  BarChart3,
  ChevronRight,
  FileText,
} from "lucide-react"

/* ── Notice data (from admin) ── */
const notices = [
  { id: 1, title: "2026학년도 1학기 학사일정 안내", date: "2026.02.15", isPinned: true },
  { id: 2, title: "대학원 장학금 신청 안내", date: "2026.02.10", isPinned: true },
  { id: 3, title: "학위논문 심사 일정 공고", date: "2026.02.05", isPinned: false },
  { id: 4, title: "대학원 연구실 배정 결과 안내", date: "2026.01.28", isPinned: false },
  { id: 5, title: "2026년 국제학술대회 참가 지원 안내", date: "2026.01.20", isPinned: false },
]

/* ── Archive data (from admin) ── */
const archives = [
  { id: 1, title: "2026학년도 대학원 입학전형 요강", date: "2026.02.20" },
  { id: 2, title: "학위논문 작성 지침서", date: "2026.02.15" },
  { id: 3, title: "연구윤리 교육자료", date: "2026.02.10" },
  { id: 4, title: "장학금 신청서 양식", date: "2026.02.05" },
  { id: 5, title: "대학원 종합시험 과거문제", date: "2026.01.28" },
]

export default function UserMainPage() {
  const router = useRouter()
  const [userId, setUserId] = useState("")
  const [password, setPassword] = useState("")
  const [rememberMe, setRememberMe] = useState(false)

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    router.push("/user/mypage")
  }

  return (
    <div className="flex flex-col">
      {/* ─── Hero Section (login only) ─── */}
      <section className="relative min-h-[600px] md:min-h-[680px] flex items-center overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0">
          <img
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/main_visual-3qTAKGXsOyK445OFEoliKPWo9STB81.png"
            alt="고려대학교 캠퍼스"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-black/50" />
        </div>

        <div className="relative z-10 mx-auto flex w-full max-w-7xl flex-col gap-8 px-4 py-12 md:flex-row md:items-center md:justify-between md:px-8 md:py-0">
          {/* Left text */}
          <div className="flex flex-col gap-5">
            {/* School label */}
            <div className="flex items-center gap-2.5">
              <span className="h-px w-8 bg-white/50" />
              <span className="text-xs font-semibold uppercase tracking-[0.2em] text-white/70">
                {"Korea University Graduate School"}
              </span>
            </div>

            <h1 className="text-4xl font-bold text-white md:text-5xl lg:text-6xl text-balance leading-tight">
              {"대학원 통합"}
              <br />
              {"이력 관리 플랫폼"}
            </h1>

            {/* Decorative divider */}
            <div className="flex items-center gap-3">
              <span className="h-0.5 w-12 bg-primary" />
              <span className="h-0.5 w-4 bg-white/30" />
            </div>

            <p className="max-w-lg text-xl font-medium text-white/85 leading-relaxed tracking-wide">
              {"대학원생 역량진단 및 이력관리를 위한 통합 플랫폼입니다."}
            </p>
          </div>

          {/* Right login card */}
          <Card className="w-full max-w-[400px] border-0 shadow-2xl bg-card/95 backdrop-blur-sm shrink-0">
            <CardContent className="p-6 md:p-8">
              <h2 className="text-xl font-bold text-foreground mb-6">{"로그인"}</h2>
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="relative">
                  <User className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="아이디 입력"
                    value={userId}
                    onChange={(e) => setUserId(e.target.value)}
                    className="pl-10 h-11"
                  />
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    type="password"
                    placeholder="비밀번호 입력"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 h-11"
                  />
                </div>
                <Button type="submit" className="w-full h-12 text-base font-bold rounded-lg gap-2">
                  {"LOGIN"}
                  <ArrowRight className="h-4 w-4" />
                </Button>
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <Checkbox
                      checked={rememberMe}
                      onCheckedChange={(v) => setRememberMe(v === true)}
                    />
                    <span className="text-sm text-muted-foreground">{"ID 저장"}</span>
                  </label>
                  <div className="flex items-center gap-3">
                    <button type="button" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                      {"회원가입"}
                    </button>
                    <span className="text-sm text-muted-foreground">{"/"}</span>
                    <button type="button" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                      {"비밀번호 찾기"}
                    </button>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* ─── Competency Survey Banners ─── */}
      <section className="grid grid-cols-1 sm:grid-cols-2">
        {/* Survey Participation Banner */}
        <Link href="#" className="group relative block bg-[#8b1a2b] overflow-hidden">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;charset=utf-8,%3Csvg%20width%3D%2260%22%20height%3D%2260%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Ccircle%20cx%3D%2230%22%20cy%3D%2230%22%20r%3D%221.5%22%20fill%3D%22rgba(255%2C255%2C255%2C0.06)%22%2F%3E%3C%2Fsvg%3E')] opacity-50" />
          <div className="relative flex items-center justify-between px-6 py-8 md:px-12 md:py-10">
            <div className="flex items-center gap-5">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-white/15 backdrop-blur-sm">
                <ClipboardList className="h-7 w-7 text-white" />
              </div>
              <div className="flex flex-col gap-1.5">
                <h3 className="text-xl font-bold text-white">{"역량설문 참가"}</h3>
                <p className="text-base text-white/75 leading-relaxed">
                  {"역량 진단을 위한 설문에 참여해 주세요."}
                </p>
              </div>
            </div>
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white/20 transition-all group-hover:bg-white/30">
              <ArrowRight className="h-5 w-5 text-white transition-transform group-hover:translate-x-0.5" />
            </div>
          </div>
        </Link>

        {/* Survey Results Banner */}
        <Link href="#" className="group relative block bg-[#1a3a5c] overflow-hidden">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;charset=utf-8,%3Csvg%20width%3D%2260%22%20height%3D%2260%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Ccircle%20cx%3D%2230%22%20cy%3D%2230%22%20r%3D%221.5%22%20fill%3D%22rgba(255%2C255%2C255%2C0.06)%22%2F%3E%3C%2Fsvg%3E')] opacity-50" />
          <div className="relative flex items-center justify-between px-6 py-8 md:px-12 md:py-10">
            <div className="flex items-center gap-5">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-white/15 backdrop-blur-sm">
                <BarChart3 className="h-7 w-7 text-white" />
              </div>
              <div className="flex flex-col gap-1.5">
                <h3 className="text-xl font-bold text-white">{"역량설문 결과"}</h3>
                <p className="text-base text-white/75 leading-relaxed">
                  {"개인별 역량 진단 결과를 확인하세요."}
                </p>
              </div>
            </div>
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white/20 transition-all group-hover:bg-white/30">
              <ArrowRight className="h-5 w-5 text-white transition-transform group-hover:translate-x-0.5" />
            </div>
          </div>
        </Link>
      </section>

      {/* ─── Notice & Archive Section ─── */}
      <section className="mx-auto w-full max-w-7xl px-4 py-12 md:px-8 md:py-16">
        <div className="grid gap-8 md:gap-12 lg:grid-cols-2">
          {/* NOTICE */}
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-foreground tracking-tight">{"NOTICE"}</h2>
              <Link href="/user/information/notice" className="text-sm text-muted-foreground hover:text-foreground transition-colors flex items-center gap-0.5">
                {"더보기"}
                <ChevronRight className="h-4 w-4" />
              </Link>
            </div>
            <div className="divide-y divide-border">
              {notices.map((item) => (
                <Link
                  key={item.id}
                  href={`/user/information/notice/${item.id}`}
                  className="flex items-center justify-between py-4 group hover:bg-muted/30 -mx-2 px-2 rounded-md transition-colors"
                >
                  <span className="text-base text-foreground group-hover:text-primary transition-colors truncate pr-4">
                    {item.isPinned && (
                      <span className="inline-flex items-center rounded bg-primary/10 px-1.5 py-0.5 text-xs font-bold text-primary mr-2">
                        {"공지"}
                      </span>
                    )}
                    {item.title}
                  </span>
                  <span className="text-sm text-muted-foreground/50 shrink-0">{item.date}</span>
                </Link>
              ))}
            </div>
          </div>

          {/* ARCHIVE */}
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-foreground tracking-tight">{"자료실"}</h2>
              <Link href="/user/information/archive" className="text-sm text-muted-foreground hover:text-foreground transition-colors flex items-center gap-0.5">
                {"더보기"}
                <ChevronRight className="h-4 w-4" />
              </Link>
            </div>
            <div className="divide-y divide-border">
              {archives.map((item) => (
                <Link
                  key={item.id}
                  href={`/user/information/archive/${item.id}`}
                  className="flex items-center justify-between py-4 group hover:bg-muted/30 -mx-2 px-2 rounded-md transition-colors"
                >
                  <span className="flex items-center gap-2 text-base text-foreground group-hover:text-primary transition-colors truncate pr-4">
                    <FileText className="h-4 w-4 shrink-0 text-muted-foreground" />
                    {item.title}
                  </span>
                  <span className="text-sm text-muted-foreground/50 shrink-0">{item.date}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
