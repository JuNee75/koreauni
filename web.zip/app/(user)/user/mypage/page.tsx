"use client"

import { useState } from "react"
import { students, studentCareers } from "@/lib/student-data"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  User,
  Mail,
  Phone,
  GraduationCap,
  BookOpen,
  Calendar,
  FlaskConical,
  Award,
  Mic,
  Briefcase,
  FileText,
  ClipboardList,
  TrendingUp,
  Pencil,
  Check,
  X,
  Plus,
  Trash2,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import Link from "next/link"
import { StudentAIProfileAnalysis } from "@/components/competency/student-ai-profile-analysis"
import { StudentCompetencySummaryCard } from "@/components/competency/student-competency-summary-card"

/* ── Student: 김민준 (S001) ── */
const student = students.find((s) => s.id === "S001")!
const career = studentCareers["S001"]

const statusColors: Record<string, string> = {
  "재학": "bg-green-50 text-green-700 border-green-200",
  "휴학": "bg-amber-50 text-amber-700 border-amber-200",
  "수료": "bg-blue-50 text-blue-700 border-blue-200",
  "졸업": "bg-gray-100 text-gray-600 border-gray-200",
}

const programColors: Record<string, string> = {
  "석사": "bg-blue-50 text-blue-700 border-blue-200",
  "박사": "bg-indigo-50 text-indigo-700 border-indigo-200",
  "통합": "bg-gray-100 text-gray-600 border-gray-200",
}

/* ── Summary stats ── */
function getSummaryStats() {
  const totalCredits = career.courses.reduce((sum, c) => sum + c.credits, 0)
  const gradedCourses = career.courses.filter((c) => c.score > 0)
  const avgGpa = gradedCourses.length > 0
    ? (gradedCourses.reduce((sum, c) => sum + c.score, 0) / gradedCourses.length).toFixed(2)
    : "0"
  const paperCount = career.papers.length
  const presentationCount = career.presentations.filter((p) => p.type === "학술회의").length
  const awardCount = career.presentations.filter((p) => p.type === "수상경력").length
  const qualCount = career.qualifications.length

  return { totalCredits, avgGpa, paperCount, presentationCount, awardCount, qualCount }
}

/* ── Section edit toggle button ── */
function EditToggleButton({
  editing,
  onEdit,
  onSave,
  onCancel,
}: {
  editing: boolean
  onEdit: () => void
  onSave: () => void
  onCancel: () => void
}) {
  if (editing) {
    return (
      <div className="flex items-center gap-1.5">
        <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs" onClick={onCancel}>
          <X className="h-3.5 w-3.5" />
          {"취소"}
        </Button>
        <Button size="sm" className="h-8 gap-1.5 text-xs" onClick={onSave}>
          <Check className="h-3.5 w-3.5" />
          {"저장"}
        </Button>
      </div>
    )
  }
  return (
    <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs" onClick={onEdit}>
      <Pencil className="h-3.5 w-3.5" />
      {"수정"}
    </Button>
  )
}

/* ── Editable table cell ── */
function EditableCell({ value, editing, className = "" }: { value: string; editing: boolean; className?: string }) {
  const [val, setVal] = useState(value)
  if (editing) {
    return (
      <Input
        value={val}
        onChange={(e) => setVal(e.target.value)}
        className={`h-8 text-sm ${className}`}
      />
    )
  }
  return <span className={className}>{val}</span>
}

/* ── Add row button ── */
function AddRowButton({ onClick, label = "추가" }: { onClick: () => void; label?: string }) {
  return (
    <Button
      variant="outline"
      size="sm"
      className="h-8 gap-1.5 text-xs border-dashed border-primary/40 text-primary hover:bg-primary/5 hover:text-primary"
      onClick={onClick}
    >
      <Plus className="h-3.5 w-3.5" />
      {label}
    </Button>
  )
}

/* ── Delete row button (shown in edit mode) ── */
function DeleteRowButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex h-6 w-6 shrink-0 items-center justify-center rounded text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
      aria-label="삭제"
    >
      <Trash2 className="h-3.5 w-3.5" />
    </button>
  )
}

/* ── New editable row input ── */
function NewRowInput({ placeholder, className = "" }: { placeholder: string; className?: string }) {
  return (
    <Input
      placeholder={placeholder}
      className={`h-8 text-sm ${className}`}
    />
  )
}

/* ── Info item (view / edit) ── */
function InfoItem({
  icon: Icon,
  label,
  value,
  editing,
}: {
  icon: React.ElementType
  label: string
  value: string
  editing: boolean
}) {
  const [val, setVal] = useState(value)
  return (
    <div className="flex items-start gap-3">
      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-muted">
        <Icon className="h-4 w-4 text-muted-foreground" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm text-muted-foreground">{label}</p>
        {editing ? (
          <Input
            value={val}
            onChange={(e) => setVal(e.target.value)}
            className="h-8 mt-0.5 text-sm"
          />
        ) : (
          <p className="text-base font-medium text-foreground truncate">{val}</p>
        )}
      </div>
    </div>
  )
}

export default function MyPage() {
  const stats = getSummaryStats()
  const [showAIAnalysis, setShowAIAnalysis] = useState(false)

  const [editBasicInfo, setEditBasicInfo] = useState(false)
  const [editCourses, setEditCourses] = useState(false)
  const [editNonCurriculum, setEditNonCurriculum] = useState(false)
  const [editPapers, setEditPapers] = useState(false)
  const [editPresentations, setEditPresentations] = useState(false)
  const [editTrainings, setEditTrainings] = useState(false)
  const [editInternships, setEditInternships] = useState(false)
  const [editLectures, setEditLectures] = useState(false)
  const [editStartups, setEditStartups] = useState(false)
  const [editQualifications, setEditQualifications] = useState(false)

  /* ── New rows state (track added empty rows per section) ── */
  const [newCourses, setNewCourses] = useState<number[]>([])
  const [newNonCurriculum, setNewNonCurriculum] = useState<number[]>([])
  const [newPapers, setNewPapers] = useState<number[]>([])
  const [newPresentations, setNewPresentations] = useState<number[]>([])
  const [newTrainings, setNewTrainings] = useState<number[]>([])
  const [newInternships, setNewInternships] = useState<number[]>([])
  const [newLectures, setNewLectures] = useState<number[]>([])
  const [newStartups, setNewStartups] = useState<number[]>([])
  const [newQualifications, setNewQualifications] = useState<number[]>([])

  let nextId = 1000
  const getNextId = () => ++nextId

  const educationTabs = [
    { value: "courses", label: "교육", icon: BookOpen, color: "data-[state=active]:bg-blue-600 data-[state=active]:text-white" },
    { value: "research", label: "연구", icon: FlaskConical, color: "data-[state=active]:bg-emerald-600 data-[state=active]:text-white" },
    { value: "lecture", label: "강의", icon: Mic, color: "data-[state=active]:bg-amber-600 data-[state=active]:text-white" },
    { value: "startup", label: "창업", icon: Briefcase, color: "data-[state=active]:bg-rose-600 data-[state=active]:text-white" },
    { value: "qualification", label: "자격/수상", icon: Award, color: "data-[state=active]:bg-indigo-600 data-[state=active]:text-white" },
  ]

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 md:px-8 md:py-10 space-y-6">
      {/* Welcome Banner */}
      <div className="rounded-xl bg-gradient-to-r from-primary to-[#a52325] p-6 md:p-8">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-4">
            <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-white/20 backdrop-blur-sm">
              <User className="h-8 w-8 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-bold text-white">{student.name}</h1>
                <span className="rounded-full bg-white/20 px-3 py-0.5 text-xs font-semibold text-white">
                  {student.program}
                </span>
                <span className="rounded-full bg-white/20 px-3 py-0.5 text-xs font-semibold text-white">
                  {student.status}
                </span>
              </div>
              <p className="text-sm text-white/80 mt-1">
                {student.department + " | " + student.advisor + " | " + student.researchLab}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => window.open('/user/competency-survey', 'survey', 'width=900,height=1000,resizable=yes,scrollbars=yes')}
              className="rounded-lg bg-white/20 backdrop-blur-sm px-4 py-2 text-sm font-semibold text-white hover:bg-white/30 transition-colors flex items-center gap-2"
            >
              <ClipboardList className="h-4 w-4" />
              {"역량설문 참가"}
            </button>
            <Link
              href="/user/competency-result"
              className="rounded-lg bg-white/20 backdrop-blur-sm px-4 py-2 text-sm font-semibold text-white hover:bg-white/30 transition-colors flex items-center gap-2"
            >
              <TrendingUp className="h-4 w-4" />
              {"역량진단 결과"}
            </Link>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 grid-cols-2 md:grid-cols-3 lg:grid-cols-6">
        <Card>
          <CardContent className="flex flex-col items-center justify-center p-6 text-center gap-2">
            <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-blue-50">
              <BookOpen className="h-7 w-7 text-blue-600" />
            </div>
            <p className="text-sm text-muted-foreground">{"취득학점"}</p>
            <p className="text-2xl font-bold text-foreground">{stats.totalCredits}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex flex-col items-center justify-center p-6 text-center gap-2">
            <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-indigo-50">
              <GraduationCap className="h-7 w-7 text-indigo-600" />
            </div>
            <p className="text-sm text-muted-foreground">{"평균 GPA"}</p>
            <p className="text-2xl font-bold text-foreground">{stats.avgGpa}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex flex-col items-center justify-center p-6 text-center gap-2">
            <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-emerald-50">
              <FileText className="h-7 w-7 text-emerald-600" />
            </div>
            <p className="text-sm text-muted-foreground">{"논문"}</p>
            <p className="text-2xl font-bold text-foreground">{stats.paperCount + "편"}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex flex-col items-center justify-center p-6 text-center gap-2">
            <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-amber-50">
              <Mic className="h-7 w-7 text-amber-600" />
            </div>
            <p className="text-sm text-muted-foreground">{"학술발표"}</p>
            <p className="text-2xl font-bold text-foreground">{stats.presentationCount + "건"}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex flex-col items-center justify-center p-6 text-center gap-2">
            <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-rose-50">
              <Award className="h-7 w-7 text-rose-600" />
            </div>
            <p className="text-sm text-muted-foreground">{"수상"}</p>
            <p className="text-2xl font-bold text-foreground">{stats.awardCount + "건"}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex flex-col items-center justify-center p-6 text-center gap-2">
            <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-indigo-50">
              <Award className="h-7 w-7 text-indigo-600" />
            </div>
            <p className="text-sm text-muted-foreground">{"자격/어학"}</p>
            <p className="text-2xl font-bold text-foreground">{stats.qualCount + "건"}</p>
          </CardContent>
        </Card>
      </div>

      {/* AI 프로필 분석 (토글 가능) */}
      <Card className="border-blue-300 bg-blue-50/30">
        <CardHeader className="pb-3">
          <button
            onClick={() => setShowAIAnalysis(!showAIAnalysis)}
            className="w-full flex items-center justify-between hover:opacity-80 transition-opacity"
          >
            <div className="flex items-center gap-2">
              <span className="text-lg font-semibold text-foreground">AI 프로필 분석</span>
              <Badge className="bg-blue-100 text-blue-700">학생 맞춤형</Badge>
            </div>
            {showAIAnalysis ? (
              <ChevronUp className="h-5 w-5 text-gray-500" />
            ) : (
              <ChevronDown className="h-5 w-5 text-gray-500" />
            )}
          </button>
        </CardHeader>
        {showAIAnalysis && (
          <CardContent className="animate-in fade-in duration-300">
            <StudentAIProfileAnalysis
              studentName={student.name}
              department={student.department}
              program={student.program}
              academicStats={{
                avgGpa: stats.avgGpa,
                totalCredits: stats.totalCredits,
                paperCount: stats.paperCount,
                presentationCount: stats.presentationCount,
                awardCount: stats.awardCount,
              }}
              competencyScores={{
                learningResearch: 78,
                convergenceResearch: 65,
              }}
            />
          </CardContent>
        )}
      </Card>

      {/* 역량 진단 결과 요약 */}
      <StudentCompetencySummaryCard
        competencies={[
          { name: "학습연구역량", score: 78, level: "우수" },
          { name: "융합연구역량", score: 65, level: "개선필요" },
        ]}
        departmentAverage={[
          { name: "학습연구역량", score: 76 },
          { name: "융합연구역량", score: 72 },
        ]}
      />

      {/* ═══ Basic Info Card ═══ */}
      <Card>
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <CardTitle className="text-lg font-bold">{"기본정보"}</CardTitle>
              <div className="flex items-center gap-2">
                <span className={`rounded-full border px-3 py-1 text-xs font-semibold ${programColors[student.program]}`}>
                  {student.program}
                </span>
                <span className={`rounded-full border px-3 py-1 text-xs font-semibold ${statusColors[student.status]}`}>
                  {student.status}
                </span>
              </div>
            </div>
            <EditToggleButton
              editing={editBasicInfo}
              onEdit={() => setEditBasicInfo(true)}
              onSave={() => setEditBasicInfo(false)}
              onCancel={() => setEditBasicInfo(false)}
            />
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-x-8 gap-y-5 md:grid-cols-3 lg:grid-cols-4">
            <InfoItem icon={BookOpen} label="소속 학과" value={student.department} editing={editBasicInfo} />
            <InfoItem icon={GraduationCap} label="학위과정" value={student.program + "과정 " + student.grade + "학년 " + student.semester + "학기"} editing={editBasicInfo} />
            <InfoItem icon={User} label="지도교수" value={student.advisor} editing={editBasicInfo} />
            <InfoItem icon={FlaskConical} label="연구실" value={student.researchLab} editing={editBasicInfo} />
            <InfoItem icon={Calendar} label="입학일" value={student.enrollmentDate} editing={editBasicInfo} />
            <InfoItem icon={Mail} label="이메일" value={student.email} editing={editBasicInfo} />
            <InfoItem icon={Phone} label="연락처" value={student.phone} editing={editBasicInfo} />
            <InfoItem icon={Award} label="장학금" value={student.scholarshipType + " (" + student.supportYears + "년차)"} editing={editBasicInfo} />
          </div>
        </CardContent>
      </Card>

      {/* ═══ Career Tabs ═══ */}
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="text-lg font-bold">{"경력사항"}</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <Tabs defaultValue="courses">
            <TabsList className="mb-6 h-auto flex flex-wrap gap-1.5 bg-muted/50 p-1.5 rounded-lg w-full justify-start">
              {educationTabs.map((tab) => (
                <TabsTrigger
                  key={tab.value}
                  value={tab.value}
                  className={`flex items-center gap-2 rounded-md px-5 py-2.5 text-base font-semibold transition-all data-[state=active]:shadow-sm ${tab.color}`}
                >
                  <tab.icon className="h-5 w-5 shrink-0" />
                  {tab.label}
                </TabsTrigger>
              ))}
            </TabsList>

            {/* ── Education Tab ── */}
            <TabsContent value="courses">
              <div className="space-y-6">
                {/* 교과과정 */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-base font-bold text-foreground">{"교과과정 이수현황"}</h3>
                    <div className="flex items-center gap-2">
                      <AddRowButton onClick={() => { setNewCourses((p) => [...p, getNextId()]); setEditCourses(true) }} />
                    <EditToggleButton
                      editing={editCourses}
                      onEdit={() => setEditCourses(true)}
                      onSave={() => setEditCourses(false)}
                      onCancel={() => { setEditCourses(false); setNewCourses([]) }}
                    />
                    </div>
                  </div>
                  <div className="overflow-hidden rounded-lg border border-border">
                    <table className="w-full">
                      <thead className="bg-muted/50">
                        <tr className="border-b border-border">
                          <th className="px-4 py-3 text-left text-sm font-semibold">{"연도"}</th>
                          <th className="px-4 py-3 text-left text-sm font-semibold">{"학기"}</th>
                          <th className="px-4 py-3 text-left text-sm font-semibold">{"과목명"}</th>
                          <th className="px-4 py-3 text-left text-sm font-semibold">{"이수구분"}</th>
                          <th className="px-4 py-3 text-center text-sm font-semibold">{"학점"}</th>
                          <th className="px-4 py-3 text-center text-sm font-semibold">{"성적"}</th>
                          <th className="px-4 py-3 text-left text-sm font-semibold">{"담당교수"}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {career.courses.map((c, i) => (
                          <tr key={i} className="border-b border-border hover:bg-muted/30 transition-colors">
                            <td className="px-4 py-3 text-base"><EditableCell value={String(c.year)} editing={editCourses} /></td>
                            <td className="px-4 py-3 text-base"><EditableCell value={c.semester} editing={editCourses} /></td>
                            <td className="px-4 py-3 text-base font-medium"><EditableCell value={c.courseName} editing={editCourses} /></td>
                            <td className="px-4 py-3 text-base"><EditableCell value={c.courseType} editing={editCourses} /></td>
                            <td className="px-4 py-3 text-base text-center"><EditableCell value={String(c.credits)} editing={editCourses} /></td>
                            <td className="px-4 py-3 text-base text-center font-semibold"><EditableCell value={c.grade} editing={editCourses} /></td>
                            <td className="px-4 py-3 text-base text-muted-foreground"><EditableCell value={c.professor} editing={editCourses} /></td>
                          </tr>
                        ))}
                        {newCourses.map((id) => (
                          <tr key={`new-${id}`} className="border-b border-border bg-primary/[0.02]">
                            <td className="px-4 py-2.5"><NewRowInput placeholder="연도" /></td>
                            <td className="px-4 py-2.5"><NewRowInput placeholder="학기" /></td>
                            <td className="px-4 py-2.5"><NewRowInput placeholder="과목명" /></td>
                            <td className="px-4 py-2.5"><NewRowInput placeholder="이수구분" /></td>
                            <td className="px-4 py-2.5"><NewRowInput placeholder="학점" /></td>
                            <td className="px-4 py-2.5"><NewRowInput placeholder="성적" /></td>
                            <td className="px-4 py-2.5">
                              <div className="flex items-center gap-1">
                                <NewRowInput placeholder="담당교수" />
                                <DeleteRowButton onClick={() => setNewCourses((p) => p.filter((x) => x !== id))} />
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* 비교과 */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-base font-bold text-foreground">{"비교과 프로그램"}</h3>
                    <div className="flex items-center gap-2">
                      <AddRowButton onClick={() => { setNewNonCurriculum((p) => [...p, getNextId()]); setEditNonCurriculum(true) }} />
                    <EditToggleButton
                      editing={editNonCurriculum}
                      onEdit={() => setEditNonCurriculum(true)}
                      onSave={() => setEditNonCurriculum(false)}
                      onCancel={() => { setEditNonCurriculum(false); setNewNonCurriculum([]) }}
                    />
                    </div>
                  </div>
                  <div className="overflow-hidden rounded-lg border border-border">
                    <table className="w-full">
                      <thead className="bg-muted/50">
                        <tr className="border-b border-border">
                          <th className="px-4 py-3 text-left text-sm font-semibold">{"프로그램명"}</th>
                          <th className="px-4 py-3 text-left text-sm font-semibold">{"학기"}</th>
                          <th className="px-4 py-3 text-left text-sm font-semibold">{"기간"}</th>
                          <th className="px-4 py-3 text-left text-sm font-semibold">{"운영방식"}</th>
                          <th className="px-4 py-3 text-center text-sm font-semibold">{"시간"}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {career.nonCurriculum.map((nc) => (
                          <tr key={nc.id} className="border-b border-border hover:bg-muted/30 transition-colors">
                            <td className="px-4 py-3 text-base font-medium"><EditableCell value={nc.programName} editing={editNonCurriculum} /></td>
                            <td className="px-4 py-3 text-base"><EditableCell value={nc.year + " " + nc.semester} editing={editNonCurriculum} /></td>
                            <td className="px-4 py-3 text-base text-muted-foreground"><EditableCell value={nc.startDate + " ~ " + nc.endDate} editing={editNonCurriculum} /></td>
                            <td className="px-4 py-3 text-base"><EditableCell value={nc.operationMethod} editing={editNonCurriculum} /></td>
                            <td className="px-4 py-3 text-base text-center"><EditableCell value={nc.hours + "시간"} editing={editNonCurriculum} /></td>
                          </tr>
                        ))}
                        {newNonCurriculum.map((id) => (
                          <tr key={`new-${id}`} className="border-b border-border bg-primary/[0.02]">
                            <td className="px-4 py-2.5"><NewRowInput placeholder="프��그램명" /></td>
                            <td className="px-4 py-2.5"><NewRowInput placeholder="학기" /></td>
                            <td className="px-4 py-2.5"><NewRowInput placeholder="기간" /></td>
                            <td className="px-4 py-2.5"><NewRowInput placeholder="운영방식" /></td>
                            <td className="px-4 py-2.5">
                              <div className="flex items-center gap-1">
                                <NewRowInput placeholder="시간" />
                                <DeleteRowButton onClick={() => setNewNonCurriculum((p) => p.filter((x) => x !== id))} />
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* ── Research Tab ── */}
            <TabsContent value="research">
              <div className="space-y-6">
                {/* 논문 */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-base font-bold text-foreground">{"논문 실적"}</h3>
                    <div className="flex items-center gap-2">
                      <AddRowButton onClick={() => { setNewPapers((p) => [...p, getNextId()]); setEditPapers(true) }} />
                    <EditToggleButton
                      editing={editPapers}
                      onEdit={() => setEditPapers(true)}
                      onSave={() => setEditPapers(false)}
                      onCancel={() => { setEditPapers(false); setNewPapers([]) }}
                    />
                    </div>
                  </div>
                  <div className="space-y-3">
                    {career.papers.map((p) => (
                      <div key={p.id} className={`rounded-lg border p-4 transition-colors ${editPapers ? "border-primary/30 bg-primary/[0.02]" : "border-border hover:bg-muted/30"}`}>
                        <div className="flex items-start justify-between gap-4">
                          <div className="min-w-0 flex-1 space-y-1.5">
                            {editPapers ? (
                              <>
                                <Input defaultValue={p.title} className="h-8 text-sm font-semibold" />
                                <Input defaultValue={p.journal + " | " + p.publishDate} className="h-8 text-sm" />
                                <Input defaultValue={p.authors} className="h-8 text-sm" />
                              </>
                            ) : (
                              <>
                                <p className="text-base font-semibold text-foreground">{p.title}</p>
                                <p className="text-sm text-muted-foreground">{p.journal + " | " + p.publishDate}</p>
                                <p className="text-sm text-muted-foreground">{p.authors}</p>
                              </>
                            )}
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            {p.isci && <Badge variant="outline" className="text-[10px] border-blue-300 text-blue-700 bg-blue-50">{"SCI"}</Badge>}
                            {p.isKci && <Badge variant="outline" className="text-[10px] border-emerald-300 text-emerald-700 bg-emerald-50">{"KCI"}</Badge>}
                            {p.isFirstAuthor && <Badge variant="outline" className="text-[10px]">{"1저자"}</Badge>}
                          </div>
                        </div>
                      </div>
                    ))}
                    {newPapers.map((id) => (
                      <div key={`new-${id}`} className="rounded-lg border border-primary/30 bg-primary/[0.02] p-4">
                        <div className="flex items-start justify-between gap-4">
                          <div className="min-w-0 flex-1 space-y-1.5">
                            <Input placeholder="논문 제목" className="h-8 text-sm font-semibold" />
                            <Input placeholder="저널명 | 발행일" className="h-8 text-sm" />
                            <Input placeholder="저자" className="h-8 text-sm" />
                          </div>
                          <DeleteRowButton onClick={() => setNewPapers((p) => p.filter((x) => x !== id))} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 학술발표 */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-base font-bold text-foreground">{"학술발표 및 수상"}</h3>
                    <div className="flex items-center gap-2">
                      <AddRowButton onClick={() => { setNewPresentations((p) => [...p, getNextId()]); setEditPresentations(true) }} />
                    <EditToggleButton
                      editing={editPresentations}
                      onEdit={() => setEditPresentations(true)}
                      onSave={() => setEditPresentations(false)}
                      onCancel={() => { setEditPresentations(false); setNewPresentations([]) }}
                    />
                    </div>
                  </div>
                  <div className="space-y-3">
                    {career.presentations.map((p) => (
                      <div key={p.id} className={`rounded-lg border p-4 transition-colors ${editPresentations ? "border-primary/30 bg-primary/[0.02]" : "border-border hover:bg-muted/30"}`}>
                        <div className="flex items-start justify-between gap-4">
                          <div className="min-w-0 flex-1 space-y-1.5">
                            {editPresentations ? (
                              <>
                                <Input defaultValue={p.title} className="h-8 text-sm font-semibold" />
                                <Input defaultValue={p.conference + " | " + p.date + " | " + p.location} className="h-8 text-sm" />
                                {p.awardInfo && <Input defaultValue={p.awardInfo} className="h-8 text-sm" />}
                              </>
                            ) : (
                              <>
                                <p className="text-base font-semibold text-foreground">{p.title}</p>
                                <p className="text-sm text-muted-foreground">{p.conference + " | " + p.date + " | " + p.location}</p>
                                {p.awardInfo && <p className="text-sm text-primary font-medium">{p.awardInfo}</p>}
                              </>
                            )}
                          </div>
                          <Badge variant="outline" className="text-[10px] shrink-0">{p.type}</Badge>
                        </div>
                      </div>
                    ))}
                    {newPresentations.map((id) => (
                      <div key={`new-${id}`} className="rounded-lg border border-primary/30 bg-primary/[0.02] p-4">
                        <div className="flex items-start justify-between gap-4">
                          <div className="min-w-0 flex-1 space-y-1.5">
                            <Input placeholder="발표/수상 제목" className="h-8 text-sm font-semibold" />
                            <Input placeholder="학회명 | 일자 | 장소" className="h-8 text-sm" />
                            <Input placeholder="수상 정보 (선택)" className="h-8 text-sm" />
                          </div>
                          <DeleteRowButton onClick={() => setNewPresentations((p) => p.filter((x) => x !== id))} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 연수 */}
                {career.trainings.length > 0 && (
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-base font-bold text-foreground">{"연수 이력"}</h3>
                      <div className="flex items-center gap-2">
                        <AddRowButton onClick={() => { setNewTrainings((p) => [...p, getNextId()]); setEditTrainings(true) }} />
                      <EditToggleButton
                        editing={editTrainings}
                        onEdit={() => setEditTrainings(true)}
                        onSave={() => setEditTrainings(false)}
                        onCancel={() => { setEditTrainings(false); setNewTrainings([]) }}
                      />
                      </div>
                    </div>
                    <div className="overflow-hidden rounded-lg border border-border">
                      <table className="w-full">
                        <thead className="bg-muted/50">
                          <tr className="border-b border-border">
                            <th className="px-4 py-3 text-left text-sm font-semibold">{"프로그램명"}</th>
                            <th className="px-4 py-3 text-left text-sm font-semibold">{"기관"}</th>
                            <th className="px-4 py-3 text-left text-sm font-semibold">{"기간"}</th>
                            <th className="px-4 py-3 text-left text-sm font-semibold">{"국가"}</th>
                          </tr>
                        </thead>
                        <tbody>
                          {career.trainings.map((t) => (
                            <tr key={t.id} className="border-b border-border hover:bg-muted/30 transition-colors">
                              <td className="px-4 py-3 text-base font-medium"><EditableCell value={t.programName} editing={editTrainings} /></td>
                              <td className="px-4 py-3 text-base text-muted-foreground"><EditableCell value={t.institution} editing={editTrainings} /></td>
                              <td className="px-4 py-3 text-base text-muted-foreground"><EditableCell value={t.startDate + " ~ " + t.endDate} editing={editTrainings} /></td>
                              <td className="px-4 py-3 text-base"><EditableCell value={t.country} editing={editTrainings} /></td>
                            </tr>
                          ))}
                          {newTrainings.map((id) => (
                            <tr key={`new-${id}`} className="border-b border-border bg-primary/[0.02]">
                              <td className="px-4 py-2.5"><NewRowInput placeholder="프로그램명" /></td>
                              <td className="px-4 py-2.5"><NewRowInput placeholder="기관" /></td>
                              <td className="px-4 py-2.5"><NewRowInput placeholder="기간" /></td>
                              <td className="px-4 py-2.5">
                                <div className="flex items-center gap-1">
                                  <NewRowInput placeholder="국가" />
                                  <DeleteRowButton onClick={() => setNewTrainings((p) => p.filter((x) => x !== id))} />
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* 인턴십 */}
                {career.internships.length > 0 && (
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-base font-bold text-foreground">{"인턴십"}</h3>
                      <div className="flex items-center gap-2">
                        <AddRowButton onClick={() => { setNewInternships((p) => [...p, getNextId()]); setEditInternships(true) }} />
                      <EditToggleButton
                        editing={editInternships}
                        onEdit={() => setEditInternships(true)}
                        onSave={() => setEditInternships(false)}
                        onCancel={() => { setEditInternships(false); setNewInternships([]) }}
                      />
                      </div>
                    </div>
                    <div className="overflow-hidden rounded-lg border border-border">
                      <table className="w-full">
                        <thead className="bg-muted/50">
                          <tr className="border-b border-border">
                            <th className="px-4 py-3 text-left text-sm font-semibold">{"프로그램명"}</th>
                            <th className="px-4 py-3 text-left text-sm font-semibold">{"기관"}</th>
                            <th className="px-4 py-3 text-left text-sm font-semibold">{"기간"}</th>
                            <th className="px-4 py-3 text-left text-sm font-semibold">{"국가"}</th>
                          </tr>
                        </thead>
                        <tbody>
                          {career.internships.map((item) => (
                            <tr key={item.id} className="border-b border-border hover:bg-muted/30 transition-colors">
                              <td className="px-4 py-3 text-base font-medium"><EditableCell value={item.programName} editing={editInternships} /></td>
                              <td className="px-4 py-3 text-base text-muted-foreground"><EditableCell value={item.institution} editing={editInternships} /></td>
                              <td className="px-4 py-3 text-base text-muted-foreground"><EditableCell value={item.startDate + " ~ " + item.endDate} editing={editInternships} /></td>
                              <td className="px-4 py-3 text-base"><EditableCell value={item.country} editing={editInternships} /></td>
                            </tr>
                          ))}
                          {newInternships.map((id) => (
                            <tr key={`new-${id}`} className="border-b border-border bg-primary/[0.02]">
                              <td className="px-4 py-2.5"><NewRowInput placeholder="프로그램명" /></td>
                              <td className="px-4 py-2.5"><NewRowInput placeholder="기관" /></td>
                              <td className="px-4 py-2.5"><NewRowInput placeholder="기간" /></td>
                              <td className="px-4 py-2.5">
                                <div className="flex items-center gap-1">
                                  <NewRowInput placeholder="국가" />
                                  <DeleteRowButton onClick={() => setNewInternships((p) => p.filter((x) => x !== id))} />
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            </TabsContent>

            {/* ── Lecture Tab ── */}
            <TabsContent value="lecture">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-base font-bold text-foreground">{"강의 이력"}</h3>
                <div className="flex items-center gap-2">
                  <AddRowButton onClick={() => { setNewLectures((p) => [...p, getNextId()]); setEditLectures(true) }} />
                <EditToggleButton
                  editing={editLectures}
                  onEdit={() => setEditLectures(true)}
                  onSave={() => setEditLectures(false)}
                  onCancel={() => { setEditLectures(false); setNewLectures([]) }}
                />
                </div>
              </div>
              <div className="overflow-hidden rounded-lg border border-border">
                <table className="w-full">
                  <thead className="bg-muted/50">
                    <tr className="border-b border-border">
                      <th className="px-4 py-3 text-left text-sm font-semibold">{"유형"}</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold">{"과목명"}</th>
                      <th className="px-4 py-3 text-center text-sm font-semibold">{"학점"}</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold">{"학기"}</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold">{"시간"}</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold">{"장소"}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {career.lectures.map((l) => (
                      <tr key={l.id} className="border-b border-border hover:bg-muted/30 transition-colors">
                        <td className="px-4 py-3 text-base"><EditableCell value={l.type} editing={editLectures} /></td>
                        <td className="px-4 py-3 text-base font-medium"><EditableCell value={l.courseName} editing={editLectures} /></td>
                        <td className="px-4 py-3 text-base text-center"><EditableCell value={String(l.credits)} editing={editLectures} /></td>
                        <td className="px-4 py-3 text-base"><EditableCell value={l.semester} editing={editLectures} /></td>
                        <td className="px-4 py-3 text-base text-muted-foreground"><EditableCell value={l.dayOfWeek + " " + l.startTime + "~" + l.endTime} editing={editLectures} /></td>
                        <td className="px-4 py-3 text-base text-muted-foreground"><EditableCell value={l.location} editing={editLectures} /></td>
                      </tr>
                    ))}
                    {newLectures.map((id) => (
                      <tr key={`new-${id}`} className="border-b border-border bg-primary/[0.02]">
                        <td className="px-4 py-2.5"><NewRowInput placeholder="유형" /></td>
                        <td className="px-4 py-2.5"><NewRowInput placeholder="과목명" /></td>
                        <td className="px-4 py-2.5"><NewRowInput placeholder="학점" /></td>
                        <td className="px-4 py-2.5"><NewRowInput placeholder="학기" /></td>
                        <td className="px-4 py-2.5"><NewRowInput placeholder="시간" /></td>
                        <td className="px-4 py-2.5">
                          <div className="flex items-center gap-1">
                            <NewRowInput placeholder="장소" />
                            <DeleteRowButton onClick={() => setNewLectures((p) => p.filter((x) => x !== id))} />
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>

            {/* ── Startup Tab ── */}
            <TabsContent value="startup">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-base font-bold text-foreground">{"창업 현황"}</h3>
                <div className="flex items-center gap-2">
                  <AddRowButton onClick={() => { setNewStartups((p) => [...p, getNextId()]); setEditStartups(true) }} />
                <EditToggleButton
                  editing={editStartups}
                  onEdit={() => setEditStartups(true)}
                  onSave={() => setEditStartups(false)}
                  onCancel={() => { setEditStartups(false); setNewStartups([]) }}
                />
                </div>
              </div>
              {career.startups.length > 0 ? (
                <div className="space-y-3">
                  {career.startups.map((s) => (
                    <Card key={s.id} className={editStartups ? "border-primary/30 bg-primary/[0.02]" : ""}>
                      <CardContent className="p-5">
                        <div className="flex items-center gap-3 mb-4">
                          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                            <Briefcase className="h-5 w-5 text-primary" />
                          </div>
                          <div className="min-w-0 flex-1">
                            {editStartups ? (
                              <>
                                <Input defaultValue={s.companyName} className="h-8 text-base font-bold mb-1" />
                                <Input defaultValue={s.registrationNumber} className="h-8 text-sm" />
                              </>
                            ) : (
                              <>
                                <p className="text-base font-bold text-foreground">{s.companyName}</p>
                                <p className="text-sm text-muted-foreground">{s.registrationNumber}</p>
                              </>
                            )}
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
                          {[
                            { label: "대표", value: s.ceo },
                            { label: "설립일", value: s.establishDate },
                            { label: "업종", value: s.businessCategory },
                            { label: "직원 수", value: s.employees + "명" },
                            { label: "연매출", value: (s.annualRevenue / 10000).toLocaleString() + "만원" },
                            { label: "소재지", value: s.address },
                          ].map((item) => (
                            <div key={item.label}>
                              <p className="text-sm text-muted-foreground">{item.label}</p>
                              {editStartups ? (
                                <Input defaultValue={item.value} className="h-8 text-base mt-0.5" />
                              ) : (
                                <p className="text-base font-medium">{item.value}</p>
                              )}
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  {newStartups.map((id) => (
                    <Card key={`new-${id}`} className="border-primary/30 bg-primary/[0.02]">
                      <CardContent className="p-5">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-3 flex-1">
                            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                              <Briefcase className="h-5 w-5 text-primary" />
                            </div>
                            <div className="flex-1 space-y-1">
                              <Input placeholder="회사명" className="h-8 text-base font-bold" />
                              <Input placeholder="사업자등록번호" className="h-8 text-sm" />
                            </div>
                          </div>
                          <DeleteRowButton onClick={() => setNewStartups((p) => p.filter((x) => x !== id))} />
                        </div>
                        <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
                          {["대표", "설립일", "업종", "직원 수", "연매출", "소재지"].map((label) => (
                            <div key={label}>
                              <p className="text-sm text-muted-foreground">{label}</p>
                              <Input placeholder={label} className="h-8 text-base mt-0.5" />
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : newStartups.length > 0 ? (
                <div className="space-y-3">
                  {newStartups.map((id) => (
                    <Card key={`new-${id}`} className="border-primary/30 bg-primary/[0.02]">
                      <CardContent className="p-5">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-3 flex-1">
                            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                              <Briefcase className="h-5 w-5 text-primary" />
                            </div>
                            <div className="flex-1 space-y-1">
                              <Input placeholder="회사명" className="h-8 text-base font-bold" />
                              <Input placeholder="사업자등록번호" className="h-8 text-sm" />
                            </div>
                          </div>
                          <DeleteRowButton onClick={() => setNewStartups((p) => p.filter((x) => x !== id))} />
                        </div>
                        <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
                          {["대표", "설립일", "업종", "직원 수", "연매출", "소재지"].map((label) => (
                            <div key={label}>
                              <p className="text-sm text-muted-foreground">{label}</p>
                              <Input placeholder={label} className="h-8 text-base mt-0.5" />
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <p className="text-base text-muted-foreground py-8 text-center">{"등록된 창업 정보가 없습니다."}</p>
              )}
            </TabsContent>

            {/* ── Qualification Tab ── */}
            <TabsContent value="qualification">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-base font-bold text-foreground">{"자격/수상/어학"}</h3>
                <div className="flex items-center gap-2">
                  <AddRowButton onClick={() => { setNewQualifications((p) => [...p, getNextId()]); setEditQualifications(true) }} />
                <EditToggleButton
                  editing={editQualifications}
                  onEdit={() => setEditQualifications(true)}
                  onSave={() => setEditQualifications(false)}
                  onCancel={() => { setEditQualifications(false); setNewQualifications([]) }}
                />
                </div>
              </div>
              <div className="overflow-hidden rounded-lg border border-border">
                <table className="w-full">
                  <thead className="bg-muted/50">
                    <tr className="border-b border-border">
                      <th className="px-4 py-3 text-left text-sm font-semibold">{"구분"}</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold">{"명칭"}</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold">{"발급기관"}</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold">{"취득일"}</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold">{"비고"}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {career.qualifications.map((q) => (
                      <tr key={q.id} className="border-b border-border hover:bg-muted/30 transition-colors">
                        <td className="px-4 py-3 text-base"><EditableCell value={q.type} editing={editQualifications} /></td>
                        <td className="px-4 py-3 text-base font-medium"><EditableCell value={q.name} editing={editQualifications} /></td>
                        <td className="px-4 py-3 text-base text-muted-foreground"><EditableCell value={q.issuer} editing={editQualifications} /></td>
                        <td className="px-4 py-3 text-base text-muted-foreground"><EditableCell value={q.acquiredDate} editing={editQualifications} /></td>
                        <td className="px-4 py-3 text-base text-muted-foreground">
                          <EditableCell value={q.totalScore ? q.totalScore + "점" : q.awardGrade || q.certificateNumber || "-"} editing={editQualifications} />
                        </td>
                      </tr>
                    ))}
                    {newQualifications.map((id) => (
                      <tr key={`new-${id}`} className="border-b border-border bg-primary/[0.02]">
                        <td className="px-4 py-2.5"><NewRowInput placeholder="구분" /></td>
                        <td className="px-4 py-2.5"><NewRowInput placeholder="명칭" /></td>
                        <td className="px-4 py-2.5"><NewRowInput placeholder="발급기관" /></td>
                        <td className="px-4 py-2.5"><NewRowInput placeholder="취득일" /></td>
                        <td className="px-4 py-2.5">
                          <div className="flex items-center gap-1">
                            <NewRowInput placeholder="비고" />
                            <DeleteRowButton onClick={() => setNewQualifications((p) => p.filter((x) => x !== id))} />
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>


    </div>
  )
}
