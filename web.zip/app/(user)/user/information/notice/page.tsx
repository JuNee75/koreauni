"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, Eye, ChevronLeft, ChevronRight, Pin } from "lucide-react"
import Link from "next/link"

interface Notice {
  id: number
  title: string
  author: string
  date: string
  views: number
  isPinned: boolean
}

const mockNotices: Notice[] = [
  {
    id: 1,
    title: "2026학년도 1학기 학사일정 안내",
    author: "관리자",
    date: "2026-02-15",
    views: 1245,
    isPinned: true,
  },
  {
    id: 2,
    title: "대학원 장학금 신청 안내",
    author: "관리자",
    date: "2026-02-10",
    views: 892,
    isPinned: true,
  },
  {
    id: 3,
    title: "학위논문 심사 일정 공고",
    author: "교학팀",
    date: "2026-02-05",
    views: 567,
    isPinned: false,
  },
  {
    id: 4,
    title: "대학원 연구실 배정 결과 안내",
    author: "관리자",
    date: "2026-01-28",
    views: 423,
    isPinned: false,
  },
  {
    id: 5,
    title: "2026년 국제학술대회 참가 지원 안내",
    author: "교학팀",
    date: "2026-01-20",
    views: 356,
    isPinned: false,
  },
  {
    id: 6,
    title: "대학원생 연구윤리교육 이수 안내",
    author: "관리자",
    date: "2026-01-15",
    views: 289,
    isPinned: false,
  },
  {
    id: 7,
    title: "학생증 재발급 신청 안내",
    author: "행정팀",
    date: "2026-01-10",
    views: 234,
    isPinned: false,
  },
  {
    id: 8,
    title: "도서관 이용시간 변경 안내",
    author: "도서관",
    date: "2026-01-05",
    views: 198,
    isPinned: false,
  },
  { id: 9, title: "2026학년도 수강신청 안내", author: "교학팀", date: "2025-12-28", views: 456, isPinned: false },
  { id: 10, title: "대학원 세미나실 예약 안내", author: "행정팀", date: "2025-12-20", views: 312, isPinned: false },
  { id: 11, title: "학위수여식 일정 공지", author: "관리자", date: "2025-12-15", views: 789, isPinned: false },
  { id: 12, title: "연구비 집행 지침 안내", author: "행정팀", date: "2025-12-10", views: 267, isPinned: false },
  { id: 13, title: "대학원생 건강검진 안내", author: "보건센터", date: "2025-12-05", views: 523, isPinned: false },
  { id: 14, title: "학기 중 연구활동 지원 프로그램", author: "교학팀", date: "2025-11-28", views: 445, isPinned: false },
  { id: 15, title: "대학원 오리엔테이션 안내", author: "관리자", date: "2025-11-20", views: 678, isPinned: false },
]

export default function NoticeListPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 10

  const filteredNotices = mockNotices.filter((notice) =>
    notice.title.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const totalPages = Math.ceil(filteredNotices.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const endIndex = startIndex + itemsPerPage
  const paginatedNotices = filteredNotices.slice(startIndex, endIndex)

  const pinned = paginatedNotices.filter((n) => n.isPinned)
  const unpinned = paginatedNotices.filter((n) => !n.isPinned)

  const handlePageChange = (page: number) => {
    setCurrentPage(page)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const handleReset = () => {
    setSearchTerm("")
    setCurrentPage(1)
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="mx-auto max-w-5xl px-4 md:px-8 space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900">공지사항</h1>
          <p className="text-gray-600 mt-2">대학원의 최신 소식과 공지사항을 확인하세요.</p>
        </div>

        {/* Search */}
        <div>
          <div className="pt-6">
            <div className="flex gap-2">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="공지사항 검색..."
                  value={searchTerm}
                  onChange={(e) => {
                    setSearchTerm(e.target.value)
                    setCurrentPage(1)
                  }}
                  className="pl-10"
                />
              </div>
              <Button variant="outline" onClick={handleReset} disabled={!searchTerm}>
                초기화
              </Button>
            </div>
          </div>
        </div>

        {/* Notices Table */}
        <Card>
          <CardContent className="pt-6">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 font-semibold text-gray-700 text-sm">제목</th>
                    <th className="hidden md:table-cell text-right py-3 px-4 font-semibold text-gray-700 text-sm whitespace-nowrap w-32">작성일</th>
                  </tr>
                </thead>
                <tbody>
                  {/* Pinned notices */}
                  {pinned.map((notice) => (
                    <tr
                      key={notice.id}
                      className="border-b border-gray-100 hover:bg-blue-50 transition-colors"
                    >
                      <td className="py-3 px-4">
                        <Link href={`/user/information/notice/${notice.id}`}>
                          <div className="flex items-center gap-2 hover:text-blue-600 transition-colors">
                            <Pin className="h-4 w-4 text-red-500 flex-shrink-0" />
                            <span className="font-medium text-gray-900 hover:underline">{notice.title}</span>
                          </div>
                        </Link>
                      </td>
                      <td className="hidden md:table-cell py-3 px-4 text-right text-sm text-gray-600 whitespace-nowrap">{notice.date}</td>
                    </tr>
                  ))}

                  {/* Normal notices */}
                  {unpinned.map((notice) => (
                    <tr
                      key={notice.id}
                      className="border-b border-gray-100 hover:bg-gray-50 transition-colors"
                    >
                      <td className="py-3 px-4">
                        <Link href={`/user/information/notice/${notice.id}`}>
                          <span className="font-medium text-gray-900 hover:text-blue-600 hover:underline transition-colors">
                            {notice.title}
                          </span>
                        </Link>
                      </td>
                      <td className="hidden md:table-cell py-3 px-4 text-right text-sm text-gray-600 whitespace-nowrap">{notice.date}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {filteredNotices.length === 0 && (
              <div className="text-center py-10">
                <p className="text-gray-500">검색 결과가 없습니다.</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={currentPage === 1}
              onClick={() => handlePageChange(currentPage - 1)}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>

            {Array.from({ length: totalPages }).map((_, index) => (
              <Button
                key={index + 1}
                variant={currentPage === index + 1 ? "default" : "outline"}
                size="sm"
                onClick={() => handlePageChange(index + 1)}
              >
                {index + 1}
              </Button>
            ))}

            <Button
              variant="outline"
              size="sm"
              disabled={currentPage === totalPages}
              onClick={() => handlePageChange(currentPage + 1)}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
