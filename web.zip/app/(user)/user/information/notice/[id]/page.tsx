import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Eye } from "lucide-react"
import Link from "next/link"
import NoticeDetail from "./detail"

interface Notice {
  id: number
  title: string
  author: string
  date: string
  views: number
  content: string
}

const mockNotices: Record<number, Notice> = {
  1: {
    id: 1,
    title: "2026학년도 1학기 학사일정 안내",
    author: "관리자",
    date: "2026-02-15",
    views: 1245,
    content: `안녕하세요. 고려대학교 대학원입니다.

2026학년도 1학기 학사일정을 안내드립니다.

■ 주요 학사일정

1. 수강신청 기간: 2026.02.20(금) ~ 2026.02.22(일)
   - 신입생 수강신청: 2026.02.20(금) 10:00
   - 재학생 수강신청: 2026.02.21(토) ~ 2026.02.22(일)

2. 개강: 2026.03.02(월)

3. 수강정정 기간: 2026.03.02(월) ~ 2026.03.06(금)

4. 학사일정
   - 중간고사: 2026.04.13(월) ~ 2026.04.24(금)
   - 기말고사: 2026.06.08(월) ~ 2026.06.19(금)
   - 성적공시: 2026.06.29(월)

5. 학위논문 제출
   - 수정본 제출: 2026.05.01(금) ~ 2026.05.15(금)
   - 최종본 제출: 2026.06.08(월) ~ 2026.06.15(월)

■ 주의사항

- 수강신청 시 학년별 지정학점을 반드시 확인하시기 바랍니다.
- 수강정정 기간 이후의 변경은 불가합니다.
- 학위논문 제출 기한을 반드시 지켜주시기 바랍니다.

이 외에 궁금한 사항이 있으시면 대학원 행정팀(02-3277-3123)으로 문의해 주시기 바랍니다.

감사합니다.`,
  },
  2: {
    id: 2,
    title: "대학원 장학금 신청 안내",
    author: "관리자",
    date: "2026-02-10",
    views: 892,
    content: `안녕하세요. 고려대학교 대학원입니다.

2026학년도 대학원 장학금 신청 안내를 드립니다.

■ 장학금 종류 및 규모

1. 성적우수장학금: 연 100만원 (5명)
2. 연구장학금: 연 80만원 (10명)
3. 저소득층장학금: 연 60만원 (8명)
4. 학위논문완성장학금: 연 50만원 (15명)

■ 신청 자격

- 전체 대학원생 (신입생, 휴학생 제외)
- 지난 학기 평점 3.5 이상

■ 신청 기간: 2026.02.20(금) ~ 2026.03.05(목)

■ 신청 방법

1. 대학원 홈페이지 > 학생지원 > 장학금 신청
2. 필요서류:
   - 장학금 신청서 (양식 다운로드)
   - 성적증명서
   - 재학증명서
   - 소득증명서 (저소득층 장학금 신청자만 해당)

■ 선발기준

- 성적우수장학금: 평점 순
- 연구장학금: 연구성과 및 실적
- 저소득층장학금: 소득 수준 및 학업성적
- 학위논문완성장학금: 논문 심사 진행 상황

■ 결과 안내: 2026.03.20(금)

자세한 내용은 대학원 행정팀으로 문의해 주시기 바랍니다.`,
  },
  3: {
    id: 3,
    title: "학위논문 심사 일정 공고",
    author: "교학팀",
    date: "2026-02-05",
    views: 567,
    content: `안녕하세요. 고려대학교 대학원 교학팀입니다.

2026학년도 1학기 학위논문 심사 일정을 공고합니다.

■ 논문 심사 추진 일정

1. 예비심사 신청기간: 2026.02.20(금) ~ 2026.03.05(목)
2. 예비심사 진행기간: 2026.03.10(월) ~ 2026.04.10(금)
3. 본심사 신청기간: 2026.04.15(수) ~ 2026.04.30(목)
4. 본심사 진행기간: 2026.05.05(월) ~ 2026.06.05(금)

■ 신청 방법

- 대학원 홈페이지 및 모바일 앱을 통한 온라인 신청

■ 필요서류

- 심사 신청서
- 논문 초본 3부
- 지도교수 의견서

■ 주의사항

- 기한 내에 신청하지 않은 경우 다음 학기에 신청 가능
- 심사비 납부는 신청 후 3일 내에 완료 필요
- 수정사항 제출 기한을 반드시 지켜주시기 바랍니다.

더 자세한 내용은 대학원 교학팀(02-3277-3456)으로 문의주시기 바랍니다.`,
  },
}

export default async function NoticeDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const notice = mockNotices[parseInt(id)]

  if (!notice) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="mx-auto max-w-5xl px-4 md:px-8">
          <div className="text-center">
            <p className="text-gray-500">공지사항을 찾을 수 없습니다.</p>
            <Link href="/user/information/notice">
              <Button variant="outline" className="mt-4">
                목록으로 돌아가기
              </Button>
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return <NoticeDetail notice={notice} id={parseInt(id)} />
}
