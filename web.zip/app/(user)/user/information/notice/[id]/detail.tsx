"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

interface Notice {
  id: number
  title: string
  author: string
  date: string
  views: number
  content: string
}

export default function NoticeDetail({ notice, id }: { notice: Notice; id: number }) {
  const router = useRouter()
  const [viewCount, setViewCount] = useState(notice.views)

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="mx-auto max-w-5xl px-4 md:px-8 space-y-6">
        {/* Back Button */}
        <button
          onClick={() => router.back()}
          className="flex items-center gap-2 text-blue-600 hover:text-blue-700 font-medium"
        >
          <ArrowLeft className="h-4 w-4" />
          목록으로
        </button>

        {/* Notice Content */}
        <Card>
          <CardHeader className="border-b border-gray-200 pb-6">
            <div className="flex items-start justify-between gap-4">
              <h1 className="text-3xl font-bold text-gray-900 flex-1">{notice.title}</h1>
              <div className="text-sm text-gray-600 whitespace-nowrap flex-shrink-0">{notice.date}</div>
            </div>
          </CardHeader>

          <CardContent className="pt-8">
            <div className="prose prose-sm max-w-none">
              <div className="whitespace-pre-wrap text-gray-800 leading-8 font-normal text-base">
                {notice.content}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-center mt-8">
          <Link href="/user/information/notice">
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">목록</Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
