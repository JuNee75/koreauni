"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Download, FileText, Clock } from "lucide-react"
import Link from "next/link"

interface Archive {
  id: number
  title: string
  author: string
  date: string
  downloads: number
  fileSize: string
  fileName: string
  description: string
}

export default function ArchiveDetail({ archive, id }: { archive: Archive; id: number }) {
  const router = useRouter()
  const [downloadCount, setDownloadCount] = useState(archive.downloads)

  const handleDownload = () => {
    console.log(`Downloading: ${archive.fileName}`)
    setDownloadCount(downloadCount + 1)
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="mx-auto max-w-5xl px-4 md:px-8 space-y-6">
        {/* Back Button */}
        <button
          onClick={() => router.back()}
          className="flex items-center gap-2 text-blue-600 hover:text-blue-700 font-medium"
        >
          <ArrowLeft className="h-4 w-4" />
          목록으로
        </button>

        {/* Archive Content */}
        <Card>
          <CardHeader className="border-b border-gray-200 pb-6">
            <div className="space-y-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3 flex-1">
                  <FileText className="h-8 w-8 text-orange-500 flex-shrink-0 mt-1" />
                  <div className="flex-1">
                    <h1 className="text-3xl font-bold text-gray-900">{archive.title}</h1>
                    <p className="text-sm text-gray-500 mt-1">{archive.fileName}</p>
                  </div>
                </div>
                <div className="text-sm text-gray-600 whitespace-nowrap flex-shrink-0">{archive.date}</div>
              </div>
            </div>
          </CardHeader>

          <CardContent className="pt-8">
            <div className="mb-8 pb-8 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">파일 정보</h3>
              <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <FileText className="h-8 w-8 text-orange-500" />
                    <div>
                      <p className="font-medium text-gray-900">{archive.fileName}</p>
                    </div>
                  </div>
                  <Button
                    onClick={handleDownload}
                    className="gap-2 bg-blue-600 hover:bg-blue-700"
                  >
                    <Download className="h-4 w-4" />
                    다운로드
                  </Button>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">자료 설명</h3>
              <div className="prose prose-sm max-w-none">
                <div className="whitespace-pre-wrap text-gray-800 leading-8 font-normal text-base">
                  {archive.description}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-center mt-8">
          <Link href="/user/information/archive">
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">목록</Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
