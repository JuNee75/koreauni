import { Button } from "@/components/ui/button"
import Link from "next/link"
import ArchiveDetail from "./detail"

interface Archive {
  id: number
  title: string
  author: string
  date: string
  downloads: number
  fileSize: string
  fileName: string
  description: string
}

const mockArchives: Record<number, Archive> = {
  1: {
    id: 1,
    title: "2026학년도 대학원 입학전형 요강",
    author: "관리자",
    date: "2026-02-20",
    downloads: 543,
    fileSize: "2.4 MB",
    fileName: "입학전형요강_2026.pdf",
    description: `2026학년도 대학원 입학전형 요강입니다.

■ 모집학과
- 일반대학원: 15개 학과
- 특수대학원: 12개 학과

■ 모집인원
- 일반대학원: 석사과정 150명, 박사과정 100명
- 특수대학원: 정원 내 모집

■ 전형방법
1단계: 서류심사 (100점)
2단계: 구술면접 (100점)

최종성적 = 1단계 40% + 2단계 60%

■ 제출서류
- 입학지원서
- 대학 또는 대학원 성적증명서
- 학위증명서
- 자기소개서
- 추천서 (선택사항)
- 어학성적 (선택사항)

■ 원서 접수
- 온라인 접수: 2026.03.02(월) ~ 2026.03.10(화)
- 서류 제출: 2026.03.02(월) ~ 2026.03.12(목)

■ 면접일정
- 일반대학원: 2026.04.10(금) ~ 2026.04.15(수)
- 특수대학원: 2026.04.17(금) ~ 2026.04.22(수)

■ 합격자 발표
- 2026.05.08(목)

자세한 내용은 본 요강을 참고하시기 바랍니다.`,
  },
  2: {
    id: 2,
    title: "학위논문 작성 지침서",
    author: "교학팀",
    date: "2026-02-15",
    downloads: 892,
    fileSize: "1.8 MB",
    fileName: "논문작성지침서.pdf",
    description: `고려대학교 대학원 학위논문 작성 지침서입니다.

■ 논문의 형식
- 용지: A4 (210mm × 297mm)
- 여백: 상 30mm, 하 30mm, 좌 35mm, 우 25mm
- 줄간격: 1.5배 (학위논문 본문)
- 글꼴: 한글(신명조), 영문(Times New Roman)
- 글자크기: 본문 12포인트

■ 논문의 구성
1. 표지
2. 학위논문 제출 동의서
3. 학위논문 심사결과서
4. 목차
5. 국문 요약 (3-4쪽)
6. 영문 요약 (3-4쪽)
7. 본문
8. 참고문헌
9. 부록 (필요시)

■ 장 구성
- 1장 서론 (선행연구 검토)
- 2장 이상 본문
- 마지막 장 결론 및 향후과제

■ 참고문헌 작성
- APA 양식 또는 학과별 지정 양식 준용
- 본문에 인용된 순서대로 기재

■ 기타 사항
- 페이지 번호: 논문 본문부터 부여
- 그림/표: 각 장별로 순번 부여
- 각주: 미주형으로 통일

자세한 내용은 본 지침서를 참고하시기 바랍니다.`,
  },
  3: {
    id: 3,
    title: "연구윤리 교육자료",
    author: "관리자",
    date: "2026-02-10",
    downloads: 456,
    fileSize: "3.2 MB",
    fileName: "연구윤리교육.pdf",
    description: `고려대학교 대학원 연구윤리 교육자료입니다.

■ 연구윤리의 기본원칙
1. 정직성 (Honesty)
   - 성실한 연구 수행
   - 연구결과의 정확한 보고
   - 부정행위 금지

2. 책임성 (Responsibility)
   - 연구 결과에 대한 책임
   - 오류 시 정정 의무

3. 진정성 (Authenticity)
   - 모든 자료의 출처 명시
   - 표절 금지

■ 연구 부정행위
1. 위조 (Fabrication): 존재하지 않는 자료 제작
2. 변조 (Falsification): 연구 자료 임의 변경
3. 표절 (Plagiarism): 출처 미표시 인용
4. 부당한 저자표시: 불공정한 저자 표시

■ 연구시험윤리
- IRB(기관생명윤리위원회) 승인 필수
- 동의서 작성 및 보관
- 개인정보 보호
- 참여자 보호

■ 연구자의 책임
- 정기적인 윤리교육 이수
- 연구실 내 윤리문화 조성
- 부정행위 적극 신고
- 학생지도 시 윤리기준 강조

본 자료를 숙지하여 연구활동에 적용하시기 바랍니다.`,
  },
}

export default async function ArchiveDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const archive = mockArchives[parseInt(id)]

  if (!archive) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="mx-auto max-w-5xl px-4 md:px-8">
          <div className="text-center">
            <p className="text-gray-500">자료를 찾을 수 없습니다.</p>
            <Link href="/user/information/archive">
              <Button variant="outline" className="mt-4">
                목록으로 돌아가기
              </Button>
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return <ArchiveDetail archive={archive} id={parseInt(id)} />
}
