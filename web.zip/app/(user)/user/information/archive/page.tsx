"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, FileText, ChevronLeft, ChevronRight } from "lucide-react"
import Link from "next/link"

interface Archive {
  id: number
  title: string
  author: string
  date: string
  downloads: number
  fileSize: string
  fileName: string
}

const mockArchives: Archive[] = [
  {
    id: 1,
    title: "2026학년도 대학원 입학전형 요강",
    author: "관리자",
    date: "2026-02-20",
    downloads: 543,
    fileSize: "2.4 MB",
    fileName: "입학전형요강_2026.pdf",
  },
  {
    id: 2,
    title: "학위논문 작성 지침서",
    author: "교학팀",
    date: "2026-02-15",
    downloads: 892,
    fileSize: "1.8 MB",
    fileName: "논문작성지침서.pdf",
  },
  {
    id: 3,
    title: "연구윤리 교육자료",
    author: "관리자",
    date: "2026-02-10",
    downloads: 456,
    fileSize: "3.2 MB",
    fileName: "연구윤리교육.pdf",
  },
  {
    id: 4,
    title: "장학금 신청서 양식",
    author: "행정팀",
    date: "2026-02-05",
    downloads: 723,
    fileSize: "0.5 MB",
    fileName: "장학금신청서.docx",
  },
  {
    id: 5,
    title: "대학원 종합시험 과거문제",
    author: "교학팀",
    date: "2026-01-28",
    downloads: 1245,
    fileSize: "4.1 MB",
    fileName: "종합시험_과거문제.pdf",
  },
  {
    id: 6,
    title: "학위논문 심사 신청서",
    author: "관리자",
    date: "2026-01-20",
    downloads: 634,
    fileSize: "0.3 MB",
    fileName: "논문심사신청서.docx",
  },
  {
    id: 7,
    title: "대학원생 연구실 사용 규정",
    author: "행정팀",
    date: "2026-01-15",
    downloads: 289,
    fileSize: "1.2 MB",
    fileName: "연구실사용규정.pdf",
  },
  {
    id: 8,
    title: "학술발표 지원금 신청 안내",
    author: "교학팀",
    date: "2026-01-10",
    downloads: 412,
    fileSize: "0.8 MB",
    fileName: "학술발표지원금안내.pdf",
  },
  {
    id: 9,
    title: "연구윤리 교육자료",
    author: "관리자",
    date: "2025-12-27",
    downloads: 567,
    fileSize: "2.4 MB",
    fileName: "연구윤리교육.pdf",
  },
  {
    id: 10,
    title: "학위청구논문 양식 (2026)",
    author: "교학팀",
    date: "2025-12-20",
    downloads: 456,
    fileSize: "1.1 MB",
    fileName: "학위청구논문양식_2026.docx",
  },
  {
    id: 11,
    title: "대학원 공지사항 템플릿",
    author: "행정팀",
    date: "2025-12-15",
    downloads: 289,
    fileSize: "0.8 MB",
    fileName: "공지사항템플릿.docx",
  },
  {
    id: 12,
    title: "학술지 발행규정 안내",
    author: "관리자",
    date: "2025-12-10",
    downloads: 378,
    fileSize: "1.5 MB",
    fileName: "학술지발행규정.pdf",
  },
  {
    id: 13,
    title: "세미나 발표 자료 작성법",
    author: "교학팀",
    date: "2025-12-05",
    downloads: 512,
    fileSize: "3.2 MB",
    fileName: "세미나발표자료작성법.pdf",
  },
  {
    id: 14,
    title: "논문 인용 방식 가이드",
    author: "도서관",
    date: "2025-11-28",
    downloads: 623,
    fileSize: "1.7 MB",
    fileName: "논문인용방식가이드.pdf",
  },
  {
    id: 15,
    title: "연구 데이터 관리 규정",
    author: "관리자",
    date: "2025-11-20",
    downloads: 445,
    fileSize: "2.1 MB",
    fileName: "연구데이터관리규정.pdf",
  },
]

export default function ArchiveListPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 10

  const filteredArchives = mockArchives.filter((archive) =>
    archive.title.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const totalPages = Math.ceil(filteredArchives.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const endIndex = startIndex + itemsPerPage
  const paginatedArchives = filteredArchives.slice(startIndex, endIndex)

  const handlePageChange = (page: number) => {
    setCurrentPage(page)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const handleReset = () => {
    setSearchTerm("")
    setCurrentPage(1)
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="mx-auto max-w-5xl px-4 md:px-8 space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900">자료실</h1>
          <p className="text-gray-600 mt-2">대학원의 다양한 학사 자료를 다운로드하세요.</p>
        </div>

        {/* Search */}
        <div>
          <div className="pt-6">
            <div className="flex gap-2">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="자료 검색..."
                  value={searchTerm}
                  onChange={(e) => {
                    setSearchTerm(e.target.value)
                    setCurrentPage(1)
                  }}
                  className="pl-10"
                />
              </div>
              <Button variant="outline" onClick={handleReset} disabled={!searchTerm}>
                초기화
              </Button>
            </div>
          </div>
        </div>

        {/* Archives Table */}
        <Card>
          <CardContent className="pt-6">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 font-semibold text-gray-700 text-sm">제목</th>
                    <th className="hidden md:table-cell text-right py-3 px-4 font-semibold text-gray-700 text-sm whitespace-nowrap w-32">작성일</th>
                  </tr>
                </thead>
                <tbody>
                  {paginatedArchives.map((archive) => (
                    <tr key={archive.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                      <td className="py-3 px-4">
                        <Link href={`/user/information/archive/${archive.id}`}>
                          <div className="flex items-center gap-3 hover:text-blue-600 transition-colors">
                            <FileText className="h-5 w-5 text-orange-500 flex-shrink-0" />
                            <span className="font-medium text-gray-900 hover:underline">{archive.title}</span>
                          </div>
                        </Link>
                      </td>
                      <td className="hidden md:table-cell py-3 px-4 text-right text-sm text-gray-600 whitespace-nowrap">{archive.date}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {filteredArchives.length === 0 && (
              <div className="text-center py-10">
                <p className="text-gray-500">검색 결과가 없습니다.</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={currentPage === 1}
              onClick={() => handlePageChange(currentPage - 1)}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>

            {Array.from({ length: totalPages }).map((_, index) => (
              <Button
                key={index + 1}
                variant={currentPage === index + 1 ? "default" : "outline"}
                size="sm"
                onClick={() => handlePageChange(index + 1)}
              >
                {index + 1}
              </Button>
            ))}

            <Button
              variant="outline"
              size="sm"
              disabled={currentPage === totalPages}
              onClick={() => handlePageChange(currentPage + 1)}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
