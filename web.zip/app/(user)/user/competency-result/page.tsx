'use client'

import { useState } from 'react'
import { ArrowLeft, Zap } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { StudentDiagnosisSummary } from '@/components/competency/student-diagnosis-summary'
import { StudentAIAnalysis } from '@/components/competency/student-ai-analysis'

// 김민준 학생의 역량진단 데이터
const studentDiagnosisData = {
  studentName: '김민준',
  competencies: [
    {
      name: '학습연구역량',
      score: 78,
      level: '우수',
      categories: [
        { name: '학업적 효능감', score: 85, level: '탁월' },
        { name: '학업적 회복탄력성', score: 80, level: '우수' },
        { name: '성실성 및 책임감', score: 81, level: '우수' },
        { name: '시간관리', score: 72, level: '보통' },
        { name: '집중력 및 학습환경 관리', score: 78, level: '우수' },
        { name: '학습전략 및 정보처리', score: 75, level: '보통' },
      ],
    },
    {
      name: '융합연구역량',
      score: 65,
      level: '개선필요',
      categories: [
        { name: '논리적 추론', score: 68, level: '보통' },
        { name: '다학제간 통찰', score: 58, level: '개선필요' },
        { name: '독창적 발상', score: 55, level: '개선필요' },
        { name: '메타인지적 성찰', score: 62, level: '보통' },
        { name: '연구문제 구조화', score: 69, level: '보통' },
        { name: '증거기반 분석', score: 71, level: '보통' },
      ],
    },
  ],
  departmentAverage: [
    { name: '학습연구역량', score: 76 },
    { name: '융합연구역량', score: 72 },
  ],
  schoolAverage: [
    { name: '학습연구역량', score: 73 },
    { name: '융합연구역량', score: 70 },
  ],
}

export default function CompetencyResultPage() {
  const router = useRouter()
  const [showAIAnalysis, setShowAIAnalysis] = useState(false)

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="mx-auto max-w-7xl px-4 py-8 md:px-8 md:py-10 space-y-6">
        {/* 헤더 */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => router.back()}
              className="h-8 w-8 p-0"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">역량 진단 결과</h1>
          </div>
          <Button
            onClick={() => setShowAIAnalysis(!showAIAnalysis)}
            className="gap-2 bg-blue-600 hover:bg-blue-700"
          >
            <Zap className="h-4 w-4" />
            {showAIAnalysis ? 'AI 분석 닫기' : 'AI 역량분석'}
          </Button>
        </div>

        {/* 동적 AI 분석 결과 표시 */}
        {showAIAnalysis && (
          <div className="animate-in fade-in duration-300">
            <StudentAIAnalysis data={studentDiagnosisData} />
          </div>
        )}

        {/* 진단 결과 요약 */}
        <StudentDiagnosisSummary data={studentDiagnosisData} />
      </div>
    </div>
  )
}
